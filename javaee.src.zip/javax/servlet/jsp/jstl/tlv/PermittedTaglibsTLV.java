package javax.servlet.jsp.jstl.tlv;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import javax.servlet.jsp.tagext.TagLibraryValidator;
import javax.servlet.jsp.tagext.ValidationMessage;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class PermittedTaglibsTLV extends TagLibraryValidator
{
  private final String PERMITTED_TAGLIBS_PARAM = "permittedTaglibs";
  private final String JSP_ROOT_URI = "http://java.sun.com/JSP/Page";
  private final String JSP_ROOT_NAME = "root";
  private final String JSP_ROOT_QN = "jsp:root";
  private Set permittedTaglibs;
  private boolean failed;
  private String uri;

  public PermittedTaglibsTLV()
  {
    init();
  }

  private void init() {
    this.permittedTaglibs = null;
    this.failed = false;
  }

  public void release() {
    super.release();
    init(); } 
  // ERROR //
  public synchronized ValidationMessage[] validate(String prefix, String uri, javax.servlet.jsp.tagext.PageData page) { // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: putfield 158	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:uri	Ljava/lang/String;
    //   5: aload_0
    //   6: aload_0
    //   7: invokespecial 171	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:readConfiguration	()Ljava/util/Set;
    //   10: putfield 159	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:permittedTaglibs	Ljava/util/Set;
    //   13: new 87	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV$PermittedTaglibsHandler
    //   16: dup
    //   17: aload_0
    //   18: aconst_null
    //   19: invokespecial 173	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV$PermittedTaglibsHandler:<init>	(Ljavax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV;Ljavax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV$1;)V
    //   22: astore 4
    //   24: invokestatic 182	javax/xml/parsers/SAXParserFactory:newInstance	()Ljavax/xml/parsers/SAXParserFactory;
    //   27: astore 5
    //   29: aload 5
    //   31: iconst_1
    //   32: invokevirtual 180	javax/xml/parsers/SAXParserFactory:setValidating	(Z)V
    //   35: aload 5
    //   37: invokevirtual 181	javax/xml/parsers/SAXParserFactory:newSAXParser	()Ljavax/xml/parsers/SAXParser;
    //   40: astore 6
    //   42: aload 6
    //   44: aload_3
    //   45: invokevirtual 174	javax/servlet/jsp/tagext/PageData:getInputStream	()Ljava/io/InputStream;
    //   48: aload 4
    //   50: invokevirtual 179	javax/xml/parsers/SAXParser:parse	(Ljava/io/InputStream;Lorg/xml/sax/helpers/DefaultHandler;)V
    //   53: aload_0
    //   54: getfield 153	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:failed	Z
    //   57: ifeq +53 -> 110
    //   60: aload_0
    //   61: new 80	java/lang/StringBuilder
    //   64: dup
    //   65: invokespecial 161	java/lang/StringBuilder:<init>	()V
    //   68: ldc 8
    //   70: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: aload_1
    //   74: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: ldc 1
    //   79: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: aload_2
    //   83: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: ldc 2
    //   88: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: ldc 3
    //   93: invokevirtual 164	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: aload_0
    //   97: getfield 159	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:permittedTaglibs	Ljava/util/Set;
    //   100: invokevirtual 163	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   103: invokevirtual 162	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   106: invokespecial 172	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   109: areturn
    //   110: aconst_null
    //   111: areturn
    //   112: astore 4
    //   114: aload_0
    //   115: aload 4
    //   117: invokevirtual 183	org/xml/sax/SAXException:toString	()Ljava/lang/String;
    //   120: invokespecial 172	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   123: areturn
    //   124: astore 4
    //   126: aload_0
    //   127: aload 4
    //   129: invokevirtual 178	javax/xml/parsers/ParserConfigurationException:toString	()Ljava/lang/String;
    //   132: invokespecial 172	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   135: areturn
    //   136: astore 4
    //   138: aload_0
    //   139: aload 4
    //   141: invokevirtual 160	java/io/IOException:toString	()Ljava/lang/String;
    //   144: invokespecial 172	javax/servlet/jsp/jstl/tlv/PermittedTaglibsTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   147: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	109	112	org/xml/sax/SAXException
    //   110	111	112	org/xml/sax/SAXException
    //   0	109	124	javax/xml/parsers/ParserConfigurationException
    //   110	111	124	javax/xml/parsers/ParserConfigurationException
    //   0	109	136	java/io/IOException
    //   110	111	136	java/io/IOException } 
  private Set readConfiguration() { Set s = new HashSet();

    String uris = (String)getInitParameters().get("permittedTaglibs");

    StringTokenizer st = new StringTokenizer(uris);
    while (st.hasMoreTokens()) {
      s.add(st.nextToken());
    }

    return s;
  }

  private ValidationMessage[] vmFromString(String message)
  {
    return { new ValidationMessage(null, message) };
  }

  private class PermittedTaglibsHandler extends DefaultHandler
  {
    public void startElement(, String ln, String qn, Attributes a)
    {
      if ((!(qn.equals("jsp:root"))) && (((!(ns.equals("http://java.sun.com/JSP/Page"))) || (!(ln.equals("root"))))))
      {
        return;
      }

      for (int i = 0; i < a.getLength(); ++i) {
        String name = a.getQName(i);

        if (name.startsWith("xmlns:")) { if (name.equals("xmlns:jsp"))
            break label132:

          String value = a.getValue(i);

          if (value.equals(PermittedTaglibsTLV.access$100(this.this$0))) {
            break label132:
          }

          label132: if (!(PermittedTaglibsTLV.access$200(this.this$0).contains(value)))
            PermittedTaglibsTLV.access$302(this.this$0, true);
        }
      }
    }
  }
}