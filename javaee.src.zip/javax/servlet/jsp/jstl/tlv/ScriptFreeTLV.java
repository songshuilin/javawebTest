package javax.servlet.jsp.jstl.tlv;

import java.util.Map;
import javax.servlet.jsp.tagext.TagLibraryValidator;
import javax.servlet.jsp.tagext.ValidationMessage;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class ScriptFreeTLV extends TagLibraryValidator
{
  private boolean allowDeclarations = false;
  private boolean allowScriptlets = false;
  private boolean allowExpressions = false;
  private boolean allowRTExpressions = false;
  private SAXParserFactory factory;

  public ScriptFreeTLV()
  {
    this.factory = SAXParserFactory.newInstance();
    this.factory.setValidating(false);
    this.factory.setNamespaceAware(true);
  }

  public void setInitParameters(Map<String, Object> initParms)
  {
    super.setInitParameters(initParms);
    String declarationsParm = (String)initParms.get("allowDeclarations");
    String scriptletsParm = (String)initParms.get("allowScriptlets");
    String expressionsParm = (String)initParms.get("allowExpressions");
    String rtExpressionsParm = (String)initParms.get("allowRTExpressions");

    this.allowRTExpressions = "true".equalsIgnoreCase(declarationsParm);
    this.allowScriptlets = "true".equalsIgnoreCase(scriptletsParm);
    this.allowExpressions = "true".equalsIgnoreCase(expressionsParm);
    this.allowRTExpressions = "true".equalsIgnoreCase(rtExpressionsParm);
  }

  // ERROR //
  public ValidationMessage[] validate(String prefix, String uri, javax.servlet.jsp.tagext.PageData page)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: new 70	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV$MyContentHandler
    //   6: dup
    //   7: aload_0
    //   8: aconst_null
    //   9: invokespecial 136	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV$MyContentHandler:<init>	(Ljavax/servlet/jsp/jstl/tlv/ScriptFreeTLV;Ljavax/servlet/jsp/jstl/tlv/ScriptFreeTLV$1;)V
    //   12: astore 6
    //   14: aload_0
    //   15: getfield 130	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV:factory	Ljavax/xml/parsers/SAXParserFactory;
    //   18: dup
    //   19: astore 7
    //   21: monitorenter
    //   22: aload_0
    //   23: getfield 130	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV:factory	Ljavax/xml/parsers/SAXParserFactory;
    //   26: invokevirtual 145	javax/xml/parsers/SAXParserFactory:newSAXParser	()Ljavax/xml/parsers/SAXParser;
    //   29: astore 5
    //   31: aload 7
    //   33: monitorexit
    //   34: goto +11 -> 45
    //   37: astore 8
    //   39: aload 7
    //   41: monitorexit
    //   42: aload 8
    //   44: athrow
    //   45: aload_3
    //   46: invokevirtual 137	javax/servlet/jsp/tagext/PageData:getInputStream	()Ljava/io/InputStream;
    //   49: astore 4
    //   51: aload 5
    //   53: aload 4
    //   55: aload 6
    //   57: invokevirtual 142	javax/xml/parsers/SAXParser:parse	(Ljava/io/InputStream;Lorg/xml/sax/helpers/DefaultHandler;)V
    //   60: aload 4
    //   62: ifnull +126 -> 188
    //   65: aload 4
    //   67: invokevirtual 132	java/io/InputStream:close	()V
    //   70: goto +118 -> 188
    //   73: astore 7
    //   75: goto +113 -> 188
    //   78: astore 7
    //   80: aload 7
    //   82: invokevirtual 141	javax/xml/parsers/ParserConfigurationException:toString	()Ljava/lang/String;
    //   85: invokestatic 134	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   88: astore 8
    //   90: aload 4
    //   92: ifnull +13 -> 105
    //   95: aload 4
    //   97: invokevirtual 132	java/io/InputStream:close	()V
    //   100: goto +5 -> 105
    //   103: astore 9
    //   105: aload 8
    //   107: areturn
    //   108: astore 7
    //   110: aload 7
    //   112: invokevirtual 147	org/xml/sax/SAXException:toString	()Ljava/lang/String;
    //   115: invokestatic 134	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   118: astore 8
    //   120: aload 4
    //   122: ifnull +13 -> 135
    //   125: aload 4
    //   127: invokevirtual 132	java/io/InputStream:close	()V
    //   130: goto +5 -> 135
    //   133: astore 9
    //   135: aload 8
    //   137: areturn
    //   138: astore 7
    //   140: aload 7
    //   142: invokevirtual 131	java/io/IOException:toString	()Ljava/lang/String;
    //   145: invokestatic 134	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV:vmFromString	(Ljava/lang/String;)[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   148: astore 8
    //   150: aload 4
    //   152: ifnull +13 -> 165
    //   155: aload 4
    //   157: invokevirtual 132	java/io/InputStream:close	()V
    //   160: goto +5 -> 165
    //   163: astore 9
    //   165: aload 8
    //   167: areturn
    //   168: astore 10
    //   170: aload 4
    //   172: ifnull +13 -> 185
    //   175: aload 4
    //   177: invokevirtual 132	java/io/InputStream:close	()V
    //   180: goto +5 -> 185
    //   183: astore 11
    //   185: aload 10
    //   187: athrow
    //   188: aload 6
    //   190: invokevirtual 135	javax/servlet/jsp/jstl/tlv/ScriptFreeTLV$MyContentHandler:reportResults	()[Ljavax/servlet/jsp/tagext/ValidationMessage;
    //   193: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   22	34	37	finally
    //   37	42	37	finally
    //   65	70	73	java/io/IOException
    //   14	60	78	javax/xml/parsers/ParserConfigurationException
    //   95	100	103	java/io/IOException
    //   14	60	108	org/xml/sax/SAXException
    //   125	130	133	java/io/IOException
    //   14	60	138	java/io/IOException
    //   155	160	163	java/io/IOException
    //   14	60	168	finally
    //   78	90	168	finally
    //   108	120	168	finally
    //   138	150	168	finally
    //   168	170	168	finally
    //   175	180	183	java/io/IOException
  }

  private static ValidationMessage[] vmFromString(String message)
  {
    return { new ValidationMessage(null, message) };
  }

  private class MyContentHandler extends DefaultHandler
  {
    private int declarationCount;
    private int scriptletCount;
    private int expressionCount;
    private int rtExpressionCount;

    private MyContentHandler()
    {
      this.declarationCount = 0;
      this.scriptletCount = 0;
      this.expressionCount = 0;
      this.rtExpressionCount = 0;
    }

    public void startElement(, String localName, String qualifiedName, Attributes atts)
    {
      if ((!(ScriptFreeTLV.access$100(this.this$0))) && (qualifiedName.equals("jsp:declaration")))
      {
        this.declarationCount = (this.declarationCount + 1);
      } else if ((!(ScriptFreeTLV.access$200(this.this$0))) && (qualifiedName.equals("jsp:scriptlet")))
      {
        this.scriptletCount = (this.scriptletCount + 1);
      } else if ((!(ScriptFreeTLV.access$300(this.this$0))) && (qualifiedName.equals("jsp:expression")))
      {
        this.expressionCount = (this.expressionCount + 1); }
      if (!(ScriptFreeTLV.access$400(this.this$0))) countRTExpressions(atts);
    }

    private void countRTExpressions()
    {
      int stop = atts.getLength();
      for (int i = 0; i < stop; ++i) {
        String attval = atts.getValue(i);
        if ((attval.startsWith("%=")) && (attval.endsWith("%")))
          this.rtExpressionCount = (this.rtExpressionCount + 1);
      }
    }

    public ValidationMessage[] reportResults()
    {
      if (this.declarationCount + this.scriptletCount + this.expressionCount > this.rtExpressionCount)
      {
        StringBuffer results = new StringBuffer("JSP page contains ");
        boolean first = true;
        if (this.declarationCount > 0) {
          results.append(Integer.toString(this.declarationCount));
          results.append(" declaration");
          if (this.declarationCount > 1) results.append('s');
          first = false;
        }
        if (this.scriptletCount > 0) {
          if (!(first)) results.append(", ");
          results.append(Integer.toString(this.scriptletCount));
          results.append(" scriptlet");
          if (this.scriptletCount > 1) results.append('s');
          first = false;
        }
        if (this.expressionCount > 0) {
          if (!(first)) results.append(", ");
          results.append(Integer.toString(this.expressionCount));
          results.append(" expression");
          if (this.expressionCount > 1) results.append('s');
          first = false;
        }
        if (this.rtExpressionCount > 0) {
          if (!(first)) results.append(", ");
          results.append(Integer.toString(this.rtExpressionCount));
          results.append(" request-time attribute value");
          if (this.rtExpressionCount > 1) results.append('s');
          first = false;
        }
        results.append(".");
        return ScriptFreeTLV.access$500(results.toString());
      }
      return null;
    }
  }
}