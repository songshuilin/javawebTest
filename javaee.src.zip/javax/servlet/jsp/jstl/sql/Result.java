package javax.servlet.jsp.jstl.sql;

import java.util.SortedMap;

public abstract interface Result
{
  public abstract SortedMap[] getRows();

  public abstract Object[][] getRowsByIndex();

  public abstract String[] getColumnNames();

  public abstract int getRowCount();

  public abstract boolean isLimitedByMaxRows();
}