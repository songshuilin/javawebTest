package javax.servlet.jsp.jstl.sql;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

class ResultImpl
  implements Result, Serializable
{
  private List rowMap;
  private List rowByIndex;
  private String[] columnNames;
  private boolean isLimited;

  public ResultImpl(ResultSet rs, int startRow, int maxRows)
    throws SQLException
  {
    this.rowMap = new ArrayList();
    this.rowByIndex = new ArrayList();

    ResultSetMetaData rsmd = rs.getMetaData();
    int noOfColumns = rsmd.getColumnCount();

    this.columnNames = new String[noOfColumns];
    for (int i = 1; i <= noOfColumns; ++i) {
      this.columnNames[(i - 1)] = rsmd.getColumnName(i);
    }

    for (i = 0; i < startRow; ++i) {
      rs.next();
    }

    int processedRows = 0;
    while (rs.next()) {
      if ((maxRows != -1) && (processedRows == maxRows)) {
        this.isLimited = true;
        return;
      }
      Object[] columns = new Object[noOfColumns];
      SortedMap columnMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);

      for (int i = 1; i <= noOfColumns; ++i) {
        Object value = rs.getObject(i);
        if (rs.wasNull())
          value = null;

        columns[(i - 1)] = value;
        columnMap.put(this.columnNames[(i - 1)], value);
      }
      this.rowMap.add(columnMap);
      this.rowByIndex.add(columns);
      ++processedRows;
    }
  }

  public SortedMap[] getRows()
  {
    if (this.rowMap == null) {
      return null;
    }

    return ((SortedMap[])(SortedMap[])this.rowMap.toArray(new SortedMap[0]));
  }

  public Object[][] getRowsByIndex()
  {
    if (this.rowByIndex == null) {
      return ((Object[][])null);
    }

    return ((Object[][])(Object[][])this.rowByIndex.toArray(new Object[0][0]));
  }

  public String[] getColumnNames()
  {
    return this.columnNames;
  }

  public int getRowCount()
  {
    if (this.rowMap == null)
      return -1;

    return this.rowMap.size();
  }

  public boolean isLimitedByMaxRows()
  {
    return this.isLimited;
  }
}