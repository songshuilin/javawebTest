package javax.servlet.jsp.jstl.sql;

public abstract interface SQLExecutionTag
{
  public abstract void addSQLParameter(Object paramObject);
}