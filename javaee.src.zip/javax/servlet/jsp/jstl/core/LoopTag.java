package javax.servlet.jsp.jstl.core;

import javax.servlet.jsp.tagext.Tag;

public abstract interface LoopTag
  implements Tag
{
  public abstract Object getCurrent();

  public abstract LoopTagStatus getLoopStatus();
}