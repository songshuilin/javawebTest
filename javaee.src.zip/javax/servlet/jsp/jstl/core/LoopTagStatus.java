package javax.servlet.jsp.jstl.core;

public abstract interface LoopTagStatus
{
  public abstract Object getCurrent();

  public abstract int getIndex();

  public abstract int getCount();

  public abstract boolean isFirst();

  public abstract boolean isLast();

  public abstract Integer getBegin();

  public abstract Integer getEnd();

  public abstract Integer getStep();
}