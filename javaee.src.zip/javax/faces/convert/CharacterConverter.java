package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class CharacterConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.Character";
  public static final String CHARACTER_ID = "javax.faces.converter.CharacterConverter.CHARACTER";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return new Character(value.charAt(0));
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.CharacterConverter.CHARACTER", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return "";

    try
    {
      return value.toString();
    } catch (Exception e) {
      throw new ConverterException(e);
    }
  }
}