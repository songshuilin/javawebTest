package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class LongConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.Long";
  public static final String LONG_ID = "javax.faces.converter.LongConverter.LONG";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return Long.valueOf(value);
    } catch (NumberFormatException nfe) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.LongConverter.LONG", new Object[] { value, "98765432", MessageFactory.getLabel(context, component) }));
    }
    catch (Exception e)
    {
      throw new ConverterException(e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null) {
      return "";
    }

    if (value instanceof String)
      return ((String)value);

    try
    {
      return Long.toString(((Long)value).longValue());
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }
}