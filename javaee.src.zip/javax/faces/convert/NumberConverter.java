package javax.faces.convert;

import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import javax.faces.component.StateHolder;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

public class NumberConverter
  implements Converter, StateHolder
{
  public static final String CONVERTER_ID = "javax.faces.Number";
  public static final String CURRENCY_ID = "javax.faces.converter.NumberConverter.CURRENCY";
  public static final String NUMBER_ID = "javax.faces.converter.NumberConverter.NUMBER";
  public static final String PATTERN_ID = "javax.faces.converter.NumberConverter.PATTERN";
  public static final String PERCENT_ID = "javax.faces.converter.NumberConverter.PERCENT";
  public static final String STRING_ID = "javax.faces.converter.STRING";
  private String currencyCode;
  private String currencySymbol;
  private boolean groupingUsed;
  private boolean integerOnly;
  private int maxFractionDigits;
  private boolean maxFractionDigitsSpecified;
  private int maxIntegerDigits;
  private boolean maxIntegerDigitsSpecified;
  private int minFractionDigits;
  private boolean minFractionDigitsSpecified;
  private int minIntegerDigits;
  private boolean minIntegerDigitsSpecified;
  private Locale locale;
  private String pattern;
  private String type;
  private static Class currencyClass;
  private static final Class[] GET_INSTANCE_PARAM_TYPES;
  private boolean transientFlag;

  public NumberConverter()
  {
    this.currencyCode = null;
    this.currencySymbol = null;
    this.groupingUsed = true;
    this.integerOnly = false;
    this.maxFractionDigits = 0;
    this.maxFractionDigitsSpecified = false;
    this.maxIntegerDigits = 0;
    this.maxIntegerDigitsSpecified = false;
    this.minFractionDigits = 0;
    this.minFractionDigitsSpecified = false;
    this.minIntegerDigits = 0;
    this.minIntegerDigitsSpecified = false;
    this.locale = null;
    this.pattern = null;
    this.type = "number";

    this.transientFlag = false;
  }

  public String getCurrencyCode()
  {
    return this.currencyCode;
  }

  public void setCurrencyCode(String currencyCode)
  {
    this.currencyCode = currencyCode;
  }

  public String getCurrencySymbol()
  {
    return this.currencySymbol;
  }

  public void setCurrencySymbol(String currencySymbol)
  {
    this.currencySymbol = currencySymbol;
  }

  public boolean isGroupingUsed()
  {
    return this.groupingUsed;
  }

  public void setGroupingUsed(boolean groupingUsed)
  {
    this.groupingUsed = groupingUsed;
  }

  public boolean isIntegerOnly()
  {
    return this.integerOnly;
  }

  public void setIntegerOnly(boolean integerOnly)
  {
    this.integerOnly = integerOnly;
  }

  public int getMaxFractionDigits()
  {
    return this.maxFractionDigits;
  }

  public void setMaxFractionDigits(int maxFractionDigits)
  {
    this.maxFractionDigits = maxFractionDigits;
    this.maxFractionDigitsSpecified = true;
  }

  public int getMaxIntegerDigits()
  {
    return this.maxIntegerDigits;
  }

  public void setMaxIntegerDigits(int maxIntegerDigits)
  {
    this.maxIntegerDigits = maxIntegerDigits;
    this.maxIntegerDigitsSpecified = true;
  }

  public int getMinFractionDigits()
  {
    return this.minFractionDigits;
  }

  public void setMinFractionDigits(int minFractionDigits)
  {
    this.minFractionDigits = minFractionDigits;
    this.minFractionDigitsSpecified = true;
  }

  public int getMinIntegerDigits()
  {
    return this.minIntegerDigits;
  }

  public void setMinIntegerDigits(int minIntegerDigits)
  {
    this.minIntegerDigits = minIntegerDigits;
    this.minIntegerDigitsSpecified = true;
  }

  public Locale getLocale()
  {
    if (this.locale == null) {
      this.locale = getLocale(FacesContext.getCurrentInstance());
    }

    return this.locale;
  }

  public void setLocale(Locale locale)
  {
    this.locale = locale;
  }

  public String getPattern()
  {
    return this.pattern;
  }

  public void setPattern(String pattern)
  {
    this.pattern = pattern;
  }

  public String getType()
  {
    return this.type;
  }

  public void setType(String type)
  {
    this.type = type; } 
  // ERROR //
  public Object getAsObject(FacesContext context, javax.faces.component.UIComponent component, String value) { // Byte code:
    //   0: aload_1
    //   1: ifnull +7 -> 8
    //   4: aload_2
    //   5: ifnonnull +11 -> 16
    //   8: new 179	java/lang/NullPointerException
    //   11: dup
    //   12: invokespecial 332	java/lang/NullPointerException:<init>	()V
    //   15: athrow
    //   16: aconst_null
    //   17: astore 4
    //   19: aconst_null
    //   20: astore 5
    //   22: aload_3
    //   23: ifnonnull +5 -> 28
    //   26: aconst_null
    //   27: areturn
    //   28: aload_3
    //   29: invokevirtual 336	java/lang/String:trim	()Ljava/lang/String;
    //   32: astore_3
    //   33: aload_3
    //   34: invokevirtual 334	java/lang/String:length	()I
    //   37: iconst_1
    //   38: if_icmpge +5 -> 43
    //   41: aconst_null
    //   42: areturn
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial 369	javax/faces/convert/NumberConverter:getLocale	(Ljavax/faces/context/FacesContext;)Ljava/util/Locale;
    //   48: astore 6
    //   50: aload_0
    //   51: aload 6
    //   53: invokespecial 368	javax/faces/convert/NumberConverter:getNumberFormat	(Ljava/util/Locale;)Ljava/text/NumberFormat;
    //   56: astore 5
    //   58: aload_0
    //   59: getfield 322	javax/faces/convert/NumberConverter:pattern	Ljava/lang/String;
    //   62: ifnull +15 -> 77
    //   65: aload_0
    //   66: getfield 322	javax/faces/convert/NumberConverter:pattern	Ljava/lang/String;
    //   69: ldc 1
    //   71: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   74: ifeq +15 -> 89
    //   77: ldc 4
    //   79: aload_0
    //   80: getfield 323	javax/faces/convert/NumberConverter:type	Ljava/lang/String;
    //   83: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   86: ifeq +9 -> 95
    //   89: aload_0
    //   90: aload 5
    //   92: invokespecial 366	javax/faces/convert/NumberConverter:configureCurrency	(Ljava/text/NumberFormat;)V
    //   95: aload 5
    //   97: aload_0
    //   98: invokevirtual 365	javax/faces/convert/NumberConverter:isIntegerOnly	()Z
    //   101: invokevirtual 348	java/text/NumberFormat:setParseIntegerOnly	(Z)V
    //   104: aload 5
    //   106: aload_3
    //   107: invokevirtual 351	java/text/NumberFormat:parse	(Ljava/lang/String;)Ljava/lang/Number;
    //   110: astore 4
    //   112: goto +229 -> 341
    //   115: astore 6
    //   117: aload_0
    //   118: getfield 322	javax/faces/convert/NumberConverter:pattern	Ljava/lang/String;
    //   121: ifnull +38 -> 159
    //   124: new 192	javax/faces/convert/ConverterException
    //   127: dup
    //   128: aload_1
    //   129: ldc 10
    //   131: iconst_3
    //   132: anewarray 180	java/lang/Object
    //   135: dup
    //   136: iconst_0
    //   137: aload_3
    //   138: aastore
    //   139: dup
    //   140: iconst_1
    //   141: ldc 2
    //   143: aastore
    //   144: dup
    //   145: iconst_2
    //   146: aload_1
    //   147: aload_2
    //   148: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   151: aastore
    //   152: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   155: invokespecial 360	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   158: athrow
    //   159: aload_0
    //   160: getfield 323	javax/faces/convert/NumberConverter:type	Ljava/lang/String;
    //   163: ldc 4
    //   165: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   168: ifeq +44 -> 212
    //   171: new 192	javax/faces/convert/ConverterException
    //   174: dup
    //   175: aload_1
    //   176: ldc 8
    //   178: iconst_3
    //   179: anewarray 180	java/lang/Object
    //   182: dup
    //   183: iconst_0
    //   184: aload_3
    //   185: aastore
    //   186: dup
    //   187: iconst_1
    //   188: aload 5
    //   190: ldc2_w 170
    //   193: invokevirtual 349	java/text/NumberFormat:format	(D)Ljava/lang/String;
    //   196: aastore
    //   197: dup
    //   198: iconst_2
    //   199: aload_1
    //   200: aload_2
    //   201: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   204: aastore
    //   205: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   208: invokespecial 360	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   211: athrow
    //   212: aload_0
    //   213: getfield 323	javax/faces/convert/NumberConverter:type	Ljava/lang/String;
    //   216: ldc 13
    //   218: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   221: ifeq +44 -> 265
    //   224: new 192	javax/faces/convert/ConverterException
    //   227: dup
    //   228: aload_1
    //   229: ldc 9
    //   231: iconst_3
    //   232: anewarray 180	java/lang/Object
    //   235: dup
    //   236: iconst_0
    //   237: aload_3
    //   238: aastore
    //   239: dup
    //   240: iconst_1
    //   241: aload 5
    //   243: ldc2_w 166
    //   246: invokevirtual 350	java/text/NumberFormat:format	(J)Ljava/lang/String;
    //   249: aastore
    //   250: dup
    //   251: iconst_2
    //   252: aload_1
    //   253: aload_2
    //   254: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   257: aastore
    //   258: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   261: invokespecial 360	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   264: athrow
    //   265: aload_0
    //   266: getfield 323	javax/faces/convert/NumberConverter:type	Ljava/lang/String;
    //   269: ldc 14
    //   271: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   274: ifeq +44 -> 318
    //   277: new 192	javax/faces/convert/ConverterException
    //   280: dup
    //   281: aload_1
    //   282: ldc 11
    //   284: iconst_3
    //   285: anewarray 180	java/lang/Object
    //   288: dup
    //   289: iconst_0
    //   290: aload_3
    //   291: aastore
    //   292: dup
    //   293: iconst_1
    //   294: aload 5
    //   296: ldc2_w 168
    //   299: invokevirtual 349	java/text/NumberFormat:format	(D)Ljava/lang/String;
    //   302: aastore
    //   303: dup
    //   304: iconst_2
    //   305: aload_1
    //   306: aload_2
    //   307: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   310: aastore
    //   311: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   314: invokespecial 360	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   317: athrow
    //   318: goto +23 -> 341
    //   321: astore 6
    //   323: aload 6
    //   325: athrow
    //   326: astore 6
    //   328: new 192	javax/faces/convert/ConverterException
    //   331: dup
    //   332: aload 6
    //   334: invokevirtual 328	java/lang/Exception:getCause	()Ljava/lang/Throwable;
    //   337: invokespecial 359	javax/faces/convert/ConverterException:<init>	(Ljava/lang/Throwable;)V
    //   340: athrow
    //   341: aload 4
    //   343: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   22	27	115	java/text/ParseException
    //   28	42	115	java/text/ParseException
    //   43	112	115	java/text/ParseException
    //   22	27	321	javax/faces/convert/ConverterException
    //   28	42	321	javax/faces/convert/ConverterException
    //   43	112	321	javax/faces/convert/ConverterException
    //   22	27	326	java/lang/Exception
    //   28	42	326	java/lang/Exception
    //   43	112	326	java/lang/Exception } 
  // ERROR //
  public String getAsString(FacesContext context, javax.faces.component.UIComponent component, Object value) { // Byte code:
    //   0: aload_1
    //   1: ifnull +7 -> 8
    //   4: aload_2
    //   5: ifnonnull +11 -> 16
    //   8: new 179	java/lang/NullPointerException
    //   11: dup
    //   12: invokespecial 332	java/lang/NullPointerException:<init>	()V
    //   15: athrow
    //   16: aload_3
    //   17: ifnonnull +6 -> 23
    //   20: ldc 1
    //   22: areturn
    //   23: aload_3
    //   24: instanceof 181
    //   27: ifeq +8 -> 35
    //   30: aload_3
    //   31: checkcast 181	java/lang/String
    //   34: areturn
    //   35: aload_0
    //   36: aload_1
    //   37: invokespecial 369	javax/faces/convert/NumberConverter:getLocale	(Ljavax/faces/context/FacesContext;)Ljava/util/Locale;
    //   40: astore 4
    //   42: aload_0
    //   43: aload 4
    //   45: invokespecial 368	javax/faces/convert/NumberConverter:getNumberFormat	(Ljava/util/Locale;)Ljava/text/NumberFormat;
    //   48: astore 5
    //   50: aload_0
    //   51: getfield 322	javax/faces/convert/NumberConverter:pattern	Ljava/lang/String;
    //   54: ifnull +15 -> 69
    //   57: aload_0
    //   58: getfield 322	javax/faces/convert/NumberConverter:pattern	Ljava/lang/String;
    //   61: ldc 1
    //   63: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   66: ifeq +15 -> 81
    //   69: ldc 4
    //   71: aload_0
    //   72: getfield 323	javax/faces/convert/NumberConverter:type	Ljava/lang/String;
    //   75: invokevirtual 335	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   78: ifeq +9 -> 87
    //   81: aload_0
    //   82: aload 5
    //   84: invokespecial 366	javax/faces/convert/NumberConverter:configureCurrency	(Ljava/text/NumberFormat;)V
    //   87: aload_0
    //   88: aload 5
    //   90: invokespecial 367	javax/faces/convert/NumberConverter:configureFormatter	(Ljava/text/NumberFormat;)V
    //   93: aload 5
    //   95: aload_3
    //   96: invokevirtual 352	java/text/NumberFormat:format	(Ljava/lang/Object;)Ljava/lang/String;
    //   99: areturn
    //   100: astore 4
    //   102: new 192	javax/faces/convert/ConverterException
    //   105: dup
    //   106: aload_1
    //   107: ldc 12
    //   109: iconst_2
    //   110: anewarray 180	java/lang/Object
    //   113: dup
    //   114: iconst_0
    //   115: aload_3
    //   116: aastore
    //   117: dup
    //   118: iconst_1
    //   119: aload_1
    //   120: aload_2
    //   121: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   124: aastore
    //   125: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   128: aload 4
    //   130: invokespecial 361	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;Ljava/lang/Throwable;)V
    //   133: athrow
    //   134: astore 4
    //   136: new 192	javax/faces/convert/ConverterException
    //   139: dup
    //   140: aload_1
    //   141: ldc 12
    //   143: iconst_2
    //   144: anewarray 180	java/lang/Object
    //   147: dup
    //   148: iconst_0
    //   149: aload_3
    //   150: aastore
    //   151: dup
    //   152: iconst_1
    //   153: aload_1
    //   154: aload_2
    //   155: invokestatic 362	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   158: aastore
    //   159: invokestatic 363	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   162: aload 4
    //   164: invokespecial 361	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;Ljava/lang/Throwable;)V
    //   167: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   16	22	100	javax/faces/convert/ConverterException
    //   23	34	100	javax/faces/convert/ConverterException
    //   35	99	100	javax/faces/convert/ConverterException
    //   16	22	134	java/lang/Exception
    //   23	34	134	java/lang/Exception
    //   35	99	134	java/lang/Exception } 
  private void configureCurrency(NumberFormat formatter) throws Exception { String code = null;
    String symbol = null;

    if ((this.currencyCode == null) && (this.currencySymbol == null)) {
      return;
    }

    if ((this.currencyCode != null) && (this.currencySymbol != null))
      if (currencyClass != null)
        code = this.currencyCode;
      else
        symbol = this.currencySymbol;
    else if (this.currencyCode == null) {
      symbol = this.currencySymbol;
    }
    else if (currencyClass != null)
      code = this.currencyCode;
    else {
      symbol = this.currencyCode;
    }

    if (code != null) {
      Object[] methodArgs = new Object[1];

      Method m = currencyClass.getMethod("getInstance", GET_INSTANCE_PARAM_TYPES);

      methodArgs[0] = code;
      Object currency = m.invoke(null, methodArgs);

      Class[] paramTypes = new Class[1];
      paramTypes[0] = currencyClass;
      Class numberFormatClass = Class.forName("java.text.NumberFormat");
      m = numberFormatClass.getMethod("setCurrency", paramTypes);
      methodArgs[0] = currency;
      m.invoke(formatter, methodArgs);
    }
    else
    {
      DecimalFormat df = (DecimalFormat)formatter;
      DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
      dfs.setCurrencySymbol(symbol);
      df.setDecimalFormatSymbols(dfs);
    }
  }

  private void configureFormatter(NumberFormat formatter)
  {
    formatter.setGroupingUsed(this.groupingUsed);
    if (this.maxIntegerDigitsSpecified)
      formatter.setMaximumIntegerDigits(this.maxIntegerDigits);

    if (this.minIntegerDigitsSpecified)
      formatter.setMinimumIntegerDigits(this.minIntegerDigits);

    if (this.maxFractionDigitsSpecified)
      formatter.setMaximumFractionDigits(this.maxFractionDigits);

    if (this.minFractionDigitsSpecified)
      formatter.setMinimumFractionDigits(this.minFractionDigits);
  }

  private Locale getLocale(FacesContext context)
  {
    Locale locale = this.locale;
    if (locale == null)
      locale = context.getViewRoot().getLocale();

    return locale;
  }

  private NumberFormat getNumberFormat(Locale locale)
  {
    if ((this.pattern == null) && (this.type == null)) {
      throw new IllegalArgumentException("Either pattern or type must be specified.");
    }

    if (this.pattern != null) {
      DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
      return new DecimalFormat(this.pattern, symbols);
    }

    if (this.type.equals("currency"))
      return NumberFormat.getCurrencyInstance(locale);
    if (this.type.equals("number"))
      return NumberFormat.getNumberInstance(locale);
    if (this.type.equals("percent")) {
      return NumberFormat.getPercentInstance(locale);
    }

    throw new ConverterException(new IllegalArgumentException(this.type));
  }

  public Object saveState(FacesContext context)
  {
    Object[] values = new Object[15];
    values[0] = this.currencyCode;
    values[1] = this.currencySymbol;
    values[2] = ((isGroupingUsed()) ? Boolean.TRUE : Boolean.FALSE);
    values[3] = ((isIntegerOnly()) ? Boolean.TRUE : Boolean.FALSE);
    values[4] = new Integer(this.maxFractionDigits);
    values[5] = ((this.maxFractionDigitsSpecified) ? Boolean.TRUE : Boolean.FALSE);
    values[6] = new Integer(this.maxIntegerDigits);
    values[7] = ((this.maxIntegerDigitsSpecified) ? Boolean.TRUE : Boolean.FALSE);
    values[8] = new Integer(this.minFractionDigits);
    values[9] = ((this.minFractionDigitsSpecified) ? Boolean.TRUE : Boolean.FALSE);
    values[10] = new Integer(this.minIntegerDigits);
    values[11] = ((this.minIntegerDigitsSpecified) ? Boolean.TRUE : Boolean.FALSE);
    values[12] = this.locale;
    values[13] = this.pattern;
    values[14] = this.type;
    return values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    Object[] values = (Object[])(Object[])state;
    this.currencyCode = ((String)values[0]);
    this.currencySymbol = ((String)values[1]);
    this.groupingUsed = ((Boolean)values[2]).booleanValue();
    this.integerOnly = ((Boolean)values[3]).booleanValue();
    this.maxFractionDigits = ((Integer)values[4]).intValue();
    this.maxFractionDigitsSpecified = ((Boolean)values[5]).booleanValue();
    this.maxIntegerDigits = ((Integer)values[6]).intValue();
    this.maxIntegerDigitsSpecified = ((Boolean)values[7]).booleanValue();
    this.minFractionDigits = ((Integer)values[8]).intValue();
    this.minFractionDigitsSpecified = ((Boolean)values[9]).booleanValue();
    this.minIntegerDigits = ((Integer)values[10]).intValue();
    this.minIntegerDigitsSpecified = ((Boolean)values[11]).booleanValue();
    this.locale = ((Locale)values[12]);
    this.pattern = ((String)values[13]);
    this.type = ((String)values[14]);
  }

  public boolean isTransient()
  {
    return this.transientFlag;
  }

  public void setTransient(boolean transientFlag)
  {
    this.transientFlag = transientFlag;
  }

  static
  {
    try
    {
      currencyClass = Class.forName("java.util.Currency");
    }
    catch (Exception cnfe)
    {
    }

    GET_INSTANCE_PARAM_TYPES = { String.class };
  }
}