package javax.faces.convert;

import java.math.BigDecimal;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class BigDecimalConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.BigDecimal";
  public static final String DECIMAL_ID = "javax.faces.converter.BigDecimalConverter.DECIMAL";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return new BigDecimal(value);
    } catch (NumberFormatException nfe) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.BigDecimalConverter.DECIMAL", new Object[] { value, "198.23", MessageFactory.getLabel(context, component) }));
    }
    catch (Exception e)
    {
      throw new ConverterException(e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null) {
      return "";
    }

    if (value instanceof String)
      return ((String)value);

    try
    {
      return ((BigDecimal)value).toString();
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }
}