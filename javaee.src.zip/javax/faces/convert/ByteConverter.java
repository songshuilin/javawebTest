package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class ByteConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.Byte";
  public static final String BYTE_ID = "javax.faces.converter.ByteConverter.BYTE";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return Byte.valueOf(value);
    } catch (NumberFormatException nfe) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.ByteConverter.BYTE", new Object[] { value, "254", MessageFactory.getLabel(context, component) }));
    }
    catch (Exception e)
    {
      throw new ConverterException(e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null) {
      return "";
    }

    if (value instanceof String)
      return ((String)value);

    try
    {
      return Byte.toString(((Byte)value).byteValue());
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }
}