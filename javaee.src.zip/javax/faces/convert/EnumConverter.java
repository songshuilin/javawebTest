package javax.faces.convert;

import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class EnumConverter
  implements Converter, StateHolder
{
  public static final String CONVERTER_ID = "javax.faces.Enum";
  public static final String ENUM_ID = "javax.faces.converter.EnumConverter.ENUM";
  public static final String ENUM_NO_CLASS_ID = "javax.faces.converter.EnumConverter.ENUM_NO_CLASS";
  private Class targetClass;
  private transient boolean isTransient = false;

  public EnumConverter(Class targetClass)
  {
    this.targetClass = targetClass;
  }

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return Enum.valueOf(this.targetClass, value);
    } catch (IllegalArgumentException iae) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.EnumConverter.ENUM", new Object[] { value, value, MessageFactory.getLabel(context, component) }));
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    return ((value == null) ? "" : value.toString());
  }

  public void restoreState(FacesContext facesContext, Object object)
  {
    this.targetClass = ((Class)object);
  }

  public Object saveState(FacesContext facesContext) {
    return this.targetClass;
  }

  public void setTransient(boolean b)
  {
    this.isTransient = b;
  }

  public boolean isTransient() {
    return this.isTransient;
  }
}