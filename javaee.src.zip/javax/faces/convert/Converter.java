package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public abstract interface Converter
{
  public abstract Object getAsObject(FacesContext paramFacesContext, UIComponent paramUIComponent, String paramString);

  public abstract String getAsString(FacesContext paramFacesContext, UIComponent paramUIComponent, Object paramObject);
}