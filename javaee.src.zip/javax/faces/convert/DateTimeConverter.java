package javax.faces.convert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import javax.faces.component.StateHolder;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

public class DateTimeConverter
  implements Converter, StateHolder
{
  public static final String CONVERTER_ID = "javax.faces.DateTime";
  public static final String DATE_ID = "javax.faces.converter.DateTimeConverter.DATE";
  public static final String TIME_ID = "javax.faces.converter.DateTimeConverter.TIME";
  public static final String DATETIME_ID = "javax.faces.converter.DateTimeConverter.DATETIME";
  public static final String STRING_ID = "javax.faces.converter.STRING";
  private static final TimeZone DEFAULT_TIME_ZONE = TimeZone.getTimeZone("GMT");
  private String dateStyle;
  private Locale locale;
  private String pattern;
  private String timeStyle;
  private TimeZone timeZone;
  private String type;
  private boolean transientFlag;

  public DateTimeConverter()
  {
    this.dateStyle = "default";
    this.locale = null;
    this.pattern = null;
    this.timeStyle = "default";
    this.timeZone = DEFAULT_TIME_ZONE;
    this.type = "date";

    this.transientFlag = false;
  }

  public String getDateStyle()
  {
    return this.dateStyle;
  }

  public void setDateStyle(String dateStyle)
  {
    this.dateStyle = dateStyle;
  }

  public Locale getLocale()
  {
    if (this.locale == null) {
      this.locale = getLocale(FacesContext.getCurrentInstance());
    }

    return this.locale;
  }

  public void setLocale(Locale locale)
  {
    this.locale = locale;
  }

  public String getPattern()
  {
    return this.pattern;
  }

  public void setPattern(String pattern)
  {
    this.pattern = pattern;
  }

  public String getTimeStyle()
  {
    return this.timeStyle;
  }

  public void setTimeStyle(String timeStyle)
  {
    this.timeStyle = timeStyle;
  }

  public TimeZone getTimeZone()
  {
    return this.timeZone;
  }

  public void setTimeZone(TimeZone timeZone)
  {
    this.timeZone = timeZone;
  }

  public String getType()
  {
    return this.type;
  }

  public void setType(String type)
  {
    this.type = type; } 
  // ERROR //
  public Object getAsObject(FacesContext context, javax.faces.component.UIComponent component, String value) { // Byte code:
    //   0: aload_1
    //   1: ifnull +7 -> 8
    //   4: aload_2
    //   5: ifnonnull +11 -> 16
    //   8: new 133	java/lang/NullPointerException
    //   11: dup
    //   12: invokespecial 238	java/lang/NullPointerException:<init>	()V
    //   15: athrow
    //   16: aconst_null
    //   17: astore 4
    //   19: aconst_null
    //   20: astore 5
    //   22: aload_3
    //   23: ifnonnull +5 -> 28
    //   26: aconst_null
    //   27: areturn
    //   28: aload_3
    //   29: invokevirtual 242	java/lang/String:trim	()Ljava/lang/String;
    //   32: astore_3
    //   33: aload_3
    //   34: invokevirtual 240	java/lang/String:length	()I
    //   37: iconst_1
    //   38: if_icmpge +5 -> 43
    //   41: aconst_null
    //   42: areturn
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial 266	javax/faces/convert/DateTimeConverter:getLocale	(Ljavax/faces/context/FacesContext;)Ljava/util/Locale;
    //   48: astore 6
    //   50: aload_0
    //   51: aload_1
    //   52: aload 6
    //   54: invokespecial 267	javax/faces/convert/DateTimeConverter:getDateFormat	(Ljavax/faces/context/FacesContext;Ljava/util/Locale;)Ljava/text/DateFormat;
    //   57: astore 5
    //   59: aconst_null
    //   60: aload_0
    //   61: getfield 236	javax/faces/convert/DateTimeConverter:timeZone	Ljava/util/TimeZone;
    //   64: if_acmpeq +12 -> 76
    //   67: aload 5
    //   69: aload_0
    //   70: getfield 236	javax/faces/convert/DateTimeConverter:timeZone	Ljava/util/TimeZone;
    //   73: invokevirtual 248	java/text/DateFormat:setTimeZone	(Ljava/util/TimeZone;)V
    //   76: aload 5
    //   78: aload_3
    //   79: invokevirtual 254	java/text/DateFormat:parse	(Ljava/lang/String;)Ljava/util/Date;
    //   82: astore 4
    //   84: goto +205 -> 289
    //   87: astore 6
    //   89: aload_0
    //   90: getfield 233	javax/faces/convert/DateTimeConverter:type	Ljava/lang/String;
    //   93: ldc 8
    //   95: invokevirtual 241	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   98: ifeq +51 -> 149
    //   101: new 148	javax/faces/convert/ConverterException
    //   104: dup
    //   105: aload_1
    //   106: ldc 11
    //   108: iconst_3
    //   109: anewarray 134	java/lang/Object
    //   112: dup
    //   113: iconst_0
    //   114: aload_3
    //   115: aastore
    //   116: dup
    //   117: iconst_1
    //   118: aload 5
    //   120: new 141	java/util/Date
    //   123: dup
    //   124: invokestatic 246	java/lang/System:currentTimeMillis	()J
    //   127: invokespecial 256	java/util/Date:<init>	(J)V
    //   130: invokevirtual 250	java/text/DateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
    //   133: aastore
    //   134: dup
    //   135: iconst_2
    //   136: aload_1
    //   137: aload_2
    //   138: invokestatic 268	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   141: aastore
    //   142: invokestatic 269	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   145: invokespecial 263	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   148: athrow
    //   149: aload_0
    //   150: getfield 233	javax/faces/convert/DateTimeConverter:type	Ljava/lang/String;
    //   153: ldc 18
    //   155: invokevirtual 241	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   158: ifeq +51 -> 209
    //   161: new 148	javax/faces/convert/ConverterException
    //   164: dup
    //   165: aload_1
    //   166: ldc 13
    //   168: iconst_3
    //   169: anewarray 134	java/lang/Object
    //   172: dup
    //   173: iconst_0
    //   174: aload_3
    //   175: aastore
    //   176: dup
    //   177: iconst_1
    //   178: aload 5
    //   180: new 141	java/util/Date
    //   183: dup
    //   184: invokestatic 246	java/lang/System:currentTimeMillis	()J
    //   187: invokespecial 256	java/util/Date:<init>	(J)V
    //   190: invokevirtual 250	java/text/DateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
    //   193: aastore
    //   194: dup
    //   195: iconst_2
    //   196: aload_1
    //   197: aload_2
    //   198: invokestatic 268	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   201: aastore
    //   202: invokestatic 269	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   205: invokespecial 263	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   208: athrow
    //   209: aload_0
    //   210: getfield 233	javax/faces/convert/DateTimeConverter:type	Ljava/lang/String;
    //   213: ldc 7
    //   215: invokevirtual 241	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   218: ifeq +51 -> 269
    //   221: new 148	javax/faces/convert/ConverterException
    //   224: dup
    //   225: aload_1
    //   226: ldc 12
    //   228: iconst_3
    //   229: anewarray 134	java/lang/Object
    //   232: dup
    //   233: iconst_0
    //   234: aload_3
    //   235: aastore
    //   236: dup
    //   237: iconst_1
    //   238: aload 5
    //   240: new 141	java/util/Date
    //   243: dup
    //   244: invokestatic 246	java/lang/System:currentTimeMillis	()J
    //   247: invokespecial 256	java/util/Date:<init>	(J)V
    //   250: invokevirtual 250	java/text/DateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
    //   253: aastore
    //   254: dup
    //   255: iconst_2
    //   256: aload_1
    //   257: aload_2
    //   258: invokestatic 268	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   261: aastore
    //   262: invokestatic 269	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   265: invokespecial 263	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;)V
    //   268: athrow
    //   269: goto +20 -> 289
    //   272: astore 6
    //   274: aload 6
    //   276: athrow
    //   277: astore 6
    //   279: new 148	javax/faces/convert/ConverterException
    //   282: dup
    //   283: aload 6
    //   285: invokespecial 262	javax/faces/convert/ConverterException:<init>	(Ljava/lang/Throwable;)V
    //   288: athrow
    //   289: aload 4
    //   291: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   22	27	87	java/text/ParseException
    //   28	42	87	java/text/ParseException
    //   43	84	87	java/text/ParseException
    //   22	27	272	javax/faces/convert/ConverterException
    //   28	42	272	javax/faces/convert/ConverterException
    //   43	84	272	javax/faces/convert/ConverterException
    //   22	27	277	java/lang/Exception
    //   28	42	277	java/lang/Exception
    //   43	84	277	java/lang/Exception } 
  // ERROR //
  public String getAsString(FacesContext context, javax.faces.component.UIComponent component, Object value) { // Byte code:
    //   0: aload_1
    //   1: ifnull +7 -> 8
    //   4: aload_2
    //   5: ifnonnull +11 -> 16
    //   8: new 133	java/lang/NullPointerException
    //   11: dup
    //   12: invokespecial 238	java/lang/NullPointerException:<init>	()V
    //   15: athrow
    //   16: aload_3
    //   17: ifnonnull +6 -> 23
    //   20: ldc 1
    //   22: areturn
    //   23: aload_3
    //   24: instanceof 135
    //   27: ifeq +8 -> 35
    //   30: aload_3
    //   31: checkcast 135	java/lang/String
    //   34: areturn
    //   35: aload_0
    //   36: aload_1
    //   37: invokespecial 266	javax/faces/convert/DateTimeConverter:getLocale	(Ljavax/faces/context/FacesContext;)Ljava/util/Locale;
    //   40: astore 4
    //   42: aload_0
    //   43: aload_1
    //   44: aload 4
    //   46: invokespecial 267	javax/faces/convert/DateTimeConverter:getDateFormat	(Ljavax/faces/context/FacesContext;Ljava/util/Locale;)Ljava/text/DateFormat;
    //   49: astore 5
    //   51: aconst_null
    //   52: aload_0
    //   53: getfield 236	javax/faces/convert/DateTimeConverter:timeZone	Ljava/util/TimeZone;
    //   56: if_acmpeq +12 -> 68
    //   59: aload 5
    //   61: aload_0
    //   62: getfield 236	javax/faces/convert/DateTimeConverter:timeZone	Ljava/util/TimeZone;
    //   65: invokevirtual 248	java/text/DateFormat:setTimeZone	(Ljava/util/TimeZone;)V
    //   68: aload 5
    //   70: aload_3
    //   71: invokevirtual 249	java/text/DateFormat:format	(Ljava/lang/Object;)Ljava/lang/String;
    //   74: areturn
    //   75: astore 4
    //   77: new 148	javax/faces/convert/ConverterException
    //   80: dup
    //   81: aload_1
    //   82: ldc 14
    //   84: iconst_2
    //   85: anewarray 134	java/lang/Object
    //   88: dup
    //   89: iconst_0
    //   90: aload_3
    //   91: aastore
    //   92: dup
    //   93: iconst_1
    //   94: aload_1
    //   95: aload_2
    //   96: invokestatic 268	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   99: aastore
    //   100: invokestatic 269	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   103: aload 4
    //   105: invokespecial 264	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;Ljava/lang/Throwable;)V
    //   108: athrow
    //   109: astore 4
    //   111: new 148	javax/faces/convert/ConverterException
    //   114: dup
    //   115: aload_1
    //   116: ldc 14
    //   118: iconst_2
    //   119: anewarray 134	java/lang/Object
    //   122: dup
    //   123: iconst_0
    //   124: aload_3
    //   125: aastore
    //   126: dup
    //   127: iconst_1
    //   128: aload_1
    //   129: aload_2
    //   130: invokestatic 268	javax/faces/convert/MessageFactory:getLabel	(Ljavax/faces/context/FacesContext;Ljavax/faces/component/UIComponent;)Ljava/lang/Object;
    //   133: aastore
    //   134: invokestatic 269	javax/faces/convert/MessageFactory:getMessage	(Ljavax/faces/context/FacesContext;Ljava/lang/String;[Ljava/lang/Object;)Ljavax/faces/application/FacesMessage;
    //   137: aload 4
    //   139: invokespecial 264	javax/faces/convert/ConverterException:<init>	(Ljavax/faces/application/FacesMessage;Ljava/lang/Throwable;)V
    //   142: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   16	22	75	javax/faces/convert/ConverterException
    //   23	34	75	javax/faces/convert/ConverterException
    //   35	74	75	javax/faces/convert/ConverterException
    //   16	22	109	java/lang/Exception
    //   23	34	109	java/lang/Exception
    //   35	74	109	java/lang/Exception } 
  private DateFormat getDateFormat(FacesContext context, Locale locale) { if ((this.pattern == null) && (this.type == null)) {
      throw new IllegalArgumentException("Either pattern or type must be specified.");
    }

    DateFormat df = null;
    if (this.pattern != null)
      df = new SimpleDateFormat(this.pattern, locale);
    else if (this.type.equals("both")) {
      df = DateFormat.getDateTimeInstance(getStyle(this.dateStyle), getStyle(this.timeStyle), locale);
    }
    else if (this.type.equals("date"))
      df = DateFormat.getDateInstance(getStyle(this.dateStyle), locale);
    else if (this.type.equals("time")) {
      df = DateFormat.getTimeInstance(getStyle(this.timeStyle), locale);
    }
    else
      throw new IllegalArgumentException("Invalid type: " + this.type);

    df.setLenient(false);
    return df;
  }

  private Locale getLocale(FacesContext context)
  {
    Locale locale = this.locale;
    if (locale == null)
      locale = context.getViewRoot().getLocale();

    return locale;
  }

  private int getStyle(String name)
  {
    if (name.equals("default"))
      return 2;
    if (name.equals("short"))
      return 3;
    if (name.equals("medium"))
      return 2;
    if (name.equals("long"))
      return 1;
    if (name.equals("full")) {
      return 0;
    }

    throw new ConverterException("Invalid style '" + name + "'");
  }

  public Object saveState(FacesContext context)
  {
    Object[] values = new Object[6];
    values[0] = this.dateStyle;
    values[1] = this.locale;
    values[2] = this.pattern;
    values[3] = this.timeStyle;
    values[4] = this.timeZone;
    values[5] = this.type;
    return values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    Object[] values = (Object[])(Object[])state;
    this.dateStyle = ((String)values[0]);
    this.locale = ((Locale)values[1]);
    this.pattern = ((String)values[2]);
    this.timeStyle = ((String)values[3]);
    this.timeZone = ((TimeZone)values[4]);
    this.type = ((String)values[5]);
  }

  public boolean isTransient()
  {
    return this.transientFlag;
  }

  public void setTransient(boolean transientFlag)
  {
    this.transientFlag = transientFlag;
  }
}