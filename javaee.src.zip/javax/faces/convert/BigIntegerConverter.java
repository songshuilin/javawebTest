package javax.faces.convert;

import java.math.BigInteger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class BigIntegerConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.BigInteger";
  public static final String BIGINTEGER_ID = "javax.faces.converter.BigIntegerConverter.BIGINTEGER";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return new BigInteger(value);
    } catch (NumberFormatException nfe) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.BigIntegerConverter.BIGINTEGER", new Object[] { value, "9876", MessageFactory.getLabel(context, component) }));
    }
    catch (Exception e)
    {
      throw new ConverterException(e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null) {
      return "";
    }

    if (value instanceof String)
      return ((String)value);

    try
    {
      return ((BigInteger)value).toString();
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }
}