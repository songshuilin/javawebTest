package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class DoubleConverter
  implements Converter
{
  public static final String CONVERTER_ID = "javax.faces.DoubleTime";
  public static final String DOUBLE_ID = "javax.faces.converter.DoubleConverter.DOUBLE";
  public static final String STRING_ID = "javax.faces.converter.STRING";

  public Object getAsObject(FacesContext context, UIComponent component, String value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null)
      return null;

    value = value.trim();
    if (value.length() < 1)
      return null;

    try
    {
      return Double.valueOf(value);
    } catch (NumberFormatException nfe) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.DoubleConverter.DOUBLE", new Object[] { value, "1999999", MessageFactory.getLabel(context, component) }));
    }
    catch (Exception e)
    {
      throw new ConverterException(e);
    }
  }

  public String getAsString(FacesContext context, UIComponent component, Object value)
  {
    if ((context == null) || (component == null)) {
      throw new NullPointerException();
    }

    if (value == null) {
      return "";
    }

    if (value instanceof String)
      return ((String)value);

    try
    {
      return Double.toString(((Double)value).doubleValue());
    } catch (Exception e) {
      throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] { value, MessageFactory.getLabel(context, component) }), e);
    }
  }
}