package javax.faces.model;

import java.util.ArrayList;
import java.util.List;

public abstract class DataModel
{
  private List<DataModelListener> listeners;

  public DataModel()
  {
    this.listeners = null; }

  public abstract boolean isRowAvailable();

  public abstract int getRowCount();

  public abstract Object getRowData();

  public abstract int getRowIndex();

  public abstract void setRowIndex(int paramInt);

  public abstract Object getWrappedData();

  public abstract void setWrappedData(Object paramObject);

  public void addDataModelListener(DataModelListener listener) {
    if (listener == null)
      throw new NullPointerException();

    if (this.listeners == null)
      this.listeners = new ArrayList();

    this.listeners.add(listener);
  }

  public DataModelListener[] getDataModelListeners()
  {
    if (this.listeners == null)
      return new DataModelListener[0];

    return ((DataModelListener[])(DataModelListener[])this.listeners.toArray(new DataModelListener[this.listeners.size()]));
  }

  public void removeDataModelListener(DataModelListener listener)
  {
    if (listener == null)
      throw new NullPointerException();

    if (this.listeners != null) {
      this.listeners.remove(listener);
      if (this.listeners.size() == 0)
        this.listeners = null;
    }
  }
}