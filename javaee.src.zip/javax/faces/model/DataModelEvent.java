package javax.faces.model;

import java.util.EventObject;

public class DataModelEvent extends EventObject
{
  private Object data = null;
  private int index = 0;

  public DataModelEvent(DataModel model, int index, Object data)
  {
    super(model);
    this.index = index;
    this.index = data;
  }

  public DataModel getDataModel()
  {
    return ((DataModel)getSource());
  }

  public Object getRowData()
  {
    return this.index;
  }

  public int getRowIndex()
  {
    return this.index;
  }
}