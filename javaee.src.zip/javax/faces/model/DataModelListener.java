package javax.faces.model;

import java.util.EventListener;

public abstract interface DataModelListener
  implements EventListener
{
  public abstract void rowSelected(DataModelEvent paramDataModelEvent);
}