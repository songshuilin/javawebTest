package javax.faces.model;

import java.util.SortedMap;
import javax.servlet.jsp.jstl.sql.Result;

public class ResultDataModel extends DataModel
{
  private int index;
  private Result result;
  private SortedMap[] rows;

  public ResultDataModel()
  {
    this(null);
  }

  public ResultDataModel(Result result)
  {
    this.index = -1;

    this.result = null;

    this.rows = null;

    setWrappedData(result);
  }

  public boolean isRowAvailable()
  {
    if (this.result == null)
      return false;

    return ((this.index >= 0) && (this.index < this.rows.length));
  }

  public int getRowCount()
  {
    if (this.result == null)
      return -1;

    return this.rows.length;
  }

  public Object getRowData()
  {
    if (this.result == null)
      return null;
    if (!(isRowAvailable()))
      throw new IllegalArgumentException();

    return this.rows[this.index];
  }

  public int getRowIndex()
  {
    return this.index;
  }

  public void setRowIndex(int rowIndex)
  {
    if (rowIndex < -1)
      throw new IllegalArgumentException();

    int old = this.index;
    this.index = rowIndex;
    if (this.result == null)
      return;

    DataModelListener[] listeners = getDataModelListeners();
    if ((old != this.index) && (listeners != null)) {
      Object rowData = null;
      if (isRowAvailable())
        rowData = getRowData();

      DataModelEvent event = new DataModelEvent(this, this.index, rowData);

      int n = listeners.length;
      for (int i = 0; i < n; ++i)
        if (null != listeners[i])
          listeners[i].rowSelected(event);
    }
  }

  public Object getWrappedData()
  {
    return this.result;
  }

  public void setWrappedData(Object data)
  {
    if (data == null) {
      this.result = null;
      this.rows = null;
      setRowIndex(-1);
    } else {
      this.result = ((Result)data);
      this.rows = this.result.getRows();
      this.index = -1;
      setRowIndex(0);
    }
  }
}