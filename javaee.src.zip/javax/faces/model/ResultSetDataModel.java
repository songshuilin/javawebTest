package javax.faces.model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import javax.faces.FacesException;

public class ResultSetDataModel extends DataModel
{
  private int index;
  private ResultSetMetaData metadata;
  private ResultSet resultSet;
  private boolean updated;

  public ResultSetDataModel()
  {
    this(null);
  }

  public ResultSetDataModel(ResultSet resultSet)
  {
    this.index = -1;

    this.metadata = null;

    this.resultSet = null;

    this.updated = false;

    setWrappedData(resultSet);
  }

  public boolean isRowAvailable()
  {
    if (this.resultSet == null)
      return false;
    if (this.index < 0)
      return false;

    try
    {
      return (this.resultSet.absolute(this.index + 1));
    }
    catch (SQLException e)
    {
      throw new FacesException(e);
    }
  }

  public int getRowCount()
  {
    return -1;
  }

  public Object getRowData()
  {
    if (this.resultSet == null)
      return null;
    if (!(isRowAvailable()))
      throw new IllegalArgumentException();
    try
    {
      getMetaData();
      return new ResultSetMap(this, String.CASE_INSENSITIVE_ORDER);
    } catch (SQLException e) {
      throw new FacesException(e);
    }
  }

  public int getRowIndex()
  {
    return this.index;
  }

  public void setRowIndex(int rowIndex)
  {
    if (rowIndex < -1) {
      throw new IllegalArgumentException();
    }

    if ((this.updated) && (this.resultSet != null))
      try {
        if (!(this.resultSet.rowDeleted()))
          this.resultSet.updateRow();

        this.updated = false;
      } catch (SQLException e) {
        throw new FacesException(e);
      }


    int old = this.index;
    this.index = rowIndex;
    if (this.resultSet == null)
      return;

    DataModelListener[] listeners = getDataModelListeners();
    if ((old != this.index) && (listeners != null)) {
      Object rowData = null;
      if (isRowAvailable())
        rowData = getRowData();

      DataModelEvent event = new DataModelEvent(this, this.index, rowData);

      int n = listeners.length;
      for (int i = 0; i < n; ++i)
        if (null != listeners[i])
          listeners[i].rowSelected(event);
    }
  }

  public Object getWrappedData()
  {
    return this.resultSet;
  }

  public void setWrappedData(Object data)
  {
    if (data == null) {
      this.metadata = null;
      this.resultSet = null;
      setRowIndex(-1);
    } else {
      this.metadata = null;
      this.resultSet = ((ResultSet)data);
      this.index = -1;
      setRowIndex(0);
    }
  }

  private ResultSetMetaData getMetaData()
  {
    if (this.metadata == null)
      try {
        this.metadata = this.resultSet.getMetaData();
      } catch (SQLException e) {
        throw new FacesException(e);
      }

    return this.metadata;
  }

  private void updated()
  {
    this.updated = true;
  }

  private static class ResultSetEntries extends AbstractSet
  {
    private ResultSetDataModel.ResultSetMap map;

    public ResultSetEntries(ResultSetDataModel.ResultSetMap map)
    {
      this.map = map;
    }

    public boolean add(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public void clear()
    {
      throw new UnsupportedOperationException();
    }

    public boolean contains(Object o) {
      if (o == null)
        throw new NullPointerException();

      if (!(o instanceof Map.Entry))
        return false;

      Map.Entry e = (Map.Entry)o;
      Object k = e.getKey();
      Object v = e.getValue();
      if (!(this.map.containsKey(k)))
        return false;

      if (v == null)
        return (this.map.get(k) == null);

      return v.equals(this.map.get(k));
    }

    public boolean isEmpty()
    {
      return this.map.isEmpty();
    }

    public Iterator iterator() {
      return new ResultSetDataModel.ResultSetEntriesIterator(this.map);
    }

    public boolean remove(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public int size() {
      return this.map.size(); }  } 
  private static class ResultSetEntriesIterator
  implements Iterator { private ResultSetDataModel.ResultSetMap map = null;
    private Iterator keys = null;

    public ResultSetEntriesIterator(ResultSetDataModel.ResultSetMap map) { this.keys = map;
      this.keys = map.keySet().iterator();
    }

    public boolean hasNext()
    {
      return this.keys.hasNext();
    }

    public Object next() {
      Object key = this.keys.next();
      return new ResultSetDataModel.ResultSetEntry(this.keys, key);
    }

    public void remove()
    {
      throw new UnsupportedOperationException();
    }
  }

  private static class ResultSetEntry
  implements Map.Entry
  {
    private ResultSetDataModel.ResultSetMap map;
    private Object key;

    public ResultSetEntry(ResultSetDataModel.ResultSetMap map, Object key)
    {
      this.map = map;
      this.key = key;
    }

    public boolean equals(Object o)
    {
      if (o == null)
        return false;

      if (!(o instanceof Map.Entry))
        return false;

      Map.Entry e = (Map.Entry)o;
      if (this.key == null) {
        if (e.getKey() == null) break label56;
        return false;
      }

      if (!(this.key.equals(e.getKey()))) {
        return false;
      }

      label56: Object v = this.map.get(this.key);
      if (v == null) {
        if (e.getValue() == null) break label98;
        return false;
      }

      label98: return (v.equals(e.getValue()));
    }

    public Object getKey()
    {
      return this.key;
    }

    public Object getValue() {
      return this.map.get(this.key);
    }

    public int hashCode() {
      Object value = this.map.get(this.key);
      return (((this.key == null) ? 0 : this.key.hashCode()) ^ ((value == null) ? 0 : value.hashCode()));
    }

    public Object setValue(Object value)
    {
      Object previous = this.map.get(this.key);
      this.map.put(this.key, value);
      return previous;
    }
  }

  private static class ResultSetKeys extends AbstractSet
  {
    private ResultSetDataModel.ResultSetMap map;

    public ResultSetKeys(ResultSetDataModel.ResultSetMap map)
    {
      this.map = map;
    }

    public boolean add(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public void clear()
    {
      throw new UnsupportedOperationException();
    }

    public boolean contains(Object o) {
      return this.map.containsKey(o);
    }

    public boolean isEmpty() {
      return this.map.isEmpty();
    }

    public Iterator iterator() {
      return new ResultSetDataModel.ResultSetKeysIterator(this.map);
    }

    public boolean remove(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection c)
    {
      throw new UnsupportedOperationException();
    }

    public int size() {
      return this.map.size(); }  }

  private static class ResultSetKeysIterator
  implements Iterator { private Iterator keys = null;

    public ResultSetKeysIterator(ResultSetDataModel.ResultSetMap map) { this.keys = map.realKeys();
    }

    public boolean hasNext()
    {
      return this.keys.hasNext();
    }

    public Object next() {
      return this.keys.next();
    }

    public void remove()
    {
      throw new UnsupportedOperationException();
    }
  }

  private class ResultSetMap extends TreeMap
  {
    private int index;

    public ResultSetMap(, Comparator comparator)
      throws SQLException
    {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: putfield 138	javax/faces/model/ResultSetDataModel$ResultSetMap:this$0	Ljavax/faces/model/ResultSetDataModel;
      //   5: aload_0
      //   6: aload_2
      //   7: invokespecial 142	java/util/TreeMap:<init>	(Ljava/util/Comparator;)V
      //   10: aload_0
      //   11: aload_1
      //   12: invokestatic 147	javax/faces/model/ResultSetDataModel:access$000	(Ljavax/faces/model/ResultSetDataModel;)I
      //   15: putfield 137	javax/faces/model/ResultSetDataModel$ResultSetMap:index	I
      //   18: aload_1
      //   19: invokestatic 149	javax/faces/model/ResultSetDataModel:access$100	(Ljavax/faces/model/ResultSetDataModel;)Ljava/sql/ResultSet;
      //   22: aload_0
      //   23: getfield 137	javax/faces/model/ResultSetDataModel$ResultSetMap:index	I
      //   26: iconst_1
      //   27: iadd
      //   28: invokeinterface 158 2 0
      //   33: pop
      //   34: aload_1
      //   35: invokestatic 150	javax/faces/model/ResultSetDataModel:access$200	(Ljavax/faces/model/ResultSetDataModel;)Ljava/sql/ResultSetMetaData;
      //   38: invokeinterface 161 1 0
      //   43: istore_3
      //   44: iconst_1
      //   45: istore 4
      //   47: iload 4
      //   49: iload_3
      //   50: if_icmpgt +36 -> 86
      //   53: aload_0
      //   54: aload_1
      //   55: invokestatic 150	javax/faces/model/ResultSetDataModel:access$200	(Ljavax/faces/model/ResultSetDataModel;)Ljava/sql/ResultSetMetaData;
      //   58: iload 4
      //   60: invokeinterface 162 2 0
      //   65: aload_1
      //   66: invokestatic 150	javax/faces/model/ResultSetDataModel:access$200	(Ljavax/faces/model/ResultSetDataModel;)Ljava/sql/ResultSetMetaData;
      //   69: iload 4
      //   71: invokeinterface 162 2 0
      //   76: invokespecial 145	java/util/TreeMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   79: pop
      //   80: iinc 4 1
      //   83: goto -36 -> 47
      //   86: return
    }

    public void clear()
    {
      throw new UnsupportedOperationException();
    }

    public boolean containsValue() {
      for (Iterator i = entrySet().iterator(); i.hasNext(); ) {
        Map.Entry entry = (Map.Entry)i.next();
        Object contained = entry.getValue();
        if (value == null) {
          if (contained != null) continue;
          return true;
        }

        if (value.equals(contained))
          return true;

      }

      return false;
    }

    public Set entrySet() {
      return new ResultSetDataModel.ResultSetEntries(this);
    }

    public Object get() {
      if (!(containsKey(key)))
        return null;
      try
      {
        ResultSetDataModel.access$100(this.this$0).absolute(this.index + 1);
        return ResultSetDataModel.access$100(this.this$0).getObject((String)realKey(key));
      } catch (SQLException e) {
        throw new FacesException(e);
      }
    }

    public Set keySet() {
      return new ResultSetDataModel.ResultSetKeys(this);
    }

    public Object put(, Object value) {
      if (!(containsKey(key)))
        throw new IllegalArgumentException();

      if (!(key instanceof String))
        throw new IllegalArgumentException();
      try
      {
        ResultSetDataModel.access$100(this.this$0).absolute(this.index + 1);
        Object previous = ResultSetDataModel.access$100(this.this$0).getObject((String)realKey(key));
        if ((previous == null) && (value == null))
          return previous;
        if ((previous != null) && (value != null) && (previous.equals(value)))
        {
          return previous;
        }
        ResultSetDataModel.access$100(this.this$0).updateObject((String)realKey(key), value);
        ResultSetDataModel.access$300(this.this$0);
        return previous;
      } catch (SQLException e) {
        throw new FacesException(e);
      }
    }

    public void putAll() {
      for (Iterator i = map.entrySet().iterator(); i.hasNext(); ) {
        Map.Entry entry = (Map.Entry)i.next();
        put(entry.getKey(), entry.getValue());
      }
    }

    public Object remove()
    {
      throw new UnsupportedOperationException();
    }

    public Collection values() {
      return new ResultSetDataModel.ResultSetValues(this);
    }

    Object realKey() {
      return super.get(key);
    }

    Iterator realKeys() {
      return super.keySet().iterator();
    }
  }

  private static class ResultSetValues extends AbstractCollection
  {
    private ResultSetDataModel.ResultSetMap map;

    public ResultSetValues(ResultSetDataModel.ResultSetMap map)
    {
      this.map = map;
    }

    public boolean add(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public void clear() {
      throw new UnsupportedOperationException();
    }

    public boolean contains(Object value) {
      return this.map.containsValue(value);
    }

    public Iterator iterator() {
      return new ResultSetDataModel.ResultSetValuesIterator(this.map);
    }

    public boolean remove(Object o) {
      throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public int size() {
      return this.map.size();
    }
  }

  private static class ResultSetValuesIterator
  implements Iterator
  {
    private ResultSetDataModel.ResultSetMap map;
    private Iterator keys;

    public ResultSetValuesIterator(ResultSetDataModel.ResultSetMap map)
    {
      this.map = map;
      this.keys = map.keySet().iterator();
    }

    public boolean hasNext()
    {
      return this.keys.hasNext();
    }

    public Object next() {
      return this.map.get(this.keys.next());
    }

    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
}