package javax.faces.event;

public abstract interface ActionListener
  implements FacesListener
{
  public abstract void processAction(ActionEvent paramActionEvent)
    throws AbortProcessingException;
}