package javax.faces.event;

public abstract interface ValueChangeListener
  implements FacesListener
{
  public abstract void processValueChange(ValueChangeEvent paramValueChangeEvent)
    throws AbortProcessingException;
}