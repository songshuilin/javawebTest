package javax.faces.event;

import java.io.Serializable;
import java.util.EventListener;

public abstract interface PhaseListener
  implements EventListener, Serializable
{
  public abstract void afterPhase(PhaseEvent paramPhaseEvent);

  public abstract void beforePhase(PhaseEvent paramPhaseEvent);

  public abstract PhaseId getPhaseId();
}