package javax.faces.event;

import java.util.EventListener;

public abstract interface FacesListener
  implements EventListener
{
}