package javax.faces.render;

import java.util.Iterator;
import javax.faces.context.FacesContext;

public abstract class RenderKitFactory
{
  public static final String HTML_BASIC_RENDER_KIT = "HTML_BASIC";

  public abstract void addRenderKit(String paramString, RenderKit paramRenderKit);

  public abstract RenderKit getRenderKit(FacesContext paramFacesContext, String paramString);

  public abstract Iterator<String> getRenderKitIds();
}