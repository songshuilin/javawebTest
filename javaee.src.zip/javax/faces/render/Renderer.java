package javax.faces.render;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;

public abstract class Renderer
{
  public void decode(FacesContext context, UIComponent component)
  {
    if ((null == context) || (null == component))
      throw new NullPointerException();
  }

  public void encodeBegin(FacesContext context, UIComponent component)
    throws IOException
  {
    if ((null == context) || (null == component))
      throw new NullPointerException();
  }

  public void encodeChildren(FacesContext context, UIComponent component)
    throws IOException
  {
    if ((context == null) || (component == null))
      throw new NullPointerException();

    if (component.getChildCount() > 0) {
      Iterator kids = component.getChildren().iterator();
      while (kids.hasNext()) {
        UIComponent kid = (UIComponent)kids.next();
        kid.encodeAll(context);
      }
    }
  }

  public void encodeEnd(FacesContext context, UIComponent component)
    throws IOException
  {
    if ((null == context) || (null == component))
      throw new NullPointerException();
  }

  public String convertClientId(FacesContext context, String clientId)
  {
    if ((context == null) || (clientId == null))
      throw new NullPointerException();

    return clientId;
  }

  public boolean getRendersChildren()
  {
    return false;
  }

  public Object getConvertedValue(FacesContext context, UIComponent component, Object submittedValue)
    throws ConverterException
  {
    if ((context == null) || (component == null))
      throw new NullPointerException();

    return submittedValue;
  }
}