package javax.faces.render;

import java.io.OutputStream;
import java.io.Writer;
import javax.faces.context.ResponseStream;
import javax.faces.context.ResponseWriter;

public abstract class RenderKit
{
  public abstract void addRenderer(String paramString1, String paramString2, Renderer paramRenderer);

  public abstract Renderer getRenderer(String paramString1, String paramString2);

  public abstract ResponseStateManager getResponseStateManager();

  public abstract ResponseWriter createResponseWriter(Writer paramWriter, String paramString1, String paramString2);

  public abstract ResponseStream createResponseStream(OutputStream paramOutputStream);
}