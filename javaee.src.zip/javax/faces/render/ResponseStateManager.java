package javax.faces.render;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.Application;
import javax.faces.application.StateManager;
import javax.faces.application.StateManager.SerializedView;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public abstract class ResponseStateManager
{
  private static Logger log = Logger.getLogger("javax.faces.render");
  public static final String RENDER_KIT_ID_PARAM = "javax.faces.RenderKitId";
  public static final String VIEW_STATE_PARAM = "javax.faces.ViewState";

  public void writeState(FacesContext context, Object state)
    throws IOException
  {
    StateManager.SerializedView view = null;
    if (state instanceof StateManager.SerializedView) {
      view = (StateManager.SerializedView)state;
    }
    else if (state instanceof Object[]) {
      Object[] stateArray = (Object[])(Object[])state;
      if (2 == stateArray.length) {
        StateManager stateManager = context.getApplication().getStateManager();

        stateManager.getClass(); view = new StateManager.SerializedView(stateManager, stateArray[0], stateArray[1]);
      }
      else
      {
        if (log.isLoggable(Level.SEVERE))
          log.log(Level.SEVERE, "State is not an expected array of length 2.");

        throw new IOException("State is not an expected array of length 2.");
      }
    }
    else {
      if (log.isLoggable(Level.SEVERE))
        log.log(Level.SEVERE, "State is not an expected array of length 2.");

      throw new IOException("State is not an expected array of length 2.");
    }

    writeState(context, view);
  }

  /**
   * @deprecated
   */
  public void writeState(FacesContext context, StateManager.SerializedView state)
    throws IOException
  {
  }

  public Object getState(FacesContext context, String viewId)
  {
    Object[] stateArray = { getTreeStructureToRestore(context, viewId), getComponentStateToRestore(context) };

    return stateArray;
  }

  /**
   * @deprecated
   */
  public Object getTreeStructureToRestore(FacesContext context, String viewId)
  {
    return null;
  }

  /**
   * @deprecated
   */
  public Object getComponentStateToRestore(FacesContext context)
  {
    return null;
  }

  public boolean isPostback(FacesContext context)
  {
    return (0 < context.getExternalContext().getRequestParameterMap().size());
  }
}