package javax.faces.component;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.FacesEvent;
import javax.faces.event.FacesListener;
import javax.faces.render.RenderKit;
import javax.faces.render.Renderer;

public abstract class UIComponentBase extends UIComponent
{
  private static Logger log;
  private static Map<Class<?>, Map<String, PropertyDescriptor>> descriptors;
  private Map<String, PropertyDescriptor> pdMap = null;
  private static Object[] empty;
  private AttributesMap attributes = null;
  private String clientId = null;
  private String id = null;
  private UIComponent parent = null;
  private boolean rendered = true;
  private boolean renderedSet = false;
  private String rendererType = null;
  private List<UIComponent> children = null;
  private static final String SEPARATOR_STRING = ":";
  private Map<String, UIComponent> facets = null;
  private List<FacesListener> listeners;
  private static final int MY_STATE = 0;
  private static final int CHILD_STATE = 1;
  private Object[] values;
  private boolean transientFlag = false;
  private static final Object[] EMPTY_ARRAY;
  private static final Iterator EMPTY_ITERATOR;

  public UIComponentBase()
  {
    populateDescriptorsMapIfNecessary();
  }

  private void populateDescriptorsMapIfNecessary() {
    Class clazz = getClass();
    this.transientFlag = ((Map)descriptors.get(clazz));
    if (null != this.transientFlag) {
      return;
    }

    PropertyDescriptor[] pd = getPropertyDescriptors();
    if (pd != null) {
      this.transientFlag = new WeakHashMap(pd.length);
      PropertyDescriptor[] arr$ = pd; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { PropertyDescriptor aPd = arr$[i$];
        this.transientFlag.put(aPd.getName(), aPd);
      }
      if (log.isLoggable(Level.FINE)) {
        log.log(Level.FINE, "fine.component.populating_descriptor_map", new Object[] { clazz, Thread.currentThread().getName() });
      }

      Map reCheckMap = (Map)descriptors.get(clazz);

      if (null != reCheckMap)
        return;

      descriptors.put(clazz, this.transientFlag);
    }
  }

  private PropertyDescriptor getPropertyDescriptor(String name)
  {
    if (this.transientFlag != null)
      return ((PropertyDescriptor)this.transientFlag.get(name));

    return null;
  }

  private PropertyDescriptor[] getPropertyDescriptors()
  {
    PropertyDescriptor[] pd = null;
    try {
      pd = Introspector.getBeanInfo(getClass()).getPropertyDescriptors();
    }
    catch (IntrospectionException e) {
      throw new FacesException(e);
    }
    return pd;
  }

  public Map<String, Object> getAttributes()
  {
    if (this.attributes == null)
      this.attributes = new AttributesMap(this, null);

    return this.attributes;
  }

  /**
   * @deprecated
   */
  public ValueBinding getValueBinding(String name)
  {
    if (name == null)
      throw new NullPointerException();

    ValueBinding result = null;
    ValueExpression ve = null;

    if (null != (ve = getValueExpression(name)))
    {
      if (ve.getClass() == ValueExpressionValueBindingAdapter.class) {
        result = ((ValueExpressionValueBindingAdapter)ve).getWrapped();
      }
      else
      {
        result = new ValueBindingValueExpressionAdapter(ve);
      }
    }
    return result;
  }

  /**
   * @deprecated
   */
  public void setValueBinding(String name, ValueBinding binding)
  {
    if (name == null)
      throw new NullPointerException();

    if (binding != null) {
      ValueExpressionValueBindingAdapter adapter = new ValueExpressionValueBindingAdapter(binding);

      setValueExpression(name, adapter);
    }
    else setValueExpression(name, null);
  }

  public ValueExpression getValueExpression(String name)
  {
    return super.getValueExpression(name);
  }

  public void setValueExpression(String name, ValueExpression binding)
  {
    super.setValueExpression(name, binding);
  }

  public String getClientId(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (this.clientId == null) {
      UIComponent parent = getNamingContainer();
      String parentId = null;

      if (parent != null) {
        parentId = parent.getContainerClientId(context);
      }

      this.clientId = this.id;
      if (this.clientId == null)
        this.clientId = context.getViewRoot().createUniqueId();

      if (parentId != null) {
        this.clientId = parentId + ':' + this.clientId;
      }

      Renderer renderer = getRenderer(context);
      if (renderer != null)
        this.clientId = renderer.convertClientId(context, this.clientId);
    }

    return this.clientId;
  }

  private UIComponent getNamingContainer()
  {
    UIComponent namingContainer = getParent();
    while (namingContainer != null) {
      if (namingContainer instanceof NamingContainer)
        return namingContainer;

      namingContainer = namingContainer.getParent();
    }
    return null;
  }

  public String getId()
  {
    return this.id;
  }

  public void setId(String id)
  {
    validateId(id);
    this.id = id;
    this.clientId = null;
  }

  public UIComponent getParent()
  {
    return this.parent;
  }

  public void setParent(UIComponent parent)
  {
    this.parent = parent;
  }

  public boolean isRendered()
  {
    if (this.renderedSet)
      return this.rendered;

    ValueExpression ve = getValueExpression("rendered");
    if (ve != null) {
      boolean result = false;
      try {
        result = !(Boolean.FALSE.equals(ve.getValue(getFacesContext().getELContext())));
      }
      catch (ELException e) {
        throw new FacesException(e);
      }
      return result;
    }
    return this.rendered;
  }

  public void setRendered(boolean rendered)
  {
    this.rendered = rendered;
    this.renderedSet = true;
  }

  public String getRendererType()
  {
    if (this.rendererType != null)
      return this.rendererType;

    ValueExpression ve = getValueExpression("rendererType");
    if (ve != null) {
      String result = null;
      try {
        result = (String)ve.getValue(getFacesContext().getELContext());
      }
      catch (ELException e) {
        throw new FacesException(e);
      }
      return result;
    }
    return null;
  }

  public void setRendererType(String rendererType)
  {
    this.rendererType = rendererType;
  }

  public boolean getRendersChildren()
  {
    boolean result = false;

    Renderer renderer = null;
    if (getRendererType() != null)
      if (null != (renderer = getRenderer(getFacesContext())))
      {
        result = renderer.getRendersChildren();
      }

    return result;
  }

  public List<UIComponent> getChildren()
  {
    if (this.children == null)
      this.children = new ChildrenList(this, null);

    return this.children;
  }

  public int getChildCount()
  {
    if (this.children != null)
      return this.children.size();

    return 0;
  }

  private void eraseParent(UIComponent component)
  {
    UIComponent parent = component.getParent();
    if (parent == null)
      return;

    if (parent.getChildCount() > 0) {
      List children = parent.getChildren();
      int index = children.indexOf(component);
      if (index >= 0) {
        children.remove(index);
        return;
      }
    }
    if (parent.getFacetCount() > 0) {
      Map facets = parent.getFacets();
      Iterator entries = facets.entrySet().iterator();
      while (entries.hasNext()) {
        Map.Entry entry = (Map.Entry)entries.next();
        if (entry.getValue() == component) {
          entries.remove();
          return;
        }
      }

    }

    throw new IllegalStateException("Parent was not null, but this component not related");
  }

  private void validateId(String id)
  {
    if (id == null)
      return;

    int n = id.length();
    if (n < 1)
      throw new IllegalArgumentException();

    for (int i = 0; i < n; ++i) {
      char c = id.charAt(i);
      if (i == 0) {
        if ((Character.isLetter(c)) || (c == '_')) break label104;
        throw new IllegalArgumentException(id);
      }

      label104: if ((!(Character.isLetter(c))) && (!(Character.isDigit(c))) && (c != '-') && (c != '_'))
      {
        throw new IllegalArgumentException(id);
      }
    }
  }

  public UIComponent findComponent(String expr)
  {
    if (expr == null) {
      throw new NullPointerException();
    }

    UIComponent base = this;
    if (expr.charAt(0) == ':')
    {
      while (base.getParent() != null) {
        base = base.getParent();
      }

      expr = expr.substring(1);
    }
    else {
      while (base.getParent() != null) {
        if (base instanceof NamingContainer)
          break;

        base = base.getParent();
      }

    }

    UIComponent result = null;
    String[] segments = expr.split(":");
    int i = 0; int length = segments.length - 1;
    while (i < segments.length)
    {
      result = findComponent(base, segments[i], false);

      if ((i == 0) && (result == null) && (segments[i].equals(base.getId())))
        result = base;

      if ((result == null) && (length > 0))
        throw new IllegalArgumentException(segments[i]);

      base = result;

      ++i; --length;
    }

    return result;
  }

  private UIComponent findComponent(UIComponent base, String id, boolean checkId)
  {
    UIComponent result = null;
    for (Iterator i = base.getFacetsAndChildren(); i.hasNext(); ) {
      UIComponent kid = (UIComponent)i.next();
      if (!(kid instanceof NamingContainer)) {
        if ((checkId) && (id.equals(kid.getId()))) {
          result = kid;
          break;
        }
        result = findComponent(kid, id, checkId);
        if (result == null) continue;
        break;
      }
      if (id.equals(kid.getId())) {
        result = kid;
        break;
      }
    }

    return result;
  }

  public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback)
    throws FacesException
  {
    return super.invokeOnComponent(context, clientId, callback);
  }

  public Map<String, UIComponent> getFacets()
  {
    if (this.facets == null)
      this.facets = new FacetsMap(this, null);

    return this.facets;
  }

  public int getFacetCount()
  {
    if (this.facets != null)
      return this.facets.size();

    return 0;
  }

  public UIComponent getFacet(String name)
  {
    if (this.facets != null)
      return ((UIComponent)this.facets.get(name));

    return null;
  }

  public Iterator<UIComponent> getFacetsAndChildren()
  {
    Iterator result = null;
    int childCount = getChildCount();
    int facetCount = getFacetCount();

    if ((0 == childCount) && (0 == facetCount)) {
      result = EMPTY_ITERATOR;
    }
    else if (0 == childCount) {
      Collection unmodifiable = Collections.unmodifiableCollection(getFacets().values());

      result = unmodifiable.iterator();
    }
    else if (0 == facetCount) {
      List unmodifiable = Collections.unmodifiableList(getChildren());

      result = unmodifiable.iterator();
    }
    else
    {
      result = new FacetsAndChildrenIterator(this);
    }
    return result;
  }

  public void broadcast(FacesEvent event)
    throws AbortProcessingException
  {
    if (event == null)
      throw new NullPointerException();

    if (this.listeners == null) {
      return;
    }

    Iterator iter = this.listeners.iterator();
    while (iter.hasNext()) {
      FacesListener listener = (FacesListener)iter.next();
      if (event.isAppropriateListener(listener))
        event.processListener(listener);
    }
  }

  public void decode(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    String rendererType = getRendererType();
    if (rendererType != null)
      getRenderer(context).decode(context, this);
  }

  public void encodeBegin(FacesContext context)
    throws IOException
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered()))
      return;

    String rendererType = getRendererType();
    if (rendererType != null)
      getRenderer(context).encodeBegin(context, this);
  }

  public void encodeChildren(FacesContext context)
    throws IOException
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered()))
      return;

    String rendererType = getRendererType();
    if (rendererType != null)
      getRenderer(context).encodeChildren(context, this);
  }

  public void encodeEnd(FacesContext context)
    throws IOException
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered()))
      return;

    String rendererType = getRendererType();
    if (rendererType != null)
      getRenderer(context).encodeEnd(context, this);
  }

  protected void addFacesListener(FacesListener listener)
  {
    if (listener == null)
      throw new NullPointerException();

    if (this.listeners == null)
      this.listeners = new ArrayList();

    this.listeners.add(listener);
  }

  protected FacesListener[] getFacesListeners(Class clazz)
  {
    if (clazz == null)
      throw new NullPointerException();

    if (!(FacesListener.class.isAssignableFrom(clazz)))
      throw new IllegalArgumentException();

    if (this.listeners == null) {
      return ((FacesListener[])(FacesListener[])Array.newInstance(clazz, 0));
    }

    List results = new ArrayList();
    Iterator items = this.listeners.iterator();
    while (items.hasNext()) {
      FacesListener item = (FacesListener)items.next();
      if (clazz.isAssignableFrom(item.getClass()))
        results.add(item);

    }

    return ((FacesListener[])(FacesListener[])results.toArray((Object[])(Object[])Array.newInstance(clazz, results.size())));
  }

  protected void removeFacesListener(FacesListener listener)
  {
    if (listener == null)
      throw new NullPointerException();

    if (this.listeners == null)
      return;

    this.listeners.remove(listener);
  }

  public void queueEvent(FacesEvent event)
  {
    if (event == null)
      throw new NullPointerException();

    UIComponent parent = getParent();
    if (parent == null)
      throw new IllegalStateException();

    parent.queueEvent(event);
  }

  public void processDecodes(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processDecodes(context);
    }

    try
    {
      decode(context);
    } catch (RuntimeException e) {
      context.renderResponse();
      throw e;
    }
  }

  public void processValidators(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processValidators(context);
    }
  }

  public void processUpdates(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processUpdates(context);
    }
  }

  public Object processSaveState(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (isTransient())
      return null;

    Object[] stateStruct = new Object[2];
    Object[] childState = EMPTY_ARRAY;

    stateStruct[0] = saveState(context);

    int count = getChildCount() + getFacetCount();
    if (count > 0)
    {
      List stateList = new ArrayList(count);

      if (getChildCount() > 0) {
        Iterator kids = getChildren().iterator();
        while (true) { UIComponent kid;
          do { if (!(kids.hasNext())) break label130;
            kid = (UIComponent)kids.next(); }
          while (kid.isTransient());
          stateList.add(kid.processSaveState(context));
        }

      }

      if (getFacetCount() > 0) {
        label130: Iterator myFacets = getFacets().entrySet().iterator();
        UIComponent facet = null;
        Object facetState = null;
        Object[] facetSaveState = null;
        Map.Entry entry = null;
        while (true) { do { if (!(myFacets.hasNext())) break label251;
            entry = (Map.Entry)myFacets.next();
            facet = (UIComponent)entry.getValue(); }
          while (facet.isTransient());
          facetState = facet.processSaveState(context);
          facetSaveState = new Object[2];
          facetSaveState[0] = entry.getKey();
          facetSaveState[1] = facetState;
          stateList.add(facetSaveState);
        }

      }

      label251: childState = stateList.toArray();
    }

    stateStruct[1] = childState;
    return stateStruct;
  }

  public void processRestoreState(FacesContext context, Object state)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    Object[] stateStruct = (Object[])(Object[])state;
    Object[] childState = (Object[])(Object[])stateStruct[1];

    restoreState(context, stateStruct[0]);

    int i = 0;

    if (getChildCount() > 0) {
      Iterator kids = getChildren().iterator();
      while (true) { UIComponent kid;
        Object currentState;
        while (true) { while (true) { if (!(kids.hasNext())) break label122;
            kid = (UIComponent)kids.next();
            if (!(kid.isTransient()))
              break;
          }
          currentState = childState[(i++)];
          if (currentState != null)
            break;
        }
        kid.processRestoreState(context, currentState);
      }

    }

    if (getFacetCount() > 0) {
      label122: int facetsSize = getFacets().size();
      int j = 0;
      Object[] facetSaveState = null;
      String facetName = null;
      UIComponent facet = null;
      Object facetState = null;
      while (j < facetsSize) {
        if (null != (facetSaveState = (Object[])(Object[])childState[(i++)])) {
          facetName = (String)facetSaveState[0];
          facetState = facetSaveState[1];
          facet = (UIComponent)getFacets().get(facetName);
          facet.processRestoreState(context, facetState);
        }
        ++j;
      }
    }
  }

  protected FacesContext getFacesContext()
  {
    return FacesContext.getCurrentInstance();
  }

  protected Renderer getRenderer(FacesContext context)
  {
    String rendererType = getRendererType();
    Renderer result = null;
    if (rendererType != null) {
      result = context.getRenderKit().getRenderer(getFamily(), rendererType);

      if ((null == result) && 
        (log.isLoggable(Level.FINE)))
      {
        log.fine("Can't get Renderer for type " + rendererType);
      }

    }
    else if (log.isLoggable(Level.FINE)) {
      String id = getId();
      id = (null != id) ? id : getClass().getName();

      log.fine("No renderer-type for component " + id);
    }

    return result;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[8];
    }

    if (this.attributes != null) {
      Map backing = this.attributes.getBackingAttributes();
      if ((backing != null) && (!(backing.isEmpty())))
        this.values[0] = backing;
    }

    this.values[1] = saveBindingsState(context);
    this.values[2] = this.clientId;
    this.values[3] = this.id;
    this.values[4] = ((this.rendered) ? Boolean.TRUE : Boolean.FALSE);
    this.values[5] = ((this.renderedSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[6] = this.rendererType;
    this.values[7] = saveAttachedState(context, this.listeners);
    if ((!($assertionsDisabled)) && (this.transientFlag)) throw new AssertionError();

    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);

    if (this.values[0] != null)
      this.attributes = new AttributesMap(this, (Map)this.values[0], null);

    this.bindings = restoreBindingsState(context, this.values[1]);
    this.clientId = ((String)this.values[2]);
    this.id = ((String)this.values[3]);
    this.rendered = ((Boolean)this.values[4]).booleanValue();
    this.renderedSet = ((Boolean)this.values[5]).booleanValue();
    this.rendererType = ((String)this.values[6]);
    List restoredListeners = null;
    if (null != (restoredListeners = (List)restoreAttachedState(context, this.values[7])))
    {
      if (null != this.listeners) {
        this.listeners.addAll(restoredListeners);
      }
      else
        this.listeners = restoredListeners;
    }
  }

  public boolean isTransient()
  {
    return this.transientFlag;
  }

  public void setTransient(boolean transientFlag)
  {
    this.transientFlag = transientFlag;
  }

  public static Object saveAttachedState(FacesContext context, Object attachedObject)
  {
    if (null == context)
      throw new NullPointerException();

    if (null == attachedObject)
      return null;

    Object result = null;

    List attachedList = null;
    List resultList = null;
    Iterator listIter = null;

    if (attachedObject instanceof List) {
      attachedList = (List)attachedObject;
      resultList = new ArrayList(attachedList.size());
      listIter = attachedList.iterator();
      Object cur = null;
      while (true) { do if (!(listIter.hasNext())) break label113;
        while (null == (cur = listIter.next()));
        resultList.add(new StateHolderSaver(context, cur));
      }

      label113: result = resultList;
    }
    else {
      result = new StateHolderSaver(context, attachedObject);
    }

    return result;
  }

  public static Object restoreAttachedState(FacesContext context, Object stateObj)
    throws IllegalStateException
  {
    Object result;
    if (null == context)
      throw new NullPointerException();

    if (null == stateObj) {
      return null;
    }

    if (stateObj instanceof List) {
      List stateList = (List)stateObj;
      List retList = new ArrayList(stateList.size());
      for (Iterator i$ = stateList.iterator(); i$.hasNext(); ) { Object item = i$.next();
        try {
          retList.add(((StateHolderSaver)item).restore(context));
        } catch (ClassCastException cce) {
          throw new IllegalStateException("Unknown object type");
        }
      }
      result = retList;
    } else if (stateObj instanceof StateHolderSaver) {
      StateHolderSaver saver = (StateHolderSaver)stateObj;
      result = saver.restore(context);
    }
    else throw new IllegalStateException("Unknown object type");

    return result;
  }

  private Map restoreBindingsState(FacesContext context, Object state)
  {
    if (state == null)
      return null;

    Object[] values = (Object[])(Object[])state;
    String[] names = (String[])(String[])values[0];
    Object[] states = (Object[])(Object[])values[1];
    Map bindings = new HashMap(names.length);
    for (int i = 0; i < names.length; ++i) {
      bindings.put(names[i], restoreAttachedState(context, states[i]));
    }

    return bindings;
  }

  private Object saveBindingsState(FacesContext context)
  {
    if (this.bindings == null) {
      return null;
    }

    Object[] values = new Object[2];
    values[0] = this.bindings.keySet().toArray(new String[this.bindings.size()]);

    Object[] bindingValues = this.bindings.values().toArray();
    for (int i = 0; i < bindingValues.length; ++i) {
      bindingValues[i] = saveAttachedState(context, bindingValues[i]);
    }

    values[1] = bindingValues;

    return values;
  }

  static
  {
    log = Logger.getLogger("javax.faces.component", "javax.faces.LogStrings");

    descriptors = new WeakHashMap();

    empty = new Object[0];

    EMPTY_ARRAY = new Object[0];

    EMPTY_ITERATOR = new Iterator()
    {
      public void remove() {
        throw new UnsupportedOperationException();
      }

      public Object next() {
        throw new NoSuchElementException("Empty Iterator");
      }

      public boolean hasNext() {
        return false;
      }
    };
  }

  private class AttributesMap
  implements Map, Serializable
  {
    private Map attributes;

    private AttributesMap()
    {
      this.attributes = attributes;
    }

    public boolean containsKey() {
      String key = (String)keyObj;
      PropertyDescriptor pd = UIComponentBase.access$400(this.this$0, key);

      if (pd == null) {
        if (this.attributes != null)
          return this.attributes.containsKey(key);

        return false;
      }

      return false; } 
    // ERROR //
    public Object get() { // Byte code:
      //   0: aload_1
      //   1: checkcast 95	java/lang/String
      //   4: astore_2
      //   5: aload_2
      //   6: ifnonnull +11 -> 17
      //   9: new 93	java/lang/NullPointerException
      //   12: dup
      //   13: invokespecial 206	java/lang/NullPointerException:<init>	()V
      //   16: athrow
      //   17: aload_0
      //   18: getfield 200	javax/faces/component/UIComponentBase$AttributesMap:this$0	Ljavax/faces/component/UIComponentBase;
      //   21: aload_2
      //   22: invokestatic 219	javax/faces/component/UIComponentBase:access$400	(Ljavax/faces/component/UIComponentBase;Ljava/lang/String;)Ljava/beans/PropertyDescriptor;
      //   25: astore_3
      //   26: aload_3
      //   27: ifnull +63 -> 90
      //   30: aload_3
      //   31: invokevirtual 201	java/beans/PropertyDescriptor:getReadMethod	()Ljava/lang/reflect/Method;
      //   34: astore 4
      //   36: aload 4
      //   38: ifnull +16 -> 54
      //   41: aload 4
      //   43: aload_0
      //   44: getfield 200	javax/faces/component/UIComponentBase$AttributesMap:this$0	Ljavax/faces/component/UIComponentBase;
      //   47: invokestatic 216	javax/faces/component/UIComponentBase:access$500	()[Ljava/lang/Object;
      //   50: invokevirtual 212	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   53: areturn
      //   54: new 92	java/lang/IllegalArgumentException
      //   57: dup
      //   58: aload_2
      //   59: invokespecial 205	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
      //   62: athrow
      //   63: astore 4
      //   65: new 106	javax/faces/FacesException
      //   68: dup
      //   69: aload 4
      //   71: invokespecial 215	javax/faces/FacesException:<init>	(Ljava/lang/Throwable;)V
      //   74: athrow
      //   75: astore 4
      //   77: new 106	javax/faces/FacesException
      //   80: dup
      //   81: aload 4
      //   83: invokevirtual 211	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
      //   86: invokespecial 215	javax/faces/FacesException:<init>	(Ljava/lang/Throwable;)V
      //   89: athrow
      //   90: aload_0
      //   91: getfield 199	javax/faces/component/UIComponentBase$AttributesMap:attributes	Ljava/util/Map;
      //   94: ifnull +27 -> 121
      //   97: aload_0
      //   98: getfield 199	javax/faces/component/UIComponentBase$AttributesMap:attributes	Ljava/util/Map;
      //   101: aload_2
      //   102: invokeinterface 231 2 0
      //   107: ifeq +14 -> 121
      //   110: aload_0
      //   111: getfield 199	javax/faces/component/UIComponentBase$AttributesMap:attributes	Ljava/util/Map;
      //   114: aload_2
      //   115: invokeinterface 237 2 0
      //   120: areturn
      //   121: aload_0
      //   122: getfield 200	javax/faces/component/UIComponentBase$AttributesMap:this$0	Ljavax/faces/component/UIComponentBase;
      //   125: aload_2
      //   126: invokevirtual 218	javax/faces/component/UIComponentBase:getValueExpression	(Ljava/lang/String;)Ljavax/el/ValueExpression;
      //   129: astore 4
      //   131: aload 4
      //   133: ifnull +38 -> 171
      //   136: aconst_null
      //   137: astore 5
      //   139: aload 4
      //   141: aload_0
      //   142: getfield 200	javax/faces/component/UIComponentBase$AttributesMap:this$0	Ljavax/faces/component/UIComponentBase;
      //   145: invokevirtual 217	javax/faces/component/UIComponentBase:getFacesContext	()Ljavax/faces/context/FacesContext;
      //   148: invokevirtual 225	javax/faces/context/FacesContext:getELContext	()Ljavax/el/ELContext;
      //   151: invokevirtual 214	javax/el/ValueExpression:getValue	(Ljavax/el/ELContext;)Ljava/lang/Object;
      //   154: astore 5
      //   156: aload 5
      //   158: areturn
      //   159: astore 6
      //   161: new 106	javax/faces/FacesException
      //   164: dup
      //   165: aload 6
      //   167: invokespecial 215	javax/faces/FacesException:<init>	(Ljava/lang/Throwable;)V
      //   170: athrow
      //   171: aconst_null
      //   172: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   30	53	63	java/lang/IllegalAccessException
      //   54	63	63	java/lang/IllegalAccessException
      //   30	53	75	java/lang/reflect/InvocationTargetException
      //   54	63	75	java/lang/reflect/InvocationTargetException
      //   139	158	159	javax/el/ELException } 
    public Object put(, Object value) { if (keyValue == null) {
        throw new NullPointerException();
      }

      if (!(keyValue instanceof String))
      {
        throw new ClassCastException("Key must be a String");
      }

      String key = keyValue.toString();
      PropertyDescriptor pd = UIComponentBase.access$400(this.this$0, key);

      if (pd != null);
      try {
        Object result = null;
        Method readMethod = pd.getReadMethod();
        if (readMethod != null) {
          result = readMethod.invoke(this.this$0, UIComponentBase.access$500());
        }

        Method writeMethod = pd.getWriteMethod();
        if (writeMethod != null) {
          writeMethod.invoke(this.this$0, new Object[] { value });
        }
        else
        {
          throw new IllegalArgumentException();
        }
        return result;
      } catch (IllegalAccessException e) {
        throw new FacesException(e);
      } catch (InvocationTargetException e) {
        throw new FacesException(e.getTargetException());

        if (value == null)
          throw new NullPointerException();

        if (this.attributes == null)
          initMap();

        return this.attributes.put(key, value);
      }
    }

    public void putAll() {
      if (map == null) {
        throw new NullPointerException();
      }

      if (this.attributes == null)
        initMap();

      this.attributes.putAll(map);
    }

    public Object remove() {
      String key = (String)keyObj;
      if (key == null)
        throw new NullPointerException();

      PropertyDescriptor pd = UIComponentBase.access$400(this.this$0, key);

      if (pd != null)
        throw new IllegalArgumentException(key);

      if (this.attributes != null)
        return this.attributes.remove(key);

      return null;
    }

    public int size()
    {
      return ((this.attributes != null) ? this.attributes.size() : 0);
    }

    public boolean isEmpty() {
      return ((this.attributes == null) || (this.attributes.isEmpty()));
    }

    public boolean containsValue() {
      return ((this.attributes != null) && (this.attributes.containsValue(value)));
    }

    public void clear() {
      if (this.attributes != null)
        this.attributes.clear();
    }

    public Set keySet()
    {
      return ((this.attributes != null) ? this.attributes.keySet() : Collections.EMPTY_SET);
    }

    public Collection values()
    {
      return ((this.attributes != null) ? this.attributes.values() : Collections.EMPTY_LIST);
    }

    public Set entrySet()
    {
      return ((this.attributes != null) ? this.attributes.entrySet() : Collections.EMPTY_SET);
    }

    Map getBackingAttributes()
    {
      return this.attributes; } 
    // ERROR //
    public boolean equals() { // Byte code:
      //   0: aload_1
      //   1: aload_0
      //   2: if_acmpne +5 -> 7
      //   5: iconst_1
      //   6: ireturn
      //   7: aload_1
      //   8: instanceof 101
      //   11: ifne +5 -> 16
      //   14: iconst_0
      //   15: ireturn
      //   16: aload_1
      //   17: checkcast 101	java/io/Serializable
      //   20: astore_2
      //   21: aload_2
      //   22: invokeinterface 228 1 0
      //   27: aload_0
      //   28: invokevirtual 220	javax/faces/component/UIComponentBase$AttributesMap:size	()I
      //   31: if_icmpeq +5 -> 36
      //   34: iconst_0
      //   35: ireturn
      //   36: aload_0
      //   37: invokevirtual 222	javax/faces/component/UIComponentBase$AttributesMap:entrySet	()Ljava/util/Set;
      //   40: invokeinterface 242 1 0
      //   45: astore_3
      //   46: aload_3
      //   47: invokeinterface 226 1 0
      //   52: ifeq +86 -> 138
      //   55: aload_3
      //   56: invokeinterface 227 1 0
      //   61: astore 4
      //   63: aload 4
      //   65: checkcast 102	java/util/Map$Entry
      //   68: astore 5
      //   70: aload 5
      //   72: invokeinterface 240 1 0
      //   77: astore 6
      //   79: aload 5
      //   81: invokeinterface 241 1 0
      //   86: astore 7
      //   88: aload 7
      //   90: ifnonnull +27 -> 117
      //   93: aload_2
      //   94: aload 6
      //   96: invokeinterface 237 2 0
      //   101: ifnonnull +14 -> 115
      //   104: aload_2
      //   105: aload 6
      //   107: invokeinterface 231 2 0
      //   112: ifne +23 -> 135
      //   115: iconst_0
      //   116: ireturn
      //   117: aload 7
      //   119: aload_2
      //   120: aload 6
      //   122: invokeinterface 237 2 0
      //   127: invokevirtual 209	java/lang/Object:equals	(Ljava/lang/Object;)Z
      //   130: ifne +5 -> 135
      //   133: iconst_0
      //   134: ireturn
      //   135: goto -89 -> 46
      //   138: goto +9 -> 147
      //   141: astore_3
      //   142: iconst_0
      //   143: ireturn
      //   144: astore_3
      //   145: iconst_0
      //   146: ireturn
      //   147: iconst_1
      //   148: ireturn
      //
      // Exception table:
      //   from	to	target	type
      //   36	116	141	java/lang/ClassCastException
      //   117	134	141	java/lang/ClassCastException
      //   135	138	141	java/lang/ClassCastException
      //   36	116	144	java/lang/NullPointerException
      //   117	134	144	java/lang/NullPointerException
      //   135	138	144	java/lang/NullPointerException } 
    public int hashCode() { int h = 0;
      for (Iterator i$ = entrySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
        h = h + o.hashCode();
      }
      return h;
    }

    private void initMap() {
      this.attributes = new HashMap(8);
    }
  }

  private class ChildrenList extends ArrayList<UIComponent>
  {
    public void add(, UIComponent element)
    {
      if (element == null)
        throw new NullPointerException();
      if ((index < 0) || (index > size()))
        throw new IndexOutOfBoundsException();

      UIComponentBase.access$600(this.this$0, element);
      element.setParent(this.this$0);
      super.add(index, element);
    }

    public boolean add()
    {
      if (element == null)
        throw new NullPointerException();

      UIComponentBase.access$600(this.this$0, element);
      element.setParent(this.this$0);
      return super.add(element);
    }

    public boolean addAll()
    {
      Iterator elements = new ArrayList(collection).iterator();

      boolean changed = false;
      while (elements.hasNext()) {
        UIComponent element = (UIComponent)elements.next();
        if (element == null)
          throw new NullPointerException();

        add(element);
        changed = true;
      }

      return changed;
    }

    public boolean addAll(, Collection<? extends UIComponent> collection) {
      Iterator elements = new ArrayList(collection).iterator();

      boolean changed = false;
      while (elements.hasNext()) {
        UIComponent element = (UIComponent)elements.next();
        if (element == null)
          throw new NullPointerException();

        add(index++, element);
        changed = true;
      }

      return changed;
    }

    public void clear() {
      int n = size();
      if (n < 1)
        return;

      for (int i = 0; i < n; ++i) {
        UIComponent child = (UIComponent)get(i);
        child.setParent(null);
      }
      super.clear();
    }

    public Iterator<UIComponent> iterator() {
      return new UIComponentBase.ChildrenListIterator(this);
    }

    public ListIterator<UIComponent> listIterator() {
      return new UIComponentBase.ChildrenListIterator(this);
    }

    public ListIterator<UIComponent> listIterator() {
      return new UIComponentBase.ChildrenListIterator(this, index);
    }

    public UIComponent remove() {
      UIComponent child = (UIComponent)get(index);
      super.remove(index);
      child.setParent(null);
      return child;
    }

    public boolean remove() {
      UIComponent element = (UIComponent)elementObj;
      if (element == null) {
        throw new NullPointerException();
      }

      if (super.remove(element)) {
        element.setParent(null);
        return true;
      }
      return false;
    }

    public boolean removeAll()
    {
      boolean result = false;
      Iterator elements = collection.iterator();
      while (true) { do if (!(elements.hasNext())) break label36;
        while (!(remove(elements.next())));
        result = true;
      }

      label36: return result;
    }

    public boolean retainAll() {
      boolean modified = false;
      Iterator items = iterator();
      while (true) { do if (!(items.hasNext())) break label42;
        while (collection.contains(items.next()));
        items.remove();
        modified = true;
      }

      label42: return modified;
    }

    public UIComponent set(, UIComponent element) {
      if (element == null)
        throw new NullPointerException();
      if ((index < 0) || (index >= size()))
        throw new IndexOutOfBoundsException();

      UIComponentBase.access$600(this.this$0, element);
      UIComponent previous = (UIComponent)get(index);

      previous.setParent(null);
      element.setParent(this.this$0);
      super.set(index, element);
      return previous; }  } 
  private static class ChildrenListIterator
  implements ListIterator<UIComponent> { private UIComponentBase.ChildrenList list;
    private int index;
    private int last = -1;

    public ChildrenListIterator(UIComponentBase.ChildrenList list) { this.list = list;
      this.index = 0;
    }

    public ChildrenListIterator(UIComponentBase.ChildrenList list, int index) {
      this.list = list;
      if ((index < 0) || (index >= list.size()))
        throw new IndexOutOfBoundsException("" + index);

      this.index = index;
    }

    public boolean hasNext()
    {
      return (this.index < this.list.size()); }

    public UIComponent next() {
      UIComponent o;
      try {
        o = (UIComponent)this.list.get(this.index);
        this.last = (this.index++);
        return o;
      } catch (IndexOutOfBoundsException e) {
        throw new NoSuchElementException("" + this.index);
      }
    }

    public void remove() {
      if (this.last == -1)
        throw new IllegalStateException();

      this.list.remove(this.last);
      if (this.last < this.index)
        this.index = (this.index - 1);

      this.last = -1;
    }

    public void add(UIComponent o)
    {
      this.last = -1;
      this.list.add(this.index++, o);
    }

    public boolean hasPrevious() {
      return (this.index > 1);
    }

    public int nextIndex() {
      return this.index; }

    public UIComponent previous() {
      int current;
      try {
        current = this.index - 1;
        UIComponent o = (UIComponent)this.list.get(current);
        this.last = current;
        this.index = current;
        return o;
      } catch (IndexOutOfBoundsException e) {
        throw new NoSuchElementException();
      }
    }

    public int previousIndex() {
      return (this.index - 1);
    }

    public void set(UIComponent o) {
      if (this.last == -1)
        throw new IllegalStateException();

      this.list.set(this.last, o);
    }
  }

  private static final class FacetsAndChildrenIterator
  implements Iterator<UIComponent>
  {
    private Iterator<UIComponent> iterator;
    private boolean childMode;
    private UIComponent c;

    public FacetsAndChildrenIterator(UIComponent c)
    {
      this.c = c;
      this.childMode = false;
    }

    private void update() {
      if (this.iterator == null)
      {
        if (this.c.getFacetCount() != 0) {
          this.iterator = this.c.getFacets().values().iterator();
          this.childMode = false;
        } else if (this.c.getChildCount() != 0) {
          this.iterator = this.c.getChildren().iterator();
          this.childMode = true;
        } else {
          this.iterator = UIComponentBase.access$700();
          this.childMode = true; }
      }
      else if ((!(this.childMode)) && (!(this.iterator.hasNext())) && (this.c.getChildCount() != 0))
      {
        this.iterator = this.c.getChildren().iterator();
        this.childMode = true;
      }
    }

    public boolean hasNext() {
      update();
      return this.iterator.hasNext();
    }

    public UIComponent next() {
      update();
      return ((UIComponent)this.iterator.next());
    }

    public void remove() {
      throw new UnsupportedOperationException();
    }
  }

  private class FacetsMap extends HashMap<String, UIComponent>
  {
    public void clear()
    {
      Iterator keys = keySet().iterator();
      while (keys.hasNext()) {
        String key = (String)keys.next();
        keys.remove();
      }
      super.clear();
    }

    public Set<Map.Entry<String, UIComponent>> entrySet() {
      return new UIComponentBase.FacetsMapEntrySet(this);
    }

    public Set<String> keySet() {
      return new UIComponentBase.FacetsMapKeySet(this);
    }

    public UIComponent put(, UIComponent value) {
      if ((key == null) || (value == null))
        throw new NullPointerException();
      if ((!(key instanceof String)) || (!(value instanceof UIComponent)))
      {
        throw new ClassCastException();
      }
      UIComponent previous = (UIComponent)super.get(key);
      if (previous != null)
        previous.setParent(null);

      UIComponentBase.access$600(this.this$0, value);
      value.setParent(this.this$0);
      return ((UIComponent)super.put(key, value));
    }

    public void putAll() {
      if (map == null)
        throw new NullPointerException();

      for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        put((String)entry.getKey(), (UIComponent)entry.getValue());
      }
    }

    public UIComponent remove() {
      UIComponent previous = (UIComponent)get(key);
      if (previous != null)
        previous.setParent(null);

      super.remove(key);
      return previous;
    }

    public Collection<UIComponent> values() {
      return new UIComponentBase.FacetsMapValues(this);
    }

    Iterator<String> keySetIterator() {
      return new ArrayList(super.keySet()).iterator(); }  }

  private static class FacetsMapEntrySet extends AbstractSet<Map.Entry<String, UIComponent>> { private UIComponentBase.FacetsMap map = null;

    public FacetsMapEntrySet(UIComponentBase.FacetsMap map) { this.map = map;
    }

    public boolean add(Map.Entry<String, UIComponent> o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends Map.Entry<String, UIComponent>> c) {
      throw new UnsupportedOperationException();
    }

    public void clear() {
      this.map.clear();
    }

    public boolean contains(Object o) {
      if (o == null)
        throw new NullPointerException();

      if (!(o instanceof Map.Entry))
        return false;

      Map.Entry e = (Map.Entry)o;
      Object k = e.getKey();
      Object v = e.getValue();
      if (!(this.map.containsKey(k)))
        return false;

      if (v == null)
        return (this.map.get(k) == null);

      return v.equals(this.map.get(k));
    }

    public boolean isEmpty()
    {
      return this.map.isEmpty();
    }

    public Iterator<Map.Entry<String, UIComponent>> iterator() {
      return new UIComponentBase.FacetsMapEntrySetIterator(this.map);
    }

    public boolean remove(Object o) {
      if (o == null)
        throw new NullPointerException();

      if (!(o instanceof Map.Entry))
        return false;

      Object k = ((Map.Entry)o).getKey();
      if (this.map.containsKey(k)) {
        this.map.remove(k);
        return true;
      }
      return false;
    }

    public boolean removeAll(Collection c)
    {
      boolean result = false;
      Iterator v = c.iterator();
      while (true) { do if (!(v.hasNext())) break label36;
        while (!(remove(v.next())));
        result = true;
      }

      label36: return result;
    }

    public boolean retainAll(Collection c) {
      boolean result = false;
      Iterator v = iterator();
      while (true) { do if (!(v.hasNext())) break label42;
        while (c.contains(v.next()));
        v.remove();
        result = true;
      }

      label42: return result;
    }

    public int size() {
      return this.map.size();
    }
  }

  private static class FacetsMapEntrySetEntry
  implements Map.Entry<String, UIComponent>
  {
    private UIComponentBase.FacetsMap map;
    private String key;

    public FacetsMapEntrySetEntry(UIComponentBase.FacetsMap map, String key) {
      this.map = map;
      this.key = key;
    }

    public boolean equals(Object o)
    {
      if (o == null)
        return false;

      if (!(o instanceof Map.Entry))
        return false;

      Map.Entry e = (Map.Entry)o;
      if (this.key == null) {
        if (e.getKey() == null) break label56;
        return false;
      }

      if (!(this.key.equals(e.getKey()))) {
        return false;
      }

      label56: UIComponent v = (UIComponent)this.map.get(this.key);
      if (v == null) {
        if (e.getValue() == null) break label101;
        return false;
      }

      label101: return (v.equals(e.getValue()));
    }

    public String getKey()
    {
      return this.key;
    }

    public UIComponent getValue() {
      return ((UIComponent)this.map.get(this.key));
    }

    public int hashCode() {
      Object value = this.map.get(this.key);
      return (((this.key == null) ? 0 : this.key.hashCode()) ^ ((value == null) ? 0 : value.hashCode()));
    }

    public UIComponent setValue(UIComponent value)
    {
      UIComponent previous = (UIComponent)this.map.get(this.key);
      this.map.put(this.key, value);
      return previous; }  } 
  private static class FacetsMapEntrySetIterator
  implements Iterator<Map.Entry<String, UIComponent>> { private UIComponentBase.FacetsMap map = null;
    private Iterator<String> iterator = null;
    private Map.Entry<String, UIComponent> last = null;

    public FacetsMapEntrySetIterator(UIComponentBase.FacetsMap map) { this.last = map;
      this.iterator = map.keySetIterator();
    }

    public boolean hasNext()
    {
      return this.iterator.hasNext();
    }

    public Map.Entry<String, UIComponent> next() {
      this.last = new UIComponentBase.FacetsMapEntrySetEntry(this.last, (String)this.iterator.next());
      return this.last;
    }

    public void remove() {
      if (this.last == null)
        throw new IllegalStateException();

      this.last.remove(this.last.getKey());
      this.last = null; }  }

  private static class FacetsMapKeySet extends AbstractSet<String> { private UIComponentBase.FacetsMap map = null;

    public FacetsMapKeySet(UIComponentBase.FacetsMap map) { this.map = map;
    }

    public boolean add(String o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends String> c) {
      throw new UnsupportedOperationException();
    }

    public void clear() {
      this.map.clear();
    }

    public boolean contains(Object o) {
      return this.map.containsKey(o);
    }

    public boolean containsAll(Collection c) {
      Iterator v = c.iterator();
      do if (!(v.hasNext())) break label34;
      while (this.map.containsKey(v.next()));
      return false;

      label34: return true;
    }

    public boolean isEmpty() {
      return (this.map.size() == 0);
    }

    public Iterator<String> iterator() {
      return new UIComponentBase.FacetsMapKeySetIterator(this.map);
    }

    public boolean remove(Object o) {
      if (this.map.containsKey(o)) {
        this.map.remove(o);
        return true;
      }
      return false;
    }

    public boolean removeAll(Collection c)
    {
      boolean result = false;
      Iterator v = c.iterator();
      while (v.hasNext()) {
        Object o = v.next();
        if (this.map.containsKey(o)) {
          this.map.remove(o);
          result = true;
        }
      }
      return result;
    }

    public boolean retainAll(Collection c) {
      boolean result = false;
      Iterator v = iterator();
      while (true) { do if (!(v.hasNext())) break label42;
        while (c.contains(v.next()));
        v.remove();
        result = true;
      }

      label42: return result;
    }

    public int size() {
      return this.map.size(); }  } 
  private static class FacetsMapKeySetIterator
  implements Iterator<String> { private UIComponentBase.FacetsMap map = null;
    private Iterator<String> iterator = null;
    private String last = null;

    public FacetsMapKeySetIterator(UIComponentBase.FacetsMap map) { this.last = map;
      this.iterator = map.keySetIterator();
    }

    public boolean hasNext()
    {
      return this.iterator.hasNext();
    }

    public String next() {
      this.last = ((String)this.iterator.next());
      return this.last;
    }

    public void remove() {
      if (this.last == null)
        throw new IllegalStateException();

      this.last.remove(this.last);
      this.last = null;
    }
  }

  private static class FacetsMapValues extends AbstractCollection<UIComponent>
  {
    private UIComponentBase.FacetsMap map;

    public FacetsMapValues(UIComponentBase.FacetsMap map)
    {
      this.map = map;
    }

    public boolean add(UIComponent o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public void clear() {
      this.map.clear();
    }

    public boolean isEmpty() {
      return (this.map.size() == 0);
    }

    public Iterator<UIComponent> iterator() {
      return new UIComponentBase.FacetsMapValuesIterator(this.map);
    }

    public int size() {
      return this.map.size(); }  } 
  private static class FacetsMapValuesIterator
  implements Iterator<UIComponent> { private UIComponentBase.FacetsMap map = null;
    private Iterator<String> iterator = null;
    private Object last = null;

    public FacetsMapValuesIterator(UIComponentBase.FacetsMap map) { this.last = map;
      this.iterator = map.keySetIterator();
    }

    public boolean hasNext()
    {
      return this.iterator.hasNext();
    }

    public UIComponent next() {
      this.last = this.iterator.next();
      return ((UIComponent)this.last.get(this.last));
    }

    public void remove() {
      if (this.last == null)
        throw new IllegalStateException();

      this.last.remove(this.last);
      this.last = null;
    }
  }
}