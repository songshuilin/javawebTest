package javax.faces.component;

import javax.faces.context.FacesContext;

public abstract interface ContextCallback
{
  public abstract void invokeContextCallback(FacesContext paramFacesContext, UIComponent paramUIComponent);
}