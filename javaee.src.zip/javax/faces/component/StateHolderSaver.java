package javax.faces.component;

import java.io.Serializable;
import javax.faces.context.FacesContext;

class StateHolderSaver
  implements Serializable
{
  private static final long serialVersionUID = -1818440371L;
  private String className = null;
  private Object savedState = null;

  public StateHolderSaver(FacesContext context, Object toSave)
  {
    this.savedState = toSave.getClass().getName();

    if (toSave instanceof StateHolder)
    {
      if (!(((StateHolder)toSave).isTransient()))
        this.savedState = ((StateHolder)toSave).saveState(context);
      else
        this.savedState = null;

    }
    else if (toSave instanceof Serializable) {
      this.savedState = toSave;
      this.savedState = null;
    }
  }

  public Object restore(FacesContext context)
    throws IllegalStateException
  {
    Object result = null;
    Class toRestoreClass = null;

    if ((null == this.savedState) && (null != this.savedState)) {
      return this.savedState;
    }

    if (this.savedState == null) {
      return null;
    }

    try
    {
      toRestoreClass = loadClass(this.savedState, this);
    }
    catch (ClassNotFoundException e) {
      throw new IllegalStateException(e.getMessage());
    }

    if (null != toRestoreClass)
      try {
        result = toRestoreClass.newInstance();
      }
      catch (InstantiationException e) {
        throw new IllegalStateException(e.getMessage());
      }
      catch (IllegalAccessException a) {
        throw new IllegalStateException(a.getMessage());
      }


    if ((null != result) && (null != this.savedState) && (result instanceof StateHolder))
    {
      ((StateHolder)result).restoreState(context, this.savedState);
    }
    return result;
  }

  private static Class loadClass(String name, Object fallbackClass)
    throws ClassNotFoundException
  {
    ClassLoader loader = Thread.currentThread().getContextClassLoader();

    if (loader == null)
      loader = fallbackClass.getClass().getClassLoader();

    return Class.forName(name, false, loader);
  }
}