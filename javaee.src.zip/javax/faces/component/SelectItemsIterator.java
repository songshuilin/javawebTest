package javax.faces.component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import javax.faces.model.SelectItem;

final class SelectItemsIterator
  implements Iterator<SelectItem>
{
  private Iterator<SelectItem> items = null;
  private ListIterator<UIComponent> kids = null;

  public SelectItemsIterator(UIComponent parent)
  {
    this.kids = parent.getChildren().listIterator();
  }

  public boolean hasNext()
  {
    if (this.kids != null) {
      if (this.kids.hasNext())
        return true;

      this.kids = null;
    }

    Object next = findNextValidChild();
    if (next != null) {
      this.kids.previous();
      return true;
    }
    return false;
  }

  public SelectItem next()
  {
    if (!(hasNext()))
      throw new NoSuchElementException();

    if (this.kids != null)
      return ((SelectItem)this.kids.next());

    UIComponent kid = (UIComponent)findNextValidChild();
    if (kid instanceof UISelectItem) {
      UISelectItem ui = (UISelectItem)kid;
      SelectItem item = (SelectItem)ui.getValue();
      if (item == null) {
        item = new SelectItem(ui.getItemValue(), ui.getItemLabel(), ui.getItemDescription(), ui.isItemDisabled(), ui.isItemEscaped());
      }

      return item; }
    if (kid instanceof UISelectItems) {
      UISelectItems ui = (UISelectItems)kid;
      Object value = ui.getValue();
      if (value instanceof SelectItem)
        return ((SelectItem)value);
      if (value instanceof SelectItem[]) {
        this.kids = Arrays.asList((SelectItem[])(SelectItem[])value).iterator();
        return next(); }
      if (value instanceof List) {
        this.kids = ((List)value).iterator();
        return next(); }
      if (value instanceof Map) {
        List list = new ArrayList();
        Iterator keys = ((Map)value).keySet().iterator();
        while (true) { Object key;
          Object val;
          while (true) { while (true) { if (!(keys.hasNext()))
                break label288;
              key = keys.next();
              if (key != null)
                break;
            }
            val = ((Map)value).get(key);
            if (val != null)
              break;
          }
          list.add(new SelectItem(val, key.toString(), null));
        }

        label288: this.kids = list.iterator();
        return next();
      }
      throw new IllegalArgumentException();
    }

    throw new NoSuchElementException();
  }

  public void remove()
  {
    throw new UnsupportedOperationException();
  }

  private Object findNextValidChild()
  {
    if (this.kids.hasNext()) {
      Object next = this.kids.next();
      while ((this.kids.hasNext()) && (!(next instanceof UISelectItem)) && (!(next instanceof UISelectItems)))
        next = this.kids.next();

      if ((next instanceof UISelectItem) || (next instanceof UISelectItems))
        return next;
    }

    return null;
  }
}