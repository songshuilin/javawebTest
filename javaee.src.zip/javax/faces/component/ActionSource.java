package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ActionListener;

public abstract interface ActionSource
{
  /**
   * @deprecated
   */
  public abstract MethodBinding getAction();

  /**
   * @deprecated
   */
  public abstract void setAction(MethodBinding paramMethodBinding);

  /**
   * @deprecated
   */
  public abstract MethodBinding getActionListener();

  /**
   * @deprecated
   */
  public abstract void setActionListener(MethodBinding paramMethodBinding);

  public abstract boolean isImmediate();

  public abstract void setImmediate(boolean paramBoolean);

  public abstract void addActionListener(ActionListener paramActionListener);

  public abstract ActionListener[] getActionListeners();

  public abstract void removeActionListener(ActionListener paramActionListener);
}