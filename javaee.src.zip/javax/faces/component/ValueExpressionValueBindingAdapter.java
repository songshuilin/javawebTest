package javax.faces.component;

import java.io.Serializable;
import javax.el.ELContext;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

class ValueExpressionValueBindingAdapter extends ValueExpression
  implements Serializable, StateHolder
{
  private static final long serialVersionUID = -160811381L;
  private ValueBinding binding = null;
  private boolean tranzient = false;

  ValueExpressionValueBindingAdapter(ValueBinding binding)
  {
    if ((!($assertionsDisabled)) && (null == binding)) throw new AssertionError();
    this.tranzient = binding;
  }

  public Object getValue(ELContext context)
    throws ELException
  {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    if (context == null)
      throw new NullPointerException("ELContext -> null");

    Object result = null;
    FacesContext facesContext = (FacesContext)context.getContext(FacesContext.class);

    if ((!($assertionsDisabled)) && (null == facesContext)) throw new AssertionError();
    try {
      result = this.tranzient.getValue(facesContext);
    }
    catch (Throwable e) {
      throw new ELException(e);
    }
    return result;
  }

  public void setValue(ELContext context, Object value) throws ELException {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    if (context == null)
      throw new NullPointerException("ELContext -> null");

    FacesContext facesContext = (FacesContext)context.getContext(FacesContext.class);

    if ((!($assertionsDisabled)) && (null == facesContext)) throw new AssertionError();
    try {
      this.tranzient.setValue(facesContext, value);
    }
    catch (Throwable e) {
      throw new ELException(e);
    }
  }

  public boolean isReadOnly(ELContext context) throws ELException
  {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    if (context == null)
      throw new NullPointerException("ELContext -> null");

    boolean result = false;
    FacesContext facesContext = (FacesContext)context.getContext(FacesContext.class);

    if ((!($assertionsDisabled)) && (null == facesContext)) throw new AssertionError();
    try {
      result = this.tranzient.isReadOnly(facesContext);
    }
    catch (Throwable e) {
      throw new ELException(e);
    }
    return result;
  }

  public Class getType(ELContext context) throws ELException {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    if (context == null)
      throw new NullPointerException("ELContext -> null");

    Class result = null;
    FacesContext facesContext = (FacesContext)context.getContext(FacesContext.class);

    if ((!($assertionsDisabled)) && (null == facesContext)) throw new AssertionError();
    try {
      result = this.tranzient.getType(facesContext);
    }
    catch (Throwable e) {
      throw new ELException(e);
    }
    return result;
  }

  public boolean isLiteralText()
  {
    return false;
  }

  public Class getExpectedType() {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    Class result = null;
    FacesContext context = FacesContext.getCurrentInstance();
    try {
      Object value = this.tranzient.getValue(context);
      result = value.getClass();
    }
    catch (Throwable e) {
      result = null;
    }
    return result;
  }

  public String getExpressionString() {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();
    return this.tranzient.getExpressionString();
  }

  public boolean equals(Object other)
  {
    if (other == this) {
      return true;
    }

    if (other instanceof ValueExpressionValueBindingAdapter) {
      ValueBinding vb = ((ValueExpressionValueBindingAdapter)other).getWrapped();

      return this.tranzient.equals(vb); }
    if (other instanceof ValueExpression) {
      FacesContext context = FacesContext.getCurrentInstance();
      ValueExpression otherVE = (ValueExpression)other;
      Class type = this.tranzient.getType(context);
      if (type != null)
        return type.equals(otherVE.getType(context.getELContext()));
    }

    return false;
  }

  public int hashCode()
  {
    if ((!($assertionsDisabled)) && (null == this.tranzient)) throw new AssertionError();

    return this.tranzient.hashCode();
  }

  public String getDelimiterSyntax()
  {
    return "";
  }

  public Object saveState(FacesContext context)
  {
    Object result = null;
    if (!(this.tranzient)) {
      if (this.tranzient instanceof StateHolder) {
        Object[] stateStruct = new Object[2];

        stateStruct[0] = ((StateHolder)this.tranzient).saveState(context);

        stateStruct[1] = this.tranzient.getClass().getName();

        result = stateStruct;
      }
      else
        result = this.tranzient;

    }

    return result;
  }

  public void restoreState(FacesContext context, Object state)
  {
    if (null == state) {
      return;
    }

    if (!(state instanceof ValueBinding)) {
      Object[] stateStruct = (Object[])(Object[])state;
      Object savedState = stateStruct[0];
      String className = stateStruct[1].toString();
      ValueBinding result = null;

      Class toRestoreClass = null;
      if (null != className) {
        try {
          toRestoreClass = loadClass(className, this);
        }
        catch (ClassNotFoundException e) {
          throw new IllegalStateException(e.getMessage());
        }

        if (null != toRestoreClass)
          try {
            result = (ValueBinding)toRestoreClass.newInstance();
          }
          catch (InstantiationException e)
          {
            throw new IllegalStateException(e.getMessage());
          }
          catch (IllegalAccessException a) {
            throw new IllegalStateException(a.getMessage());
          }


        if ((null != result) && (null != savedState))
        {
          ((StateHolder)result).restoreState(context, savedState);
        }
        this.tranzient = result;
      }
    }
    else
      this.tranzient = ((ValueBinding)state);
  }

  public boolean isTransient()
  {
    return this.tranzient;
  }

  public void setTransient(boolean newTransientValue) {
    this.tranzient = newTransientValue;
  }

  private static Class loadClass(String name, Object fallbackClass)
    throws ClassNotFoundException
  {
    ClassLoader loader = Thread.currentThread().getContextClassLoader();

    if (loader == null)
      loader = fallbackClass.getClass().getClassLoader();

    return Class.forName(name, true, loader);
  }

  public ValueBinding getWrapped()
  {
    return this.tranzient;
  }
}