package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

public class UIParameter extends UIComponentBase
{
  public static final String COMPONENT_TYPE = "javax.faces.Parameter";
  public static final String COMPONENT_FAMILY = "javax.faces.Parameter";
  private String name = null;
  private Object value = null;
  private Object[] values;

  public UIParameter()
  {
    setRendererType(null);
  }

  public String getFamily()
  {
    return "javax.faces.Parameter";
  }

  public String getName()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("name");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setName(String name)
  {
    this.value = name;
  }

  public Object getValue()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    this.value = value;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[3];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = this.value;
    this.values[2] = this.value;
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.value = ((String)this.values[1]);
    this.value = this.values[2];
  }
}