package javax.faces.component;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.FacesEvent;
import javax.faces.event.PhaseId;
import javax.faces.model.ArrayDataModel;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.ResultDataModel;
import javax.faces.model.ResultSetDataModel;
import javax.faces.model.ScalarDataModel;
import javax.servlet.jsp.jstl.sql.Result;

public class UIData extends UIComponentBase
  implements NamingContainer
{
  public static final String COMPONENT_TYPE = "javax.faces.Data";
  public static final String COMPONENT_FAMILY = "javax.faces.Data";
  private int first = 0;
  private boolean firstSet = false;
  private transient DataModel model = null;
  private transient Object oldVar;
  private int rowIndex = -1;
  private int rows = 0;
  private boolean rowsSet = false;
  private Map saved = new HashMap();
  private Object value = null;
  private String var = null;
  private Object[] values;

  public UIData()
  {
    setRendererType("javax.faces.Table");
  }

  public String getFamily()
  {
    return "javax.faces.Data";
  }

  public int getFirst()
  {
    if (this.firstSet)
      return this.var;

    ValueExpression ve = getValueExpression("first");
    if (ve != null) {
      Integer value = null;
      try {
        value = (Integer)ve.getValue(getFacesContext().getELContext());
      }
      catch (ELException e) {
        throw new FacesException(e);
      }
      if (null == value)
        return this.var;

      return value.intValue();
    }
    return this.var;
  }

  public void setFirst(int first)
  {
    if (first < 0)
      throw new IllegalArgumentException("" + first);

    this.var = first;
    this.firstSet = true;
  }

  public UIComponent getFooter()
  {
    return getFacet("footer");
  }

  public void setFooter(UIComponent footer)
  {
    getFacets().put("footer", footer);
  }

  public UIComponent getHeader()
  {
    return getFacet("header");
  }

  public void setHeader(UIComponent header)
  {
    getFacets().put("header", header);
  }

  public boolean isRowAvailable()
  {
    return getDataModel().isRowAvailable();
  }

  public int getRowCount()
  {
    return getDataModel().getRowCount();
  }

  public Object getRowData()
  {
    return getDataModel().getRowData();
  }

  public int getRowIndex()
  {
    return this.rowIndex;
  }

  public void setRowIndex(int rowIndex)
  {
    saveDescendantState();

    int previous = this.rowIndex;
    this.rowIndex = rowIndex;
    DataModel localModel = getDataModel();
    localModel.setRowIndex(rowIndex);

    if (this.var != null) {
      Map requestMap = getFacesContext().getExternalContext().getRequestMap();

      if (rowIndex == -1)
        this.oldVar = requestMap.remove(this.var);
      else if (isRowAvailable())
        requestMap.put(this.var, getRowData());
      else {
        requestMap.remove(this.var);
        if (null != this.oldVar) {
          requestMap.put("var", this.oldVar);
          this.oldVar = null;
        }
      }

    }

    restoreDescendantState();
  }

  public int getRows()
  {
    if (this.rowsSet)
      return this.rows;

    ValueExpression ve = getValueExpression("rows");
    if (ve != null) {
      Integer value = null;
      try {
        value = (Integer)ve.getValue(getFacesContext().getELContext());
      }
      catch (ELException e) {
        throw new FacesException(e);
      }

      if (null == value)
        return this.rows;

      return value.intValue();
    }
    return this.rows;
  }

  public void setRows(int rows)
  {
    if (rows < 0)
      throw new IllegalArgumentException("" + rows);

    this.rows = rows;
    this.rowsSet = true;
  }

  public String getVar()
  {
    return this.var;
  }

  public void setVar(String var)
  {
    this.var = var;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[9];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = new Integer(this.var);
    this.values[2] = ((this.firstSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[3] = new Integer(this.rowIndex);
    this.values[4] = new Integer(this.rows);
    this.values[5] = ((this.rowsSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[6] = this.saved;
    this.values[7] = this.value;
    this.values[8] = this.var;
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.var = ((Integer)this.values[1]).intValue();
    this.firstSet = ((Boolean)this.values[2]).booleanValue();
    this.rowIndex = ((Integer)this.values[3]).intValue();
    this.rows = ((Integer)this.values[4]).intValue();
    this.rowsSet = ((Boolean)this.values[5]).booleanValue();
    this.saved = ((Map)this.values[6]);
    this.value = this.values[7];
    this.var = ((String)this.values[8]);
  }

  public Object getValue()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    setDataModel(null);
    this.value = value;
  }

  /**
   * @deprecated
   */
  public void setValueBinding(String name, ValueBinding binding)
  {
    if ("value".equals(name))
      setDataModel(null);
    else if (("var".equals(name)) || ("rowIndex".equals(name)))
      throw new IllegalArgumentException();

    super.setValueBinding(name, binding);
  }

  public void setValueExpression(String name, ValueExpression binding)
  {
    if ("value".equals(name))
      this.model = null;
    else if (("var".equals(name)) || ("rowIndex".equals(name)))
      throw new IllegalArgumentException();

    super.setValueExpression(name, binding);
  }

  public String getClientId(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    String baseClientId = super.getClientId(context);
    if (this.rowIndex >= 0)
      return baseClientId + ':' + this.rowIndex;

    return baseClientId;
  }

  public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback)
    throws FacesException
  {
    if ((null == context) || (null == clientId) || (null == callback)) {
      throw new NullPointerException();
    }

    String myId = super.getClientId(context);
    boolean found = false;
    if (clientId.equals(myId));
    try {
      callback.invokeContextCallback(context, this);
      return true;
    }
    catch (Exception lastSep) {
      throw new FacesException(e);

      int savedRowIndex = getRowIndex();
      try
      {
        if (myId.endsWith("" + savedRowIndex)) {
          int lastSep = myId.lastIndexOf(58);
          if ((!($assertionsDisabled)) && (-1 == lastSep)) throw new AssertionError();
          myId = myId.substring(0, lastSep);
        }

        if (clientId.startsWith(myId))
        {
          int preRowIndexSep;
          if ((-1 != (preRowIndexSep = clientId.indexOf(58, myId.length()))) && 
            (++preRowIndexSep < clientId.length())) {
            int postRowIndexSep;
            if (-1 != (postRowIndexSep = clientId.indexOf(58, preRowIndexSep + 1)))
            {
              int newRow;
              try {
                newRow = Integer.valueOf(clientId.substring(preRowIndexSep, postRowIndexSep)).intValue();
              }
              catch (NumberFormatException ex)
              {
                String message = "Trying to extract rowIndex from clientId '" + clientId + "' " + ex.getMessage();

                throw new NumberFormatException(message);
              }
              setRowIndex(newRow);
              if (isRowAvailable())
                found = super.invokeOnComponent(context, clientId, callback);
            }
          }

        }

      }
      catch (FacesException fe)
      {
      }
      catch (Exception e)
      {
      }
      finally
      {
        setRowIndex(savedRowIndex);
      }
      return found;
    }
  }

  public void queueEvent(FacesEvent event)
  {
    super.queueEvent(new WrapperEvent(this, event, getRowIndex()));
  }

  public void broadcast(FacesEvent event)
    throws AbortProcessingException
  {
    if (!(event instanceof WrapperEvent)) {
      super.broadcast(event);
      return;
    }

    WrapperEvent revent = (WrapperEvent)event;
    if (isNestedWithinUIData())
      setDataModel(null);

    int oldRowIndex = getRowIndex();
    setRowIndex(revent.getRowIndex());
    FacesEvent rowEvent = revent.getFacesEvent();
    rowEvent.getComponent().broadcast(rowEvent);
    setRowIndex(oldRowIndex);
  }

  public void encodeBegin(FacesContext context)
    throws IOException
  {
    setDataModel(null);
    if (!(keepSaved(context)))
      this.saved = new HashMap();

    super.encodeBegin(context);
  }

  public void processDecodes(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered())) {
      return;
    }

    setDataModel(null);
    if ((null == this.saved) || (!(keepSaved(context)))) {
      this.saved = new HashMap();
    }

    iterate(context, PhaseId.APPLY_REQUEST_VALUES);
    decode(context);
  }

  public void processValidators(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered()))
      return;

    if (isNestedWithinUIData())
      setDataModel(null);

    iterate(context, PhaseId.PROCESS_VALIDATIONS);
  }

  public void processUpdates(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isRendered()))
      return;

    if (isNestedWithinUIData())
      setDataModel(null);

    iterate(context, PhaseId.UPDATE_MODEL_VALUES);
  }

  protected DataModel getDataModel()
  {
    if (this.model != null) {
      return this.model;
    }

    Object current = getValue();
    if (current == null)
      setDataModel(new ListDataModel(Collections.EMPTY_LIST));
    else if (current instanceof DataModel)
      setDataModel((DataModel)current);
    else if (current instanceof List)
      setDataModel(new ListDataModel((List)current));
    else if ([Ljava.lang.Object.class.isAssignableFrom(current.getClass()))
      setDataModel(new ArrayDataModel((Object[])(Object[])current));
    else if (current instanceof ResultSet)
      setDataModel(new ResultSetDataModel((ResultSet)current));
    else if (current instanceof Result)
      setDataModel(new ResultDataModel((Result)current));
    else
      setDataModel(new ScalarDataModel(current));

    return this.model;
  }

  protected void setDataModel(DataModel dataModel)
  {
    this.model = dataModel;
  }

  private void iterate(FacesContext context, PhaseId phaseId)
  {
    setRowIndex(-1);
    Iterator facets = getFacets().keySet().iterator();
    while (facets.hasNext()) {
      UIComponent facet = (UIComponent)getFacets().get(facets.next());

      if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
        facet.processDecodes(context);
      else if (phaseId == PhaseId.PROCESS_VALIDATIONS)
        facet.processValidators(context);
      else if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
        facet.processUpdates(context);
      else {
        throw new IllegalArgumentException();
      }

    }

    setRowIndex(-1);
    Iterator columns = getChildren().iterator();
    while (true) { UIComponent column;
      while (true) { while (true) { if (!(columns.hasNext())) break label279;
          column = (UIComponent)columns.next();
          if (column instanceof UIColumn)
            break;
        }
        if (column.isRendered())
          break;
      }
      Iterator columnFacets = column.getFacets().keySet().iterator();
      while (columnFacets.hasNext()) {
        UIComponent columnFacet = (UIComponent)column.getFacets().get(columnFacets.next());

        if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
          columnFacet.processDecodes(context);
        else if (phaseId == PhaseId.PROCESS_VALIDATIONS)
          columnFacet.processValidators(context);
        else if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
          columnFacet.processUpdates(context);
        else
          throw new IllegalArgumentException();

      }

    }

    label279: int processed = 0;
    int rowIndex = getFirst() - 1;
    int rows = getRows();
    while (true)
    {
      if ((rows > 0) && (++processed > rows)) {
        break;
      }

      setRowIndex(++rowIndex);
      if (!(isRowAvailable())) {
        break;
      }

      Iterator kids = getChildren().iterator();
      while (true) { UIComponent kid;
        while (true) { if (!(kids.hasNext())) break label484;
          kid = (UIComponent)kids.next();
          if (kid instanceof UIColumn)
            break;
        }
        Iterator grandkids = kid.getChildren().iterator();
        while (true) { UIComponent grandkid;
          while (true) { if (!(grandkids.hasNext())) break label481;
            grandkid = (UIComponent)grandkids.next();
            if (grandkid.isRendered())
              break;
          }
          label481: label484: if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
            grandkid.processDecodes(context);
          else if (phaseId == PhaseId.PROCESS_VALIDATIONS)
            grandkid.processValidators(context);
          else if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
            grandkid.processUpdates(context);
          else
            throw new IllegalArgumentException();

        }

      }

    }

    setRowIndex(-1);
  }

  private boolean keepSaved(FacesContext context)
  {
    Iterator clientIds = this.saved.keySet().iterator();
    while (clientIds.hasNext()) {
      String clientId = (String)clientIds.next();
      Iterator messages = context.getMessages(clientId);
      while (messages.hasNext()) {
        FacesMessage message = (FacesMessage)messages.next();
        if (message.getSeverity().compareTo(FacesMessage.SEVERITY_ERROR) >= 0)
        {
          return true;
        }
      }
    }
    return isNestedWithinUIData();
  }

  private boolean isNestedWithinUIData()
  {
    UIComponent parent = this;
    do if (null == (parent = parent.getParent())) break label21;
    while (!(parent instanceof UIData));
    return true;

    label21: return false;
  }

  private void restoreDescendantState()
  {
    FacesContext context = getFacesContext();
    Iterator kids = getChildren().iterator();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      if (kid instanceof UIColumn)
        restoreDescendantState(kid, context);
    }
  }

  private void restoreDescendantState(UIComponent component, FacesContext context)
  {
    String id = component.getId();
    component.setId(id);

    if (component instanceof EditableValueHolder) {
      EditableValueHolder input = (EditableValueHolder)component;
      String clientId = component.getClientId(context);
      SavedState state = (SavedState)this.saved.get(clientId);
      if (state == null)
        state = new SavedState();

      input.setValue(state.getValue());
      input.setValid(state.isValid());
      input.setSubmittedValue(state.getSubmittedValue());

      input.setLocalValueSet(state.isLocalValueSet());
    }

    Iterator kids = component.getChildren().iterator();
    while (kids.hasNext()) {
      restoreDescendantState((UIComponent)kids.next(), context);
    }

    Iterator facetNames = component.getFacets().keySet().iterator();
    while (facetNames.hasNext()) {
      UIComponent c = component.getFacet((String)facetNames.next());
      if (c != null)
        restoreDescendantState(c, context);
    }
  }

  private void saveDescendantState()
  {
    FacesContext context = getFacesContext();
    Iterator kids = getChildren().iterator();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      if (kid instanceof UIColumn)
        saveDescendantState(kid, context);
    }
  }

  private void saveDescendantState(UIComponent component, FacesContext context)
  {
    if (component instanceof EditableValueHolder) {
      EditableValueHolder input = (EditableValueHolder)component;
      String clientId = component.getClientId(context);
      SavedState state = (SavedState)this.saved.get(clientId);
      if (state == null) {
        state = new SavedState();
        this.saved.put(clientId, state);
      }
      state.setValue(input.getLocalValue());
      state.setValid(input.isValid());
      state.setSubmittedValue(input.getSubmittedValue());
      state.setLocalValueSet(input.isLocalValueSet());
    }

    Iterator kids = component.getChildren().iterator();
    while (kids.hasNext()) {
      saveDescendantState((UIComponent)kids.next(), context);
    }

    Iterator facetNames = component.getFacets().keySet().iterator();
    while (facetNames.hasNext()) {
      UIComponent c = component.getFacet((String)facetNames.next());
      if (c != null)
        saveDescendantState(c, context);
    }
  }
}