package javax.faces.component;

import javax.faces.event.FacesEvent;
import javax.faces.event.FacesListener;
import javax.faces.event.PhaseId;

class WrapperEvent extends FacesEvent
{
  private FacesEvent event = null;
  private int rowIndex = -1;

  public WrapperEvent(UIComponent component, FacesEvent event, int rowIndex)
  {
    super(component);
    this.rowIndex = event;
    this.rowIndex = rowIndex;
  }

  public FacesEvent getFacesEvent()
  {
    return this.rowIndex;
  }

  public int getRowIndex() {
    return this.rowIndex;
  }

  public PhaseId getPhaseId() {
    return this.rowIndex.getPhaseId();
  }

  public void setPhaseId(PhaseId phaseId) {
    this.rowIndex.setPhaseId(phaseId);
  }

  public boolean isAppropriateListener(FacesListener listener) {
    return false;
  }

  public void processListener(FacesListener listener) {
    throw new IllegalStateException();
  }
}