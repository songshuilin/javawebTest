package javax.faces.component;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.MethodBinding;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
import javax.faces.render.Renderer;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class UIInput extends UIOutput
  implements EditableValueHolder
{
  public static final String COMPONENT_TYPE = "javax.faces.Input";
  public static final String COMPONENT_FAMILY = "javax.faces.Input";
  public static final String CONVERSION_MESSAGE_ID = "javax.faces.component.UIInput.CONVERSION";
  public static final String REQUIRED_MESSAGE_ID = "javax.faces.component.UIInput.REQUIRED";
  public static final String UPDATE_MESSAGE_ID = "javax.faces.component.UIInput.UPDATE";
  private Object submittedValue = null;
  private boolean localValueSet;
  private boolean required = false;
  private boolean requiredSet = false;
  private String requiredMessage = null;
  private boolean requiredMessageSet = false;
  private String converterMessage = null;
  private boolean converterMessageSet = false;
  private String validatorMessage = null;
  private boolean validatorMessageSet = false;
  private boolean valid = true;
  private boolean immediate = false;
  private boolean immediateSet = false;
  List<Validator> validators = null;
  private Object[] values;

  public UIInput()
  {
    setRendererType("javax.faces.Text");
  }

  public String getFamily()
  {
    return "javax.faces.Input";
  }

  public Object getSubmittedValue()
  {
    return this.validators;
  }

  public void setSubmittedValue(Object submittedValue)
  {
    this.validators = submittedValue;
  }

  public void setValue(Object value)
  {
    super.setValue(value);

    setLocalValueSet(true);
  }

  public void resetValue()
  {
    setValue(null);
    setSubmittedValue(null);
    setLocalValueSet(false);
    setValid(true);
  }

  public boolean isLocalValueSet()
  {
    return this.localValueSet;
  }

  public void setLocalValueSet(boolean localValueSet)
  {
    this.localValueSet = localValueSet;
  }

  public boolean isRequired()
  {
    if (this.requiredSet)
      return this.required;

    ValueExpression ve = getValueExpression("required");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.required;
    }
  }

  public String getRequiredMessage()
  {
    if (this.requiredMessageSet) {
      return this.requiredMessage;
    }

    ValueExpression ve = getValueExpression("requiredMessage");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.requiredMessage;
    }
  }

  public void setRequiredMessage(String message)
  {
    this.requiredMessageSet = true;
    this.requiredMessage = message;
  }

  public String getConverterMessage()
  {
    if (this.converterMessageSet) {
      return this.converterMessage;
    }

    ValueExpression ve = getValueExpression("converterMessage");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.converterMessage;
    }
  }

  public void setConverterMessage(String message)
  {
    this.converterMessageSet = true;
    this.converterMessage = message;
  }

  public String getValidatorMessage()
  {
    if (this.validatorMessageSet) {
      return this.validatorMessage;
    }

    ValueExpression ve = getValueExpression("validatorMessage");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.validatorMessage;
    }
  }

  public void setValidatorMessage(String message)
  {
    this.validatorMessageSet = true;
    this.validatorMessage = message;
  }

  public boolean isValid()
  {
    return this.valid;
  }

  public void setValid(boolean valid)
  {
    this.valid = valid;
  }

  public void setRequired(boolean required)
  {
    this.required = required;
    this.requiredSet = true;
  }

  public boolean isImmediate()
  {
    if (this.immediateSet)
      return this.immediate;

    ValueExpression ve = getValueExpression("immediate");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.immediate;
    }
  }

  public void setImmediate(boolean immediate)
  {
    if (immediate != this.immediate)
      this.immediate = immediate;

    this.immediateSet = true;
  }

  /**
   * @deprecated
   */
  public MethodBinding getValidator()
  {
    MethodBinding result = null;

    Validator[] curValidators = getValidators();

    if (null != curValidators)
      for (int i = 0; i < curValidators.length; ++i)
      {
        if (MethodBindingValidator.class == curValidators[i].getClass())
        {
          result = ((MethodBindingValidator)curValidators[i]).getWrapped();

          break;
        }
      }

    return result;
  }

  /**
   * @deprecated
   */
  public void setValidator(MethodBinding validatorBinding)
  {
    Validator[] curValidators = getValidators();

    if (null != curValidators)
      for (int i = 0; i < curValidators.length; ++i)
      {
        if (null == validatorBinding)
        {
          if (MethodBindingValidator.class != curValidators[i].getClass())
            break label60;
          removeValidator(curValidators[i]);
          return;
        }

        if (validatorBinding == curValidators[i]) {
          removeValidator(curValidators[i]);
          label60: break;
        }
      }

    addValidator(new MethodBindingValidator(validatorBinding));
  }

  public MethodBinding getValueChangeListener()
  {
    MethodBinding result = null;

    ValueChangeListener[] curListeners = getValueChangeListeners();

    if (null != curListeners)
      for (int i = 0; i < curListeners.length; ++i)
      {
        if (MethodBindingValueChangeListener.class == curListeners[i].getClass())
        {
          result = ((MethodBindingValueChangeListener)curListeners[i]).getWrapped();

          break;
        }
      }

    return result;
  }

  /**
   * @deprecated
   */
  public void setValueChangeListener(MethodBinding valueChangeListener)
  {
    ValueChangeListener[] curListeners = getValueChangeListeners();

    if (null != curListeners)
      for (int i = 0; i < curListeners.length; ++i)
      {
        if (null == valueChangeListener)
        {
          if (MethodBindingValueChangeListener.class != curListeners[i].getClass())
            break label60;
          removeFacesListener(curListeners[i]);
          return;
        }

        if (valueChangeListener == curListeners[i]) {
          removeFacesListener(curListeners[i]);
          label60: break;
        }
      }

    addValueChangeListener(new MethodBindingValueChangeListener(valueChangeListener));
  }

  public void processDecodes(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    super.processDecodes(context);

    if (isImmediate())
      executeValidate(context);
  }

  public void processValidators(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    super.processValidators(context);
    if (!(isImmediate()))
      executeValidate(context);
  }

  public void processUpdates(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (!(isRendered())) {
      return;
    }

    super.processUpdates(context);
    try
    {
      updateModel(context);
    } catch (RuntimeException e) {
      context.renderResponse();
      throw e;
    }

    if (!(isValid()))
      context.renderResponse();
  }

  public void decode(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    setValid(true);
    super.decode(context);
  }

  public void updateModel(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if ((!(isValid())) || (!(isLocalValueSet())))
      return;

    ValueExpression ve = getValueExpression("value");
    if (ve != null) {
      FacesMessage message;
      try { ve.setValue(context.getELContext(), getLocalValue());
        setValue(null);
        setLocalValueSet(false);
        return;
      } catch (ELException e) {
        String messageStr = e.getMessage();
        Throwable result = e.getCause();
        while ((null != result) && (result.getClass().isAssignableFrom(ELException.class)))
        {
          messageStr = result.getMessage();
          result = result.getCause();
        }
        FacesMessage message = null;
        if (null == messageStr) {
          message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] { MessageFactory.getLabel(context, this) });
        }
        else
        {
          message = new FacesMessage(messageStr);
        }
        message.setSeverity(FacesMessage.SEVERITY_ERROR);
        context.addMessage(getClientId(context), message);
        setValid(false);
      } catch (IllegalArgumentException e) {
        message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] { MessageFactory.getLabel(context, this) });

        message.setSeverity(FacesMessage.SEVERITY_ERROR);
        context.addMessage(getClientId(context), message);
        setValid(false);
      } catch (Exception e) {
        message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] { MessageFactory.getLabel(context, this) });

        message.setSeverity(FacesMessage.SEVERITY_ERROR);
        context.addMessage(getClientId(context), message);
        setValid(false);
      }
    }
  }

  public void validate(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    Object submittedValue = getSubmittedValue();
    if (submittedValue == null) {
      return;
    }

    Object newValue = null;
    try
    {
      newValue = getConvertedValue(context, submittedValue);
    }
    catch (ConverterException ce) {
      addConversionErrorMessage(context, ce, submittedValue);
      setValid(false);
    }

    validateValue(context, newValue);

    if (isValid()) {
      Object previous = getValue();
      setValue(newValue);
      setSubmittedValue(null);
      if (compareValues(previous, newValue))
        queueEvent(new ValueChangeEvent(this, previous, newValue));
    }
  }

  protected Object getConvertedValue(FacesContext context, Object newSubmittedValue)
    throws ConverterException
  {
    Renderer renderer = getRenderer(context);
    Object newValue = null;

    if (renderer != null) {
      newValue = renderer.getConvertedValue(context, this, newSubmittedValue);
    }
    else if (newSubmittedValue instanceof String)
    {
      Converter converter = getConverterWithType(context);
      if (converter != null) {
        newValue = converter.getAsObject(context, this, (String)newSubmittedValue);
      }
      else
      {
        newValue = newSubmittedValue;
      }
    }
    else newValue = newSubmittedValue;

    return newValue;
  }

  protected void validateValue(FacesContext context, Object newValue)
  {
    if ((isValid()) && (isRequired()) && (isEmpty(newValue))) {
      String requiredMessageStr = getRequiredMessage();
      FacesMessage message = null;
      if (null != requiredMessageStr) {
        message = new FacesMessage(requiredMessageStr, requiredMessageStr);
      }
      else {
        message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.REQUIRED", new Object[] { MessageFactory.getLabel(context, this) });
      }

      message.setSeverity(FacesMessage.SEVERITY_ERROR);
      context.addMessage(getClientId(context), message);
      setValid(false);
    }

    if ((isValid()) && (!(isEmpty(newValue))) && 
      (this.validators != null)) {
      Iterator validators = this.validators.iterator();
      while (validators.hasNext()) {
        Validator validator = (Validator)validators.next();
        try {
          validator.validate(context, this, newValue);
        }
        catch (ValidatorException ve)
        {
          setValid(false);
          FacesMessage message = null;
          String validatorMessageString = getValidatorMessage();

          if (null != validatorMessageString) {
            message = new FacesMessage(validatorMessageString, validatorMessageString);
          }
          else
          {
            message = ve.getFacesMessage();
          }
          if (message != null) {
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            context.addMessage(getClientId(context), message);
          }
        }
      }
    }
  }

  protected boolean compareValues(Object previous, Object value)
  {
    if (previous == null)
      return (value != null);
    if (value == null)
      return true;

    return (!(previous.equals(value)));
  }

  private void executeValidate(FacesContext context)
  {
    try
    {
      validate(context);
    } catch (RuntimeException e) {
      context.renderResponse();
      throw e;
    }

    if (!(isValid()))
      context.renderResponse();
  }

  private boolean isEmpty(Object value)
  {
    if (value == null)
      return true;
    if ((value instanceof String) && (((String)value).length() < 1))
    {
      return true; }
    if (value.getClass().isArray()) {
      if (0 != Array.getLength(value)) break label68;
      return true;
    }

    label68: return ((value instanceof List) && 
      (0 == ((List)value).size()));
  }

  public void addValidator(Validator validator)
  {
    if (validator == null)
      throw new NullPointerException();

    if (this.validators == null)
      this.validators = new ArrayList();

    this.validators.add(validator);
  }

  public Validator[] getValidators()
  {
    if (this.validators == null)
      return new Validator[0];

    return ((Validator[])(Validator[])this.validators.toArray(new Validator[this.validators.size()]));
  }

  public void removeValidator(Validator validator)
  {
    if (this.validators != null)
      this.validators.remove(validator);
  }

  public void addValueChangeListener(ValueChangeListener listener)
  {
    addFacesListener(listener);
  }

  public ValueChangeListener[] getValueChangeListeners()
  {
    return ((ValueChangeListener[])(ValueChangeListener[])getFacesListeners(ValueChangeListener.class));
  }

  public void removeValueChangeListener(ValueChangeListener listener)
  {
    removeFacesListener(listener);
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[14];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = ((this.localValueSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[2] = ((this.required) ? Boolean.TRUE : Boolean.FALSE);
    this.values[3] = ((this.requiredSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[4] = this.requiredMessage;
    this.values[5] = ((this.requiredMessageSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[6] = this.converterMessage;
    this.values[7] = ((this.converterMessageSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[8] = this.validatorMessage;
    this.values[9] = ((this.validatorMessageSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[10] = ((this.valid) ? Boolean.TRUE : Boolean.FALSE);
    this.values[11] = ((this.immediate) ? Boolean.TRUE : Boolean.FALSE);
    this.values[12] = ((this.immediateSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[13] = saveAttachedState(context, this.validators);
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.localValueSet = ((Boolean)this.values[1]).booleanValue();
    this.required = ((Boolean)this.values[2]).booleanValue();
    this.requiredSet = ((Boolean)this.values[3]).booleanValue();
    this.requiredMessage = ((String)this.values[4]);
    this.requiredMessageSet = ((Boolean)this.values[5]).booleanValue();
    this.converterMessage = ((String)this.values[6]);
    this.converterMessageSet = ((Boolean)this.values[7]).booleanValue();
    this.validatorMessage = ((String)this.values[8]);
    this.validatorMessageSet = ((Boolean)this.values[9]).booleanValue();
    this.valid = ((Boolean)this.values[10]).booleanValue();
    this.immediate = ((Boolean)this.values[11]).booleanValue();
    this.immediateSet = ((Boolean)this.values[12]).booleanValue();
    List restoredValidators = null;
    Iterator iter = null;

    if (null != (restoredValidators = (List)restoreAttachedState(context, this.values[13])))
    {
      if (null != this.validators) {
        iter = restoredValidators.iterator();
        while (true) { if (!(iter.hasNext())) return;
          this.validators.add(iter.next());
        }
      }

      this.validators = restoredValidators;
    }
  }

  private Converter getConverterWithType(FacesContext context)
  {
    Converter converter = getConverter();
    if (converter != null) {
      return converter;
    }

    ValueExpression valueExpression = getValueExpression("value");
    if (valueExpression == null) {
      return null;
    }

    Class converterType = null;
    try {
      converterType = valueExpression.getType(context.getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);
    }

    if ((converterType == null) || (converterType == String.class) || (converterType == Object.class))
    {
      return null;
    }

    try
    {
      Application application = context.getApplication();
      return application.createConverter(converterType);
    } catch (Exception e) {
      return null;
    }
  }

  private void addConversionErrorMessage(FacesContext context, ConverterException ce, Object value)
  {
    FacesMessage message = null;
    String converterMessageString = getConverterMessage();
    if (null != converterMessageString)
      message = new FacesMessage(converterMessageString, converterMessageString);
    else
    {
      message = ce.getFacesMessage();
      if (message == null) {
        message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.CONVERSION", new Object[0]);

        if (message.getDetail() == null)
          message.setDetail(ce.getMessage());
      }

    }

    message.setSeverity(FacesMessage.SEVERITY_ERROR);
    context.addMessage(getClientId(context), message);
  }
}