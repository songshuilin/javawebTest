package javax.faces.component;

abstract class MethodBindingAdapterBase
{
  Throwable getExpectedCause(Class expectedExceptionClass, Throwable exception)
  {
    Throwable result = exception.getCause();
    if ((null != result) && 
      (!(result.getClass().isAssignableFrom(expectedExceptionClass)))) {
      result = getExpectedCause(expectedExceptionClass, result);
    }

    return result;
  }
}