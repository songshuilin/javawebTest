package javax.faces.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.faces.event.FacesEvent;
import javax.faces.event.PhaseId;

public class UICommand extends UIComponentBase
  implements ActionSource2
{
  public static final String COMPONENT_TYPE = "javax.faces.Command";
  public static final String COMPONENT_FAMILY = "javax.faces.Command";
  private Object value = null;
  private boolean immediate = false;
  private boolean immediateSet = false;
  private MethodBinding methodBindingActionListener = null;
  private MethodExpression actionExpression = null;
  private Object[] values;

  public UICommand()
  {
    setRendererType("javax.faces.Button");
  }

  public String getFamily()
  {
    return "javax.faces.Command";
  }

  /**
   * @deprecated
   */
  public MethodBinding getAction()
  {
    MethodBinding result = null;
    MethodExpression me = null;

    if (null != (me = getActionExpression()))
    {
      if (me.getClass() == MethodExpressionMethodBindingAdapter.class) {
        result = ((MethodExpressionMethodBindingAdapter)me).getWrapped();
      }
      else
      {
        result = new MethodBindingMethodExpressionAdapter(me);
      }
    }
    return result;
  }

  /**
   * @deprecated
   */
  public void setAction(MethodBinding action)
  {
    MethodExpressionMethodBindingAdapter adapter = null;
    if (null != action) {
      adapter = new MethodExpressionMethodBindingAdapter(action);
      setActionExpression(adapter);
    }
    else
      setActionExpression(null);
  }

  /**
   * @deprecated
   */
  public MethodBinding getActionListener()
  {
    return this.methodBindingActionListener;
  }

  /**
   * @deprecated
   */
  public void setActionListener(MethodBinding actionListener)
  {
    this.methodBindingActionListener = actionListener;
  }

  public boolean isImmediate()
  {
    if (this.immediateSet)
      return this.immediate;

    ValueExpression ve = getValueExpression("immediate");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.immediate;
    }
  }

  public void setImmediate(boolean immediate)
  {
    if (immediate != this.immediate)
      this.immediate = immediate;

    this.immediateSet = true;
  }

  public Object getValue()
  {
    if (this.actionExpression != null)
      return this.actionExpression;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    this.actionExpression = value;
  }

  public MethodExpression getActionExpression()
  {
    return this.actionExpression;
  }

  public void setActionExpression(MethodExpression actionExpression) {
    this.actionExpression = actionExpression;
  }

  public void addActionListener(ActionListener listener)
  {
    addFacesListener(listener);
  }

  public ActionListener[] getActionListeners()
  {
    ActionListener[] al = (ActionListener[])(ActionListener[])getFacesListeners(ActionListener.class);

    return al;
  }

  public void removeActionListener(ActionListener listener)
  {
    removeFacesListener(listener);
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[6];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = saveAttachedState(context, this.methodBindingActionListener);
    this.values[2] = saveAttachedState(context, this.actionExpression);
    this.values[3] = ((this.immediate) ? Boolean.TRUE : Boolean.FALSE);
    this.values[4] = ((this.immediateSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[5] = this.actionExpression;

    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.methodBindingActionListener = ((MethodBinding)restoreAttachedState(context, this.values[1]));

    this.actionExpression = ((MethodExpression)restoreAttachedState(context, this.values[2]));

    this.immediate = ((Boolean)this.values[3]).booleanValue();
    this.immediateSet = ((Boolean)this.values[4]).booleanValue();
    this.actionExpression = this.values[5];
  }

  public void broadcast(FacesEvent event)
    throws AbortProcessingException
  {
    super.broadcast(event);

    if (event instanceof ActionEvent) {
      FacesContext context = getFacesContext();

      MethodBinding mb = getActionListener();
      if (mb != null) {
        mb.invoke(context, new Object[] { event });
      }

      ActionListener listener = context.getApplication().getActionListener();

      if (listener != null)
        listener.processAction((ActionEvent)event);
    }
  }

  public void queueEvent(FacesEvent e)
  {
    if (e instanceof ActionEvent)
      if (isImmediate()) {
        e.setPhaseId(PhaseId.APPLY_REQUEST_VALUES);
      }
      else
        e.setPhaseId(PhaseId.INVOKE_APPLICATION);


    super.queueEvent(e);
  }
}