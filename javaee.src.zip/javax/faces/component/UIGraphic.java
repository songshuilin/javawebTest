package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

public class UIGraphic extends UIComponentBase
{
  public static final String COMPONENT_TYPE = "javax.faces.Graphic";
  public static final String COMPONENT_FAMILY = "javax.faces.Graphic";
  private Object value = null;
  private Object[] values;

  public UIGraphic()
  {
    setRendererType("javax.faces.Image");
  }

  public String getFamily()
  {
    return "javax.faces.Graphic";
  }

  public String getUrl()
  {
    return ((String)getValue());
  }

  public void setUrl(String url)
  {
    setValue(url);
  }

  public Object getValue()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    this.value = value;
  }

  /**
   * @deprecated
   */
  public ValueBinding getValueBinding(String name)
  {
    if ("url".equals(name))
      return super.getValueBinding("value");

    return super.getValueBinding(name);
  }

  /**
   * @deprecated
   */
  public void setValueBinding(String name, ValueBinding binding)
  {
    if ("url".equals(name))
      super.setValueBinding("value", binding);
    else
      super.setValueBinding(name, binding);
  }

  public ValueExpression getValueExpression(String name)
  {
    if ("url".equals(name))
      return super.getValueExpression("value");

    return super.getValueExpression(name);
  }

  public void setValueExpression(String name, ValueExpression binding)
  {
    if ("url".equals(name))
      super.setValueExpression("value", binding);
    else
      super.setValueExpression(name, binding);
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[2];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = this.value;
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.value = this.values[1];
  }
}