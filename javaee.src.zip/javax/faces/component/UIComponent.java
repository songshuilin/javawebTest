package javax.faces.component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.el.ELContext;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.FacesEvent;
import javax.faces.event.FacesListener;
import javax.faces.render.Renderer;

public abstract class UIComponent
  implements StateHolder
{
  protected Map<String, ValueExpression> bindings;
  private boolean isUIComponentBase;
  private boolean isUIComponentBaseIsSet;

  public UIComponent()
  {
    this.bindings = null;

    this.isUIComponentBaseIsSet = false;
  }

  public abstract Map<String, Object> getAttributes();

  /**
   * @deprecated
   */
  public abstract ValueBinding getValueBinding(String paramString);

  /**
   * @deprecated
   */
  public abstract void setValueBinding(String paramString, ValueBinding paramValueBinding);

  public ValueExpression getValueExpression(String name)
  {
    ValueExpression result = null;

    if (name == null)
      throw new NullPointerException();

    if (this.bindings == null) {
      if (!(isUIComponentBase())) {
        ValueBinding binding = getValueBinding(name);
        if (null != binding) {
          result = new ValueExpressionValueBindingAdapter(binding);

          this.bindings = new HashMap();
          this.bindings.put(name, result);
        }
      }
      return result;
    }
    return ((ValueExpression)this.bindings.get(name));
  }

  public void setValueExpression(String name, ValueExpression binding)
  {
    if (name == null)
      throw new NullPointerException();
    if (("id".equals(name)) || ("parent".equals(name)))
      throw new IllegalArgumentException();

    if (binding != null)
      if (!(binding.isLiteralText())) {
        if (this.bindings == null)
          this.bindings = new HashMap();

        this.bindings.put(name, binding);
      } else {
        ELContext context = FacesContext.getCurrentInstance().getELContext();
        try
        {
          getAttributes().put(name, binding.getValue(context));
        } catch (ELException ele) {
          throw new FacesException(ele);
        }
      }

    else if (this.bindings != null) {
      this.bindings.remove(name);
      if (this.bindings.size() == 0)
        this.bindings = null;
    }
  }

  public abstract String getClientId(FacesContext paramFacesContext);

  public String getContainerClientId(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    return getClientId(context);
  }

  public abstract String getFamily();

  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract UIComponent getParent();

  public abstract void setParent(UIComponent paramUIComponent);

  public abstract boolean isRendered();

  public abstract void setRendered(boolean paramBoolean);

  public abstract String getRendererType();

  public abstract void setRendererType(String paramString);

  public abstract boolean getRendersChildren();

  private boolean isUIComponentBase()
  {
    if (!(this.isUIComponentBaseIsSet)) {
      this.isUIComponentBase = this instanceof UIComponentBase;
    }

    return this.isUIComponentBase;
  }

  public abstract List<UIComponent> getChildren();

  public abstract int getChildCount();

  public abstract UIComponent findComponent(String paramString);

  public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback)
    throws FacesException
  {
    if ((null == context) || (null == clientId) || (null == callback)) {
      throw new NullPointerException();
    }

    boolean found = false;
    if (clientId.equals(getClientId(context)));
    try {
      callback.invokeContextCallback(context, this);
      return true;
    } catch (Exception itr) {
      throw new FacesException(e);

      Iterator itr = getFacetsAndChildren();

      while ((itr.hasNext()) && (!(found))) {
        found = ((UIComponent)itr.next()).invokeOnComponent(context, clientId, callback);
      }

      return found;
    }
  }

  public abstract Map<String, UIComponent> getFacets();

  public int getFacetCount()
  {
    return getFacets().size();
  }

  public abstract UIComponent getFacet(String paramString);

  public abstract Iterator<UIComponent> getFacetsAndChildren();

  public abstract void broadcast(FacesEvent paramFacesEvent)
    throws AbortProcessingException;

  public abstract void decode(FacesContext paramFacesContext);

  public abstract void encodeBegin(FacesContext paramFacesContext)
    throws IOException;

  public abstract void encodeChildren(FacesContext paramFacesContext)
    throws IOException;

  public abstract void encodeEnd(FacesContext paramFacesContext)
    throws IOException;

  public void encodeAll(FacesContext context)
    throws IOException
  {
    if (!(isRendered())) {
      return;
    }

    encodeBegin(context);
    if (getRendersChildren()) {
      encodeChildren(context);
    }
    else if (getChildCount() > 0) {
      Iterator kids = getChildren().iterator();
      while (kids.hasNext()) {
        UIComponent kid = (UIComponent)kids.next();
        kid.encodeAll(context);
      }
    }

    encodeEnd(context);
  }

  protected abstract void addFacesListener(FacesListener paramFacesListener);

  protected abstract FacesListener[] getFacesListeners(Class paramClass);

  protected abstract void removeFacesListener(FacesListener paramFacesListener);

  public abstract void queueEvent(FacesEvent paramFacesEvent);

  public abstract void processRestoreState(FacesContext paramFacesContext, Object paramObject);

  public abstract void processDecodes(FacesContext paramFacesContext);

  public abstract void processValidators(FacesContext paramFacesContext);

  public abstract void processUpdates(FacesContext paramFacesContext);

  public abstract Object processSaveState(FacesContext paramFacesContext);

  protected abstract FacesContext getFacesContext();

  protected abstract Renderer getRenderer(FacesContext paramFacesContext);
}