package javax.faces.component;

import javax.faces.context.FacesContext;

public abstract interface StateHolder
{
  public abstract Object saveState(FacesContext paramFacesContext);

  public abstract void restoreState(FacesContext paramFacesContext, Object paramObject);

  public abstract boolean isTransient();

  public abstract void setTransient(boolean paramBoolean);
}