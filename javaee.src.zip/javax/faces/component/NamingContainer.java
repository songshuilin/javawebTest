package javax.faces.component;

public abstract interface NamingContainer
{
  public static final char SEPARATOR_CHAR = 58;
}