package javax.faces.component;

import java.io.Serializable;

class SavedState
  implements Serializable
{
  private Object submittedValue;
  private static final long serialVersionUID = -687106727L;
  private boolean valid;
  private Object value;
  private boolean localValueSet;

  SavedState()
  {
    this.valid = true;
  }

  Object getSubmittedValue()
  {
    return this.submittedValue; }

  void setSubmittedValue(Object submittedValue) {
    this.submittedValue = submittedValue;
  }

  boolean isValid()
  {
    return this.valid; }

  void setValid(boolean valid) {
    this.valid = valid;
  }

  Object getValue()
  {
    return this.value; }

  public void setValue(Object value) {
    this.value = value;
  }

  boolean isLocalValueSet()
  {
    return this.localValueSet; }

  public void setLocalValueSet(boolean localValueSet) {
    this.localValueSet = localValueSet;
  }

  public String toString() {
    return "submittedValue: " + this.submittedValue + " value: " + this.value + " localValueSet: " + this.localValueSet;
  }
}