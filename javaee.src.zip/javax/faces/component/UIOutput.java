package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

public class UIOutput extends UIComponentBase
  implements ValueHolder
{
  public static final String COMPONENT_TYPE = "javax.faces.Output";
  public static final String COMPONENT_FAMILY = "javax.faces.Output";
  private Converter converter = null;
  private Object value = null;
  private Object[] values;

  public UIOutput()
  {
    setRendererType("javax.faces.Text");
  }

  public String getFamily()
  {
    return "javax.faces.Output";
  }

  public Converter getConverter()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("converter");
    if (ve != null);
    try {
      return ((Converter)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setConverter(Converter converter)
  {
    this.value = converter;
  }

  public Object getLocalValue()
  {
    return this.value;
  }

  public Object getValue()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    this.value = value;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[3];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = saveAttachedState(context, this.value);
    this.values[2] = this.value;
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.value = ((Converter)restoreAttachedState(context, this.values[1]));
    this.value = this.values[2];
  }
}