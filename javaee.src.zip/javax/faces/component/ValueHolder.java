package javax.faces.component;

import javax.faces.convert.Converter;

public abstract interface ValueHolder
{
  public abstract Object getLocalValue();

  public abstract Object getValue();

  public abstract void setValue(Object paramObject);

  public abstract Converter getConverter();

  public abstract void setConverter(Converter paramConverter);
}