package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ValueChangeListener;
import javax.faces.validator.Validator;

public abstract interface EditableValueHolder
  implements ValueHolder
{
  public abstract Object getSubmittedValue();

  public abstract void setSubmittedValue(Object paramObject);

  public abstract boolean isLocalValueSet();

  public abstract void setLocalValueSet(boolean paramBoolean);

  public abstract boolean isValid();

  public abstract void setValid(boolean paramBoolean);

  public abstract boolean isRequired();

  public abstract void setRequired(boolean paramBoolean);

  public abstract boolean isImmediate();

  public abstract void setImmediate(boolean paramBoolean);

  /**
   * @deprecated
   */
  public abstract MethodBinding getValidator();

  /**
   * @deprecated
   */
  public abstract void setValidator(MethodBinding paramMethodBinding);

  /**
   * @deprecated
   */
  public abstract MethodBinding getValueChangeListener();

  /**
   * @deprecated
   */
  public abstract void setValueChangeListener(MethodBinding paramMethodBinding);

  public abstract void addValidator(Validator paramValidator);

  public abstract Validator[] getValidators();

  public abstract void removeValidator(Validator paramValidator);

  public abstract void addValueChangeListener(ValueChangeListener paramValueChangeListener);

  public abstract ValueChangeListener[] getValueChangeListeners();

  public abstract void removeValueChangeListener(ValueChangeListener paramValueChangeListener);
}