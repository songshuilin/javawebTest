package javax.faces.component;

import java.util.Map;

public class UIColumn extends UIComponentBase
{
  public static final String COMPONENT_TYPE = "javax.faces.Column";
  public static final String COMPONENT_FAMILY = "javax.faces.Column";

  public UIColumn()
  {
    setRendererType(null);
  }

  public String getFamily()
  {
    return "javax.faces.Column";
  }

  public UIComponent getFooter()
  {
    return getFacet("footer");
  }

  public void setFooter(UIComponent footer)
  {
    getFacets().put("footer", footer);
  }

  public UIComponent getHeader()
  {
    return getFacet("header");
  }

  public void setHeader(UIComponent header)
  {
    getFacets().put("header", header);
  }
}