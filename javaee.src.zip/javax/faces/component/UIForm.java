package javax.faces.component;

import java.util.Iterator;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

public class UIForm extends UIComponentBase
  implements NamingContainer
{
  public static final String COMPONENT_TYPE = "javax.faces.Form";
  public static final String COMPONENT_FAMILY = "javax.faces.Form";
  private boolean submitted = false;
  private boolean prependId = true;
  private boolean prependIdSet = false;

  public UIForm()
  {
    setRendererType("javax.faces.Form");
  }

  public String getFamily()
  {
    return "javax.faces.Form";
  }

  public boolean isSubmitted()
  {
    return this.prependIdSet;
  }

  public void setSubmitted(boolean submitted)
  {
    this.prependIdSet = submitted;
  }

  public boolean isPrependId()
  {
    if (this.prependIdSet)
      return this.prependId;

    ValueExpression ve = getValueExpression("prependId");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.prependId;
    }
  }

  public void setPrependId(boolean prependId)
  {
    if (prependId != this.prependId)
      this.prependId = prependId;

    this.prependIdSet = true;
  }

  public void processDecodes(FacesContext context)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    decode(context);

    if (!(isSubmitted())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processDecodes(context);
    }
  }

  public void processValidators(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isSubmitted())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processValidators(context);
    }
  }

  public void processUpdates(FacesContext context)
  {
    if (context == null)
      throw new NullPointerException();

    if (!(isSubmitted())) {
      return;
    }

    Iterator kids = getFacetsAndChildren();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      kid.processUpdates(context);
    }
  }

  public String getContainerClientId(FacesContext context)
  {
    if (isPrependId())
      return super.getContainerClientId(context);

    UIComponent parent = getParent();
    while (parent != null) {
      if (parent instanceof NamingContainer)
        return parent.getContainerClientId(context);

      parent = parent.getParent();
    }

    return null;
  }
}