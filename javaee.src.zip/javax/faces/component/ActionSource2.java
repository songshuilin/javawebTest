package javax.faces.component;

import javax.el.MethodExpression;

public abstract interface ActionSource2
  implements ActionSource
{
  public abstract MethodExpression getActionExpression();

  public abstract void setActionExpression(MethodExpression paramMethodExpression);
}