package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UISelectMany;
import javax.faces.context.FacesContext;

public class HtmlSelectManyListbox extends UISelectMany
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlSelectManyListbox";
  private String accesskey;
  private String dir;
  private boolean disabled = false;
  private boolean disabled_set = false;
  private String disabledClass;
  private String enabledClass;
  private String label;
  private String lang;
  private String onblur;
  private String onchange;
  private String onclick;
  private String ondblclick;
  private String onfocus;
  private String onkeydown;
  private String onkeypress;
  private String onkeyup;
  private String onmousedown;
  private String onmousemove;
  private String onmouseout;
  private String onmouseover;
  private String onmouseup;
  private String onselect;
  private boolean readonly = false;
  private boolean readonly_set = false;
  private int size = -2147483648;
  private boolean size_set = false;
  private String style;
  private String styleClass;
  private String tabindex;
  private String title;
  private Object[] _values;

  public HtmlSelectManyListbox()
  {
    setRendererType("javax.faces.Listbox");
  }

  public String getAccesskey()
  {
    if (null != this.accesskey)
      return this.accesskey;

    ValueExpression _ve = getValueExpression("accesskey");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setAccesskey(String accesskey)
  {
    this.accesskey = accesskey;
  }

  public String getDir()
  {
    if (null != this.dir)
      return this.dir;

    ValueExpression _ve = getValueExpression("dir");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setDir(String dir)
  {
    this.dir = dir;
  }

  public boolean isDisabled()
  {
    if (this.disabled_set)
      return this.size_set;

    ValueExpression _ve = getValueExpression("disabled");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.size_set;
  }

  public void setDisabled(boolean disabled)
  {
    this.size_set = disabled;
    this.disabled_set = true;
  }

  public String getDisabledClass()
  {
    if (null != this.disabledClass)
      return this.disabledClass;

    ValueExpression _ve = getValueExpression("disabledClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setDisabledClass(String disabledClass)
  {
    this.disabledClass = disabledClass;
  }

  public String getEnabledClass()
  {
    if (null != this.enabledClass)
      return this.enabledClass;

    ValueExpression _ve = getValueExpression("enabledClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setEnabledClass(String enabledClass)
  {
    this.enabledClass = enabledClass;
  }

  public String getLabel()
  {
    if (null != this.label)
      return this.label;

    ValueExpression _ve = getValueExpression("label");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLabel(String label)
  {
    this.label = label;
  }

  public String getLang()
  {
    if (null != this.lang)
      return this.lang;

    ValueExpression _ve = getValueExpression("lang");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLang(String lang)
  {
    this.lang = lang;
  }

  public String getOnblur()
  {
    if (null != this.onblur)
      return this.onblur;

    ValueExpression _ve = getValueExpression("onblur");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnblur(String onblur)
  {
    this.onblur = onblur;
  }

  public String getOnchange()
  {
    if (null != this.onchange)
      return this.onchange;

    ValueExpression _ve = getValueExpression("onchange");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnchange(String onchange)
  {
    this.onchange = onchange;
  }

  public String getOnclick()
  {
    if (null != this.onclick)
      return this.onclick;

    ValueExpression _ve = getValueExpression("onclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnclick(String onclick)
  {
    this.onclick = onclick;
  }

  public String getOndblclick()
  {
    if (null != this.ondblclick)
      return this.ondblclick;

    ValueExpression _ve = getValueExpression("ondblclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOndblclick(String ondblclick)
  {
    this.ondblclick = ondblclick;
  }

  public String getOnfocus()
  {
    if (null != this.onfocus)
      return this.onfocus;

    ValueExpression _ve = getValueExpression("onfocus");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnfocus(String onfocus)
  {
    this.onfocus = onfocus;
  }

  public String getOnkeydown()
  {
    if (null != this.onkeydown)
      return this.onkeydown;

    ValueExpression _ve = getValueExpression("onkeydown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeydown(String onkeydown)
  {
    this.onkeydown = onkeydown;
  }

  public String getOnkeypress()
  {
    if (null != this.onkeypress)
      return this.onkeypress;

    ValueExpression _ve = getValueExpression("onkeypress");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeypress(String onkeypress)
  {
    this.onkeypress = onkeypress;
  }

  public String getOnkeyup()
  {
    if (null != this.onkeyup)
      return this.onkeyup;

    ValueExpression _ve = getValueExpression("onkeyup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeyup(String onkeyup)
  {
    this.onkeyup = onkeyup;
  }

  public String getOnmousedown()
  {
    if (null != this.onmousedown)
      return this.onmousedown;

    ValueExpression _ve = getValueExpression("onmousedown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousedown(String onmousedown)
  {
    this.onmousedown = onmousedown;
  }

  public String getOnmousemove()
  {
    if (null != this.onmousemove)
      return this.onmousemove;

    ValueExpression _ve = getValueExpression("onmousemove");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousemove(String onmousemove)
  {
    this.onmousemove = onmousemove;
  }

  public String getOnmouseout()
  {
    if (null != this.onmouseout)
      return this.onmouseout;

    ValueExpression _ve = getValueExpression("onmouseout");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseout(String onmouseout)
  {
    this.onmouseout = onmouseout;
  }

  public String getOnmouseover()
  {
    if (null != this.onmouseover)
      return this.onmouseover;

    ValueExpression _ve = getValueExpression("onmouseover");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseover(String onmouseover)
  {
    this.onmouseover = onmouseover;
  }

  public String getOnmouseup()
  {
    if (null != this.onmouseup)
      return this.onmouseup;

    ValueExpression _ve = getValueExpression("onmouseup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseup(String onmouseup)
  {
    this.onmouseup = onmouseup;
  }

  public String getOnselect()
  {
    if (null != this.onselect)
      return this.onselect;

    ValueExpression _ve = getValueExpression("onselect");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnselect(String onselect)
  {
    this.onselect = onselect;
  }

  public boolean isReadonly()
  {
    if (this.readonly_set)
      return this.readonly;

    ValueExpression _ve = getValueExpression("readonly");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.readonly;
  }

  public void setReadonly(boolean readonly)
  {
    this.readonly = readonly;
    this.readonly_set = true;
  }

  public int getSize()
  {
    if (this.size_set)
      return this.size;

    ValueExpression _ve = getValueExpression("size");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return -2147483648;

      return ((Integer)_result).intValue();
    }

    return this.size;
  }

  public void setSize(int size)
  {
    this.size = size;
    this.size_set = true;
  }

  public String getStyle()
  {
    if (null != this.style)
      return this.style;

    ValueExpression _ve = getValueExpression("style");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyle(String style)
  {
    this.style = style;
  }

  public String getStyleClass()
  {
    if (null != this.styleClass)
      return this.styleClass;

    ValueExpression _ve = getValueExpression("styleClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyleClass(String styleClass)
  {
    this.styleClass = styleClass;
  }

  public String getTabindex()
  {
    if (null != this.tabindex)
      return this.tabindex;

    ValueExpression _ve = getValueExpression("tabindex");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTabindex(String tabindex)
  {
    this.tabindex = tabindex;
  }

  public String getTitle()
  {
    if (null != this.title)
      return this.title;

    ValueExpression _ve = getValueExpression("title");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[31];

    this._values[0] = super.saveState(_context);
    this._values[1] = this.accesskey;
    this._values[2] = this.dir;
    this._values[3] = ((this.size_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[4] = ((this.disabled_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[5] = this.disabledClass;
    this._values[6] = this.enabledClass;
    this._values[7] = this.label;
    this._values[8] = this.lang;
    this._values[9] = this.onblur;
    this._values[10] = this.onchange;
    this._values[11] = this.onclick;
    this._values[12] = this.ondblclick;
    this._values[13] = this.onfocus;
    this._values[14] = this.onkeydown;
    this._values[15] = this.onkeypress;
    this._values[16] = this.onkeyup;
    this._values[17] = this.onmousedown;
    this._values[18] = this.onmousemove;
    this._values[19] = this.onmouseout;
    this._values[20] = this.onmouseover;
    this._values[21] = this.onmouseup;
    this._values[22] = this.onselect;
    this._values[23] = ((this.readonly) ? Boolean.TRUE : Boolean.FALSE);
    this._values[24] = ((this.readonly_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[25] = new Integer(this.size);
    this._values[26] = ((this.size_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[27] = this.style;
    this._values[28] = this.styleClass;
    this._values[29] = this.tabindex;
    this._values[30] = this.title;
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
    this.accesskey = ((String)this._values[1]);
    this.dir = ((String)this._values[2]);
    this.size_set = ((Boolean)this._values[3]).booleanValue();
    this.disabled_set = ((Boolean)this._values[4]).booleanValue();
    this.disabledClass = ((String)this._values[5]);
    this.enabledClass = ((String)this._values[6]);
    this.label = ((String)this._values[7]);
    this.lang = ((String)this._values[8]);
    this.onblur = ((String)this._values[9]);
    this.onchange = ((String)this._values[10]);
    this.onclick = ((String)this._values[11]);
    this.ondblclick = ((String)this._values[12]);
    this.onfocus = ((String)this._values[13]);
    this.onkeydown = ((String)this._values[14]);
    this.onkeypress = ((String)this._values[15]);
    this.onkeyup = ((String)this._values[16]);
    this.onmousedown = ((String)this._values[17]);
    this.onmousemove = ((String)this._values[18]);
    this.onmouseout = ((String)this._values[19]);
    this.onmouseover = ((String)this._values[20]);
    this.onmouseup = ((String)this._values[21]);
    this.onselect = ((String)this._values[22]);
    this.readonly = ((Boolean)this._values[23]).booleanValue();
    this.readonly_set = ((Boolean)this._values[24]).booleanValue();
    this.size = ((Integer)this._values[25]).intValue();
    this.size_set = ((Boolean)this._values[26]).booleanValue();
    this.style = ((String)this._values[27]);
    this.styleClass = ((String)this._values[28]);
    this.tabindex = ((String)this._values[29]);
    this.title = ((String)this._values[30]);
  }
}