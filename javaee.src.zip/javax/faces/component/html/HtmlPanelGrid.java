package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIPanel;
import javax.faces.context.FacesContext;

public class HtmlPanelGrid extends UIPanel
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlPanelGrid";
  private String bgcolor;
  private int border = -2147483648;
  private boolean border_set = false;
  private String captionClass;
  private String captionStyle;
  private String cellpadding;
  private String cellspacing;
  private String columnClasses;
  private int columns = -2147483648;
  private boolean columns_set = false;
  private String dir;
  private String footerClass;
  private String frame;
  private String headerClass;
  private String lang;
  private String onclick;
  private String ondblclick;
  private String onkeydown;
  private String onkeypress;
  private String onkeyup;
  private String onmousedown;
  private String onmousemove;
  private String onmouseout;
  private String onmouseover;
  private String onmouseup;
  private String rowClasses;
  private String rules;
  private String style;
  private String styleClass;
  private String summary;
  private String title;
  private String width;
  private Object[] _values;

  public HtmlPanelGrid()
  {
    setRendererType("javax.faces.Grid");
  }

  public String getBgcolor()
  {
    if (null != this.bgcolor)
      return this.bgcolor;

    ValueExpression _ve = getValueExpression("bgcolor");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setBgcolor(String bgcolor)
  {
    this.bgcolor = bgcolor;
  }

  public int getBorder()
  {
    if (this.border_set)
      return this.columns_set;

    ValueExpression _ve = getValueExpression("border");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return -2147483648;

      return ((Integer)_result).intValue();
    }

    return this.columns_set;
  }

  public void setBorder(int border)
  {
    this.columns_set = border;
    this.border_set = true;
  }

  public String getCaptionClass()
  {
    if (null != this.captionClass)
      return this.captionClass;

    ValueExpression _ve = getValueExpression("captionClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setCaptionClass(String captionClass)
  {
    this.captionClass = captionClass;
  }

  public String getCaptionStyle()
  {
    if (null != this.captionStyle)
      return this.captionStyle;

    ValueExpression _ve = getValueExpression("captionStyle");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setCaptionStyle(String captionStyle)
  {
    this.captionStyle = captionStyle;
  }

  public String getCellpadding()
  {
    if (null != this.cellpadding)
      return this.cellpadding;

    ValueExpression _ve = getValueExpression("cellpadding");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setCellpadding(String cellpadding)
  {
    this.cellpadding = cellpadding;
  }

  public String getCellspacing()
  {
    if (null != this.cellspacing)
      return this.cellspacing;

    ValueExpression _ve = getValueExpression("cellspacing");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setCellspacing(String cellspacing)
  {
    this.cellspacing = cellspacing;
  }

  public String getColumnClasses()
  {
    if (null != this.columnClasses)
      return this.columnClasses;

    ValueExpression _ve = getValueExpression("columnClasses");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setColumnClasses(String columnClasses)
  {
    this.columnClasses = columnClasses;
  }

  public int getColumns()
  {
    if (this.columns_set)
      return this.columns;

    ValueExpression _ve = getValueExpression("columns");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return -2147483648;

      return ((Integer)_result).intValue();
    }

    return this.columns;
  }

  public void setColumns(int columns)
  {
    this.columns = columns;
    this.columns_set = true;
  }

  public String getDir()
  {
    if (null != this.dir)
      return this.dir;

    ValueExpression _ve = getValueExpression("dir");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setDir(String dir)
  {
    this.dir = dir;
  }

  public String getFooterClass()
  {
    if (null != this.footerClass)
      return this.footerClass;

    ValueExpression _ve = getValueExpression("footerClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setFooterClass(String footerClass)
  {
    this.footerClass = footerClass;
  }

  public String getFrame()
  {
    if (null != this.frame)
      return this.frame;

    ValueExpression _ve = getValueExpression("frame");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setFrame(String frame)
  {
    this.frame = frame;
  }

  public String getHeaderClass()
  {
    if (null != this.headerClass)
      return this.headerClass;

    ValueExpression _ve = getValueExpression("headerClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setHeaderClass(String headerClass)
  {
    this.headerClass = headerClass;
  }

  public String getLang()
  {
    if (null != this.lang)
      return this.lang;

    ValueExpression _ve = getValueExpression("lang");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLang(String lang)
  {
    this.lang = lang;
  }

  public String getOnclick()
  {
    if (null != this.onclick)
      return this.onclick;

    ValueExpression _ve = getValueExpression("onclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnclick(String onclick)
  {
    this.onclick = onclick;
  }

  public String getOndblclick()
  {
    if (null != this.ondblclick)
      return this.ondblclick;

    ValueExpression _ve = getValueExpression("ondblclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOndblclick(String ondblclick)
  {
    this.ondblclick = ondblclick;
  }

  public String getOnkeydown()
  {
    if (null != this.onkeydown)
      return this.onkeydown;

    ValueExpression _ve = getValueExpression("onkeydown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeydown(String onkeydown)
  {
    this.onkeydown = onkeydown;
  }

  public String getOnkeypress()
  {
    if (null != this.onkeypress)
      return this.onkeypress;

    ValueExpression _ve = getValueExpression("onkeypress");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeypress(String onkeypress)
  {
    this.onkeypress = onkeypress;
  }

  public String getOnkeyup()
  {
    if (null != this.onkeyup)
      return this.onkeyup;

    ValueExpression _ve = getValueExpression("onkeyup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeyup(String onkeyup)
  {
    this.onkeyup = onkeyup;
  }

  public String getOnmousedown()
  {
    if (null != this.onmousedown)
      return this.onmousedown;

    ValueExpression _ve = getValueExpression("onmousedown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousedown(String onmousedown)
  {
    this.onmousedown = onmousedown;
  }

  public String getOnmousemove()
  {
    if (null != this.onmousemove)
      return this.onmousemove;

    ValueExpression _ve = getValueExpression("onmousemove");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousemove(String onmousemove)
  {
    this.onmousemove = onmousemove;
  }

  public String getOnmouseout()
  {
    if (null != this.onmouseout)
      return this.onmouseout;

    ValueExpression _ve = getValueExpression("onmouseout");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseout(String onmouseout)
  {
    this.onmouseout = onmouseout;
  }

  public String getOnmouseover()
  {
    if (null != this.onmouseover)
      return this.onmouseover;

    ValueExpression _ve = getValueExpression("onmouseover");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseover(String onmouseover)
  {
    this.onmouseover = onmouseover;
  }

  public String getOnmouseup()
  {
    if (null != this.onmouseup)
      return this.onmouseup;

    ValueExpression _ve = getValueExpression("onmouseup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseup(String onmouseup)
  {
    this.onmouseup = onmouseup;
  }

  public String getRowClasses()
  {
    if (null != this.rowClasses)
      return this.rowClasses;

    ValueExpression _ve = getValueExpression("rowClasses");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setRowClasses(String rowClasses)
  {
    this.rowClasses = rowClasses;
  }

  public String getRules()
  {
    if (null != this.rules)
      return this.rules;

    ValueExpression _ve = getValueExpression("rules");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setRules(String rules)
  {
    this.rules = rules;
  }

  public String getStyle()
  {
    if (null != this.style)
      return this.style;

    ValueExpression _ve = getValueExpression("style");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyle(String style)
  {
    this.style = style;
  }

  public String getStyleClass()
  {
    if (null != this.styleClass)
      return this.styleClass;

    ValueExpression _ve = getValueExpression("styleClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyleClass(String styleClass)
  {
    this.styleClass = styleClass;
  }

  public String getSummary()
  {
    if (null != this.summary)
      return this.summary;

    ValueExpression _ve = getValueExpression("summary");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setSummary(String summary)
  {
    this.summary = summary;
  }

  public String getTitle()
  {
    if (null != this.title)
      return this.title;

    ValueExpression _ve = getValueExpression("title");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  public String getWidth()
  {
    if (null != this.width)
      return this.width;

    ValueExpression _ve = getValueExpression("width");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setWidth(String width)
  {
    this.width = width;
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[33];

    this._values[0] = super.saveState(_context);
    this._values[1] = this.bgcolor;
    this._values[2] = new Integer(this.columns_set);
    this._values[3] = ((this.border_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[4] = this.captionClass;
    this._values[5] = this.captionStyle;
    this._values[6] = this.cellpadding;
    this._values[7] = this.cellspacing;
    this._values[8] = this.columnClasses;
    this._values[9] = new Integer(this.columns);
    this._values[10] = ((this.columns_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[11] = this.dir;
    this._values[12] = this.footerClass;
    this._values[13] = this.frame;
    this._values[14] = this.headerClass;
    this._values[15] = this.lang;
    this._values[16] = this.onclick;
    this._values[17] = this.ondblclick;
    this._values[18] = this.onkeydown;
    this._values[19] = this.onkeypress;
    this._values[20] = this.onkeyup;
    this._values[21] = this.onmousedown;
    this._values[22] = this.onmousemove;
    this._values[23] = this.onmouseout;
    this._values[24] = this.onmouseover;
    this._values[25] = this.onmouseup;
    this._values[26] = this.rowClasses;
    this._values[27] = this.rules;
    this._values[28] = this.style;
    this._values[29] = this.styleClass;
    this._values[30] = this.summary;
    this._values[31] = this.title;
    this._values[32] = this.width;
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
    this.bgcolor = ((String)this._values[1]);
    this.columns_set = ((Integer)this._values[2]).intValue();
    this.border_set = ((Boolean)this._values[3]).booleanValue();
    this.captionClass = ((String)this._values[4]);
    this.captionStyle = ((String)this._values[5]);
    this.cellpadding = ((String)this._values[6]);
    this.cellspacing = ((String)this._values[7]);
    this.columnClasses = ((String)this._values[8]);
    this.columns = ((Integer)this._values[9]).intValue();
    this.columns_set = ((Boolean)this._values[10]).booleanValue();
    this.dir = ((String)this._values[11]);
    this.footerClass = ((String)this._values[12]);
    this.frame = ((String)this._values[13]);
    this.headerClass = ((String)this._values[14]);
    this.lang = ((String)this._values[15]);
    this.onclick = ((String)this._values[16]);
    this.ondblclick = ((String)this._values[17]);
    this.onkeydown = ((String)this._values[18]);
    this.onkeypress = ((String)this._values[19]);
    this.onkeyup = ((String)this._values[20]);
    this.onmousedown = ((String)this._values[21]);
    this.onmousemove = ((String)this._values[22]);
    this.onmouseout = ((String)this._values[23]);
    this.onmouseover = ((String)this._values[24]);
    this.onmouseup = ((String)this._values[25]);
    this.rowClasses = ((String)this._values[26]);
    this.rules = ((String)this._values[27]);
    this.style = ((String)this._values[28]);
    this.styleClass = ((String)this._values[29]);
    this.summary = ((String)this._values[30]);
    this.title = ((String)this._values[31]);
    this.width = ((String)this._values[32]);
  }
}