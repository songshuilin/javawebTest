package javax.faces.component.html;

import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;

public class HtmlInputHidden extends UIInput
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlInputHidden";
  private Object[] _values;

  public HtmlInputHidden()
  {
    setRendererType("javax.faces.Hidden");
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[1];

    this._values[0] = super.saveState(_context);
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
  }
}