package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;

public class HtmlOutputText extends UIOutput
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlOutputText";
  private String dir;
  private boolean escape = true;
  private boolean escape_set = false;
  private String lang;
  private String style;
  private String styleClass;
  private String title;
  private Object[] _values;

  public HtmlOutputText()
  {
    setRendererType("javax.faces.Text");
  }

  public String getDir()
  {
    if (null != this.dir)
      return this.dir;

    ValueExpression _ve = getValueExpression("dir");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setDir(String dir)
  {
    this.dir = dir;
  }

  public boolean isEscape()
  {
    if (this.escape_set)
      return this.escape_set;

    ValueExpression _ve = getValueExpression("escape");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.escape_set;
  }

  public void setEscape(boolean escape)
  {
    this.escape_set = escape;
    this.escape_set = true;
  }

  public String getLang()
  {
    if (null != this.lang)
      return this.lang;

    ValueExpression _ve = getValueExpression("lang");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLang(String lang)
  {
    this.lang = lang;
  }

  public String getStyle()
  {
    if (null != this.style)
      return this.style;

    ValueExpression _ve = getValueExpression("style");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyle(String style)
  {
    this.style = style;
  }

  public String getStyleClass()
  {
    if (null != this.styleClass)
      return this.styleClass;

    ValueExpression _ve = getValueExpression("styleClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyleClass(String styleClass)
  {
    this.styleClass = styleClass;
  }

  public String getTitle()
  {
    if (null != this.title)
      return this.title;

    ValueExpression _ve = getValueExpression("title");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[8];

    this._values[0] = super.saveState(_context);
    this._values[1] = this.dir;
    this._values[2] = ((this.escape_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[3] = ((this.escape_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[4] = this.lang;
    this._values[5] = this.style;
    this._values[6] = this.styleClass;
    this._values[7] = this.title;
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
    this.dir = ((String)this._values[1]);
    this.escape_set = ((Boolean)this._values[2]).booleanValue();
    this.escape_set = ((Boolean)this._values[3]).booleanValue();
    this.lang = ((String)this._values[4]);
    this.style = ((String)this._values[5]);
    this.styleClass = ((String)this._values[6]);
    this.title = ((String)this._values[7]);
  }
}