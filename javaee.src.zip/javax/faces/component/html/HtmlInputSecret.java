package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;

public class HtmlInputSecret extends UIInput
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlInputSecret";
  private String accesskey;
  private String alt;
  private String autocomplete;
  private String dir;
  private boolean disabled = false;
  private boolean disabled_set = false;
  private String label;
  private String lang;
  private int maxlength = -2147483648;
  private boolean maxlength_set = false;
  private String onblur;
  private String onchange;
  private String onclick;
  private String ondblclick;
  private String onfocus;
  private String onkeydown;
  private String onkeypress;
  private String onkeyup;
  private String onmousedown;
  private String onmousemove;
  private String onmouseout;
  private String onmouseover;
  private String onmouseup;
  private String onselect;
  private boolean readonly = false;
  private boolean readonly_set = false;
  private boolean redisplay = false;
  private boolean redisplay_set = false;
  private int size = -2147483648;
  private boolean size_set = false;
  private String style;
  private String styleClass;
  private String tabindex;
  private String title;
  private Object[] _values;

  public HtmlInputSecret()
  {
    setRendererType("javax.faces.Secret");
  }

  public String getAccesskey()
  {
    if (null != this.accesskey)
      return this.accesskey;

    ValueExpression _ve = getValueExpression("accesskey");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setAccesskey(String accesskey)
  {
    this.accesskey = accesskey;
  }

  public String getAlt()
  {
    if (null != this.alt)
      return this.alt;

    ValueExpression _ve = getValueExpression("alt");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setAlt(String alt)
  {
    this.alt = alt;
  }

  public String getAutocomplete()
  {
    if (null != this.autocomplete)
      return this.autocomplete;

    ValueExpression _ve = getValueExpression("autocomplete");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setAutocomplete(String autocomplete)
  {
    this.autocomplete = autocomplete;
  }

  public String getDir()
  {
    if (null != this.dir)
      return this.dir;

    ValueExpression _ve = getValueExpression("dir");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setDir(String dir)
  {
    this.dir = dir;
  }

  public boolean isDisabled()
  {
    if (this.disabled_set)
      return this.size_set;

    ValueExpression _ve = getValueExpression("disabled");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.size_set;
  }

  public void setDisabled(boolean disabled)
  {
    this.size_set = disabled;
    this.disabled_set = true;
  }

  public String getLabel()
  {
    if (null != this.label)
      return this.label;

    ValueExpression _ve = getValueExpression("label");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLabel(String label)
  {
    this.label = label;
  }

  public String getLang()
  {
    if (null != this.lang)
      return this.lang;

    ValueExpression _ve = getValueExpression("lang");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setLang(String lang)
  {
    this.lang = lang;
  }

  public int getMaxlength()
  {
    if (this.maxlength_set)
      return this.maxlength;

    ValueExpression _ve = getValueExpression("maxlength");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return -2147483648;

      return ((Integer)_result).intValue();
    }

    return this.maxlength;
  }

  public void setMaxlength(int maxlength)
  {
    this.maxlength = maxlength;
    this.maxlength_set = true;
  }

  public String getOnblur()
  {
    if (null != this.onblur)
      return this.onblur;

    ValueExpression _ve = getValueExpression("onblur");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnblur(String onblur)
  {
    this.onblur = onblur;
  }

  public String getOnchange()
  {
    if (null != this.onchange)
      return this.onchange;

    ValueExpression _ve = getValueExpression("onchange");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnchange(String onchange)
  {
    this.onchange = onchange;
  }

  public String getOnclick()
  {
    if (null != this.onclick)
      return this.onclick;

    ValueExpression _ve = getValueExpression("onclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnclick(String onclick)
  {
    this.onclick = onclick;
  }

  public String getOndblclick()
  {
    if (null != this.ondblclick)
      return this.ondblclick;

    ValueExpression _ve = getValueExpression("ondblclick");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOndblclick(String ondblclick)
  {
    this.ondblclick = ondblclick;
  }

  public String getOnfocus()
  {
    if (null != this.onfocus)
      return this.onfocus;

    ValueExpression _ve = getValueExpression("onfocus");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnfocus(String onfocus)
  {
    this.onfocus = onfocus;
  }

  public String getOnkeydown()
  {
    if (null != this.onkeydown)
      return this.onkeydown;

    ValueExpression _ve = getValueExpression("onkeydown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeydown(String onkeydown)
  {
    this.onkeydown = onkeydown;
  }

  public String getOnkeypress()
  {
    if (null != this.onkeypress)
      return this.onkeypress;

    ValueExpression _ve = getValueExpression("onkeypress");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeypress(String onkeypress)
  {
    this.onkeypress = onkeypress;
  }

  public String getOnkeyup()
  {
    if (null != this.onkeyup)
      return this.onkeyup;

    ValueExpression _ve = getValueExpression("onkeyup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnkeyup(String onkeyup)
  {
    this.onkeyup = onkeyup;
  }

  public String getOnmousedown()
  {
    if (null != this.onmousedown)
      return this.onmousedown;

    ValueExpression _ve = getValueExpression("onmousedown");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousedown(String onmousedown)
  {
    this.onmousedown = onmousedown;
  }

  public String getOnmousemove()
  {
    if (null != this.onmousemove)
      return this.onmousemove;

    ValueExpression _ve = getValueExpression("onmousemove");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmousemove(String onmousemove)
  {
    this.onmousemove = onmousemove;
  }

  public String getOnmouseout()
  {
    if (null != this.onmouseout)
      return this.onmouseout;

    ValueExpression _ve = getValueExpression("onmouseout");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseout(String onmouseout)
  {
    this.onmouseout = onmouseout;
  }

  public String getOnmouseover()
  {
    if (null != this.onmouseover)
      return this.onmouseover;

    ValueExpression _ve = getValueExpression("onmouseover");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseover(String onmouseover)
  {
    this.onmouseover = onmouseover;
  }

  public String getOnmouseup()
  {
    if (null != this.onmouseup)
      return this.onmouseup;

    ValueExpression _ve = getValueExpression("onmouseup");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnmouseup(String onmouseup)
  {
    this.onmouseup = onmouseup;
  }

  public String getOnselect()
  {
    if (null != this.onselect)
      return this.onselect;

    ValueExpression _ve = getValueExpression("onselect");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setOnselect(String onselect)
  {
    this.onselect = onselect;
  }

  public boolean isReadonly()
  {
    if (this.readonly_set)
      return this.readonly;

    ValueExpression _ve = getValueExpression("readonly");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.readonly;
  }

  public void setReadonly(boolean readonly)
  {
    this.readonly = readonly;
    this.readonly_set = true;
  }

  public boolean isRedisplay()
  {
    if (this.redisplay_set)
      return this.redisplay;

    ValueExpression _ve = getValueExpression("redisplay");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return false;

      return ((Boolean)_result).booleanValue();
    }

    return this.redisplay;
  }

  public void setRedisplay(boolean redisplay)
  {
    this.redisplay = redisplay;
    this.redisplay_set = true;
  }

  public int getSize()
  {
    if (this.size_set)
      return this.size;

    ValueExpression _ve = getValueExpression("size");
    if (_ve != null) {
      Object _result = _ve.getValue(getFacesContext().getELContext());
      if (_result == null)
        return -2147483648;

      return ((Integer)_result).intValue();
    }

    return this.size;
  }

  public void setSize(int size)
  {
    this.size = size;
    this.size_set = true;
  }

  public String getStyle()
  {
    if (null != this.style)
      return this.style;

    ValueExpression _ve = getValueExpression("style");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyle(String style)
  {
    this.style = style;
  }

  public String getStyleClass()
  {
    if (null != this.styleClass)
      return this.styleClass;

    ValueExpression _ve = getValueExpression("styleClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setStyleClass(String styleClass)
  {
    this.styleClass = styleClass;
  }

  public String getTabindex()
  {
    if (null != this.tabindex)
      return this.tabindex;

    ValueExpression _ve = getValueExpression("tabindex");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTabindex(String tabindex)
  {
    this.tabindex = tabindex;
  }

  public String getTitle()
  {
    if (null != this.title)
      return this.title;

    ValueExpression _ve = getValueExpression("title");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[35];

    this._values[0] = super.saveState(_context);
    this._values[1] = this.accesskey;
    this._values[2] = this.alt;
    this._values[3] = this.autocomplete;
    this._values[4] = this.dir;
    this._values[5] = ((this.size_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[6] = ((this.disabled_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[7] = this.label;
    this._values[8] = this.lang;
    this._values[9] = new Integer(this.maxlength);
    this._values[10] = ((this.maxlength_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[11] = this.onblur;
    this._values[12] = this.onchange;
    this._values[13] = this.onclick;
    this._values[14] = this.ondblclick;
    this._values[15] = this.onfocus;
    this._values[16] = this.onkeydown;
    this._values[17] = this.onkeypress;
    this._values[18] = this.onkeyup;
    this._values[19] = this.onmousedown;
    this._values[20] = this.onmousemove;
    this._values[21] = this.onmouseout;
    this._values[22] = this.onmouseover;
    this._values[23] = this.onmouseup;
    this._values[24] = this.onselect;
    this._values[25] = ((this.readonly) ? Boolean.TRUE : Boolean.FALSE);
    this._values[26] = ((this.readonly_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[27] = ((this.redisplay) ? Boolean.TRUE : Boolean.FALSE);
    this._values[28] = ((this.redisplay_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[29] = new Integer(this.size);
    this._values[30] = ((this.size_set) ? Boolean.TRUE : Boolean.FALSE);
    this._values[31] = this.style;
    this._values[32] = this.styleClass;
    this._values[33] = this.tabindex;
    this._values[34] = this.title;
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
    this.accesskey = ((String)this._values[1]);
    this.alt = ((String)this._values[2]);
    this.autocomplete = ((String)this._values[3]);
    this.dir = ((String)this._values[4]);
    this.size_set = ((Boolean)this._values[5]).booleanValue();
    this.disabled_set = ((Boolean)this._values[6]).booleanValue();
    this.label = ((String)this._values[7]);
    this.lang = ((String)this._values[8]);
    this.maxlength = ((Integer)this._values[9]).intValue();
    this.maxlength_set = ((Boolean)this._values[10]).booleanValue();
    this.onblur = ((String)this._values[11]);
    this.onchange = ((String)this._values[12]);
    this.onclick = ((String)this._values[13]);
    this.ondblclick = ((String)this._values[14]);
    this.onfocus = ((String)this._values[15]);
    this.onkeydown = ((String)this._values[16]);
    this.onkeypress = ((String)this._values[17]);
    this.onkeyup = ((String)this._values[18]);
    this.onmousedown = ((String)this._values[19]);
    this.onmousemove = ((String)this._values[20]);
    this.onmouseout = ((String)this._values[21]);
    this.onmouseover = ((String)this._values[22]);
    this.onmouseup = ((String)this._values[23]);
    this.onselect = ((String)this._values[24]);
    this.readonly = ((Boolean)this._values[25]).booleanValue();
    this.readonly_set = ((Boolean)this._values[26]).booleanValue();
    this.redisplay = ((Boolean)this._values[27]).booleanValue();
    this.redisplay_set = ((Boolean)this._values[28]).booleanValue();
    this.size = ((Integer)this._values[29]).intValue();
    this.size_set = ((Boolean)this._values[30]).booleanValue();
    this.style = ((String)this._values[31]);
    this.styleClass = ((String)this._values[32]);
    this.tabindex = ((String)this._values[33]);
    this.title = ((String)this._values[34]);
  }
}