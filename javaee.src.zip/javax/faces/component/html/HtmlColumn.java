package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIColumn;
import javax.faces.context.FacesContext;

public class HtmlColumn extends UIColumn
{
  public static final String COMPONENT_TYPE = "javax.faces.HtmlColumn";
  private String footerClass;
  private String headerClass;
  private Object[] _values;

  public String getFooterClass()
  {
    if (null != this.footerClass)
      return this.footerClass;

    ValueExpression _ve = getValueExpression("footerClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setFooterClass(String footerClass)
  {
    this.footerClass = footerClass;
  }

  public String getHeaderClass()
  {
    if (null != this.headerClass)
      return this.headerClass;

    ValueExpression _ve = getValueExpression("headerClass");
    if (_ve != null)
      return ((String)_ve.getValue(getFacesContext().getELContext()));

    return null;
  }

  public void setHeaderClass(String headerClass)
  {
    this.headerClass = headerClass;
  }

  public Object saveState(FacesContext _context)
  {
    if (this._values == null)
      this._values = new Object[3];

    this._values[0] = super.saveState(_context);
    this._values[1] = this.footerClass;
    this._values[2] = this.headerClass;
    return this._values;
  }

  public void restoreState(FacesContext _context, Object _state)
  {
    this._values = ((Object[])(Object[])_state);
    super.restoreState(_context, this._values[0]);
    this.footerClass = ((String)this._values[1]);
    this.headerClass = ((String)this._values[2]);
  }
}