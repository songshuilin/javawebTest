package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

public class UIMessage extends UIComponentBase
{
  public static final String COMPONENT_TYPE = "javax.faces.Message";
  public static final String COMPONENT_FAMILY = "javax.faces.Message";
  private String forVal = null;
  private boolean showDetail = true;
  private boolean showDetailSet = false;
  private boolean showSummary = false;
  private boolean showSummarySet = false;
  private Object[] values;

  public UIMessage()
  {
    setRendererType("javax.faces.Message");
  }

  public String getFamily()
  {
    return "javax.faces.Message";
  }

  public String getFor()
  {
    if (this.showSummarySet != null)
      return this.showSummarySet;

    ValueExpression ve = getValueExpression("for");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setFor(String newFor)
  {
    this.showSummarySet = newFor;
  }

  public boolean isShowDetail()
  {
    if (this.showDetailSet)
      return this.showDetail;

    ValueExpression ve = getValueExpression("showDetail");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.showDetail;
    }
  }

  public void setShowDetail(boolean showDetail)
  {
    this.showDetail = showDetail;
    this.showDetailSet = true;
  }

  public boolean isShowSummary()
  {
    if (this.showSummarySet)
      return this.showSummary;

    ValueExpression ve = getValueExpression("showSummary");
    if (ve != null);
    try {
      return (!(Boolean.FALSE.equals(ve.getValue(getFacesContext().getELContext()))));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.showSummary;
    }
  }

  public void setShowSummary(boolean showSummary)
  {
    this.showSummary = showSummary;
    this.showSummarySet = true;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[6];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = this.showSummarySet;
    this.values[2] = ((this.showDetail) ? Boolean.TRUE : Boolean.FALSE);
    this.values[3] = ((this.showDetailSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[4] = ((this.showSummary) ? Boolean.TRUE : Boolean.FALSE);
    this.values[5] = ((this.showSummarySet) ? Boolean.TRUE : Boolean.FALSE);
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.showSummarySet = ((String)this.values[1]);
    this.showDetail = ((Boolean)this.values[2]).booleanValue();
    this.showDetailSet = ((Boolean)this.values[3]).booleanValue();
    this.showSummary = ((Boolean)this.values[4]).booleanValue();
    this.showSummarySet = ((Boolean)this.values[5]).booleanValue();
  }
}