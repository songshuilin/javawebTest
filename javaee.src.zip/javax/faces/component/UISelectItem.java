package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

public class UISelectItem extends UIComponentBase
{
  public static final String COMPONENT_TYPE = "javax.faces.SelectItem";
  public static final String COMPONENT_FAMILY = "javax.faces.SelectItem";
  private String itemDescription = null;
  private boolean itemDisabled = false;
  private boolean itemDisabledSet = false;
  private boolean itemEscaped = true;
  private boolean itemEscapedSet = false;
  private String itemLabel = null;
  private Object itemValue = null;
  private Object value = null;
  private Object[] values;

  public UISelectItem()
  {
    setRendererType(null);
  }

  public String getFamily()
  {
    return "javax.faces.SelectItem";
  }

  public String getItemDescription()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("itemDescription");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setItemDescription(String itemDescription)
  {
    this.value = itemDescription;
  }

  public boolean isItemDisabled()
  {
    if (this.itemDisabledSet)
      return this.itemDisabled;

    ValueExpression ve = getValueExpression("itemDisabled");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.itemDisabled;
    }
  }

  public void setItemDisabled(boolean itemDisabled)
  {
    this.itemDisabled = itemDisabled;
    this.itemDisabledSet = true;
  }

  public boolean isItemEscaped()
  {
    if (this.itemEscapedSet)
      return this.itemEscaped;

    ValueExpression ve = getValueExpression("itemEscaped");
    if (ve != null);
    try {
      return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return this.itemEscaped;
    }
  }

  public void setItemEscaped(boolean itemEscaped)
  {
    this.itemEscaped = itemEscaped;
    this.itemEscapedSet = true;
  }

  public String getItemLabel()
  {
    if (this.itemLabel != null)
      return this.itemLabel;

    ValueExpression ve = getValueExpression("itemLabel");
    if (ve != null);
    try {
      return ((String)ve.getValue(getFacesContext().getELContext()));
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setItemLabel(String itemLabel)
  {
    this.itemLabel = itemLabel;
  }

  public Object getItemValue()
  {
    if (this.itemValue != null)
      return this.itemValue;

    ValueExpression ve = getValueExpression("itemValue");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setItemValue(Object itemValue)
  {
    this.itemValue = itemValue;
  }

  public Object getValue()
  {
    if (this.value != null)
      return this.value;

    ValueExpression ve = getValueExpression("value");
    if (ve != null);
    try {
      return ve.getValue(getFacesContext().getELContext());
    }
    catch (ELException e) {
      throw new FacesException(e);

      return null;
    }
  }

  public void setValue(Object value)
  {
    this.value = value;
  }

  public Object saveState(FacesContext context)
  {
    if (this.values == null) {
      this.values = new Object[9];
    }

    this.values[0] = super.saveState(context);
    this.values[1] = this.value;
    this.values[2] = ((this.itemDisabled) ? Boolean.TRUE : Boolean.FALSE);
    this.values[3] = ((this.itemDisabledSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[4] = ((this.itemEscaped) ? Boolean.TRUE : Boolean.FALSE);
    this.values[5] = ((this.itemEscapedSet) ? Boolean.TRUE : Boolean.FALSE);
    this.values[6] = this.itemLabel;
    this.values[7] = this.itemValue;
    this.values[8] = this.value;
    return this.values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    this.values = ((Object[])(Object[])state);
    super.restoreState(context, this.values[0]);
    this.value = ((String)this.values[1]);
    this.itemDisabled = ((Boolean)this.values[2]).booleanValue();
    this.itemDisabledSet = ((Boolean)this.values[3]).booleanValue();
    this.itemEscaped = ((Boolean)this.values[4]).booleanValue();
    this.itemEscapedSet = ((Boolean)this.values[5]).booleanValue();
    this.itemLabel = ((String)this.values[6]);
    this.itemValue = this.values[7];
    this.value = this.values[8];
  }
}