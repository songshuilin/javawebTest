package javax.faces.component;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.el.ELContext;
import javax.el.ELException;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.MethodInfo;
import javax.el.MethodNotFoundException;
import javax.el.PropertyNotFoundException;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.EvaluationException;
import javax.faces.el.MethodBinding;
import javax.faces.el.MethodNotFoundException;

class MethodBindingMethodExpressionAdapter extends MethodBinding
  implements StateHolder, Serializable
{
  private static final long serialVersionUID = -1468492135L;
  private MethodExpression methodExpression = null;
  private boolean tranzient;

  MethodBindingMethodExpressionAdapter(MethodExpression methodExpression)
  {
    this.methodExpression = methodExpression;
  }

  public Object invoke(FacesContext context, Object[] params) throws EvaluationException, MethodNotFoundException
  {
    if ((!($assertionsDisabled)) && (null == this.methodExpression)) throw new AssertionError();
    if (context == null) {
      throw new NullPointerException("FacesConext -> null");
    }

    Object result = null;
    try {
      result = this.methodExpression.invoke(context.getELContext(), params);
    }
    catch (MethodNotFoundException e)
    {
      throw new MethodNotFoundException(e);
    }
    catch (PropertyNotFoundException e) {
      throw new EvaluationException(e);
    }
    catch (ELException e)
    {
      Throwable cause = e.getCause();
      if (cause != null) while (true) {
          if (cause.getCause() == null) break label114;
          cause = cause.getCause();
        }

      cause = e;

      throw new EvaluationException(cause);
    } catch (NullPointerException e) {
      label114: throw new MethodNotFoundException(e);
    }
    return result;
  }

  public Class getType(FacesContext context) throws MethodNotFoundException {
    if ((!($assertionsDisabled)) && (null == this.methodExpression)) throw new AssertionError();
    if (context == null)
      throw new NullPointerException("FacesConext -> null");

    Class result = null;
    if (context == null)
      throw new NullPointerException();

    try
    {
      MethodInfo mi = this.methodExpression.getMethodInfo(context.getELContext());

      result = mi.getReturnType();
    }
    catch (PropertyNotFoundException e) {
      throw new MethodNotFoundException(e);
    }
    catch (MethodNotFoundException e) {
      throw new MethodNotFoundException(e);
    }
    catch (ELException e) {
      throw new MethodNotFoundException(e);
    }
    return result;
  }

  public String getExpressionString()
  {
    if ((!($assertionsDisabled)) && (null == this.methodExpression)) throw new AssertionError();
    return this.methodExpression.getExpressionString();
  }

  public boolean equals(Object other) {
    if (this == other)
      return true;

    if (other instanceof MethodBindingMethodExpressionAdapter)
      return this.methodExpression.equals(((MethodBindingMethodExpressionAdapter)other).getWrapped());
    if (other instanceof MethodBinding) {
      MethodBinding binding = (MethodBinding)other;

      String expr = binding.getExpressionString();
      int idx = expr.indexOf(46);
      String target = expr.substring(0, idx).substring(2);
      String t = expr.substring(idx + 1);
      String method = t.substring(0, t.length() - 1);

      FacesContext context = FacesContext.getCurrentInstance();
      ELContext elContext = context.getELContext();
      MethodInfo controlInfo = this.methodExpression.getMethodInfo(elContext);

      if (!(controlInfo.getName().equals(method))) {
        return false;
      }

      ExpressionFactory factory = context.getApplication().getExpressionFactory();
      ValueExpression ve = factory.createValueExpression(elContext, "#{" + target + '}', Object.class);

      if (ve == null) {
        return false;
      }

      Object result = ve.getValue(elContext);

      if (result == null) {
        return false;
      }

      Class type = binding.getType(context);
      Method[] methods = result.getClass().getMethods();
      Method[] arr$ = methods; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Method meth = arr$[i$];
        if ((meth.getName().equals(method)) && (type.equals(controlInfo.getReturnType())) && (Arrays.equals(meth.getParameterTypes(), controlInfo.getParamTypes())))
        {
          return true;
        }
      }
    }

    return false;
  }

  public int hashCode()
  {
    if ((!($assertionsDisabled)) && (null == this.methodExpression)) throw new AssertionError();

    return this.methodExpression.hashCode();
  }

  public boolean isTransient()
  {
    return this.tranzient;
  }

  public void setTransient(boolean tranzient) {
    this.tranzient = tranzient;
  }

  public Object saveState(FacesContext context) {
    Object result = null;
    if (!(this.tranzient)) {
      if (this.methodExpression instanceof Serializable) {
        Object[] stateStruct = new Object[2];

        stateStruct[0] = ((Serializable)this.methodExpression).saveState(context);

        stateStruct[1] = this.methodExpression.getClass().getName();

        result = stateStruct;
      }
      else
        result = this.methodExpression;

    }

    return result;
  }

  public void restoreState(FacesContext context, Object state)
  {
    if (null == state) {
      return;
    }

    if (!(state instanceof MethodExpression)) {
      Object[] stateStruct = (Object[])(Object[])state;
      Object savedState = stateStruct[0];
      String className = stateStruct[1].toString();
      MethodExpression result = null;

      Class toRestoreClass = null;
      if (null != className) {
        try {
          toRestoreClass = loadClass(className, this);
        }
        catch (ClassNotFoundException e) {
          throw new IllegalStateException(e.getMessage());
        }

        if (null != toRestoreClass)
          try {
            result = (MethodExpression)toRestoreClass.newInstance();
          }
          catch (InstantiationException e)
          {
            throw new IllegalStateException(e.getMessage());
          }
          catch (IllegalAccessException a) {
            throw new IllegalStateException(a.getMessage());
          }


        if ((null != result) && (null != savedState))
        {
          ((Serializable)result).restoreState(context, savedState);
        }
        this.methodExpression = result;
      }
    }
    else
      this.methodExpression = ((MethodExpression)state);
  }

  public MethodExpression getWrapped()
  {
    return this.methodExpression;
  }

  private static Class loadClass(String name, Object fallbackClass)
    throws ClassNotFoundException
  {
    ClassLoader loader = Thread.currentThread().getContextClassLoader();

    if (loader == null)
      loader = fallbackClass.getClass().getClassLoader();

    return Class.forName(name, true, loader);
  }
}