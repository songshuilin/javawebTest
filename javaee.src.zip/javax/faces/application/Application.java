package javax.faces.application;

import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import javax.el.ELContextListener;
import javax.el.ELException;
import javax.el.ELResolver;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.el.MethodBinding;
import javax.faces.el.PropertyResolver;
import javax.faces.el.ReferenceSyntaxException;
import javax.faces.el.ValueBinding;
import javax.faces.el.VariableResolver;
import javax.faces.event.ActionListener;
import javax.faces.validator.Validator;

public abstract class Application
{
  public abstract ActionListener getActionListener();

  public abstract void setActionListener(ActionListener paramActionListener);

  public abstract Locale getDefaultLocale();

  public abstract void setDefaultLocale(Locale paramLocale);

  public abstract String getDefaultRenderKitId();

  public abstract void setDefaultRenderKitId(String paramString);

  public abstract String getMessageBundle();

  public abstract void setMessageBundle(String paramString);

  public abstract NavigationHandler getNavigationHandler();

  public abstract void setNavigationHandler(NavigationHandler paramNavigationHandler);

  /**
   * @deprecated
   */
  public abstract PropertyResolver getPropertyResolver();

  /**
   * @deprecated
   */
  public abstract void setPropertyResolver(PropertyResolver paramPropertyResolver);

  public ResourceBundle getResourceBundle(FacesContext ctx, String name)
  {
    Application impl = null;
    if (null != (impl = (Application)ctx.getExternalContext().getApplicationMap().get("com.sun.faces.ApplicationImpl")))
    {
      return impl.getResourceBundle(ctx, name);
    }

    throw new UnsupportedOperationException();
  }

  /**
   * @deprecated
   */
  public abstract VariableResolver getVariableResolver();

  /**
   * @deprecated
   */
  public abstract void setVariableResolver(VariableResolver paramVariableResolver);

  public void addELResolver(ELResolver resolver)
  {
    throw new UnsupportedOperationException();
  }

  public ELResolver getELResolver()
  {
    throw new UnsupportedOperationException();
  }

  public abstract ViewHandler getViewHandler();

  public abstract void setViewHandler(ViewHandler paramViewHandler);

  public abstract StateManager getStateManager();

  public abstract void setStateManager(StateManager paramStateManager);

  public abstract void addComponent(String paramString1, String paramString2);

  public abstract UIComponent createComponent(String paramString)
    throws FacesException;

  /**
   * @deprecated
   */
  public abstract UIComponent createComponent(ValueBinding paramValueBinding, FacesContext paramFacesContext, String paramString)
    throws FacesException;

  public UIComponent createComponent(ValueExpression componentExpression, FacesContext context, String componentType)
    throws FacesException
  {
    if ((null == componentExpression) || (null == context) || (null == componentType))
    {
      String message = "null parameters";
      message = message + " componentExpression " + componentExpression + " context " + context + " componentType " + componentType;

      throw new NullPointerException(message);
    }

    Object result = null;
    boolean createOne = false;
    try
    {
      if (null != (result = componentExpression.getValue(context.getELContext())))
      {
        createOne = !(result instanceof UIComponent);
      }

      if ((null == result) || (createOne)) {
        result = createComponent(componentType);
        componentExpression.setValue(context.getELContext(), result);
      }
    } catch (ELException elex) {
      throw new FacesException(elex);
    }

    return ((UIComponent)result);
  }

  public abstract Iterator<String> getComponentTypes();

  public abstract void addConverter(String paramString1, String paramString2);

  public abstract void addConverter(Class paramClass, String paramString);

  public abstract Converter createConverter(String paramString);

  public abstract Converter createConverter(Class paramClass);

  public abstract Iterator<String> getConverterIds();

  public abstract Iterator<Class> getConverterTypes();

  public ExpressionFactory getExpressionFactory()
  {
    throw new UnsupportedOperationException();
  }

  public Object evaluateExpressionGet(FacesContext context, String expression, Class expectedType)
    throws ELException
  {
    throw new UnsupportedOperationException();
  }

  /**
   * @deprecated
   */
  public abstract MethodBinding createMethodBinding(String paramString, Class[] paramArrayOfClass)
    throws ReferenceSyntaxException;

  public abstract Iterator<Locale> getSupportedLocales();

  public abstract void setSupportedLocales(Collection<Locale> paramCollection);

  public void addELContextListener(ELContextListener listener)
  {
    throw new UnsupportedOperationException();
  }

  public void removeELContextListener(ELContextListener listener)
  {
    throw new UnsupportedOperationException();
  }

  public ELContextListener[] getELContextListeners()
  {
    throw new UnsupportedOperationException();
  }

  public abstract void addValidator(String paramString1, String paramString2);

  public abstract Validator createValidator(String paramString)
    throws FacesException;

  public abstract Iterator<String> getValidatorIds();

  /**
   * @deprecated
   */
  public abstract ValueBinding createValueBinding(String paramString)
    throws ReferenceSyntaxException;
}