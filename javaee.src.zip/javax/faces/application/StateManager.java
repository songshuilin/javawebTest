package javax.faces.application;

import java.io.IOException;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public abstract class StateManager
{
  public static final String STATE_SAVING_METHOD_PARAM_NAME = "javax.faces.STATE_SAVING_METHOD";
  public static final String STATE_SAVING_METHOD_CLIENT = "client";
  public static final String STATE_SAVING_METHOD_SERVER = "server";
  private Boolean savingStateInClient;

  public StateManager()
  {
    this.savingStateInClient = null;
  }

  /**
   * @deprecated
   */
  public SerializedView saveSerializedView(FacesContext context)
  {
    return null;
  }

  public Object saveView(FacesContext context)
  {
    SerializedView view = saveSerializedView(context);
    Object[] stateArray = { view.getStructure(), view.getState() };

    return stateArray;
  }

  /**
   * @deprecated
   */
  protected Object getTreeStructureToSave(FacesContext context)
  {
    return null;
  }

  /**
   * @deprecated
   */
  protected Object getComponentStateToSave(FacesContext context)
  {
    return null;
  }

  public void writeState(FacesContext context, Object state)
    throws IOException
  {
    if ((null != state) && (state.getClass().isArray()) && (state.getClass().getComponentType().equals(Object.class)))
    {
      Object[] stateArray = (Object[])(Object[])state;
      if (2 == stateArray.length) {
        SerializedView view = new SerializedView(this, stateArray[0], stateArray[1]);

        writeState(context, view);
      }
    }
  }

  /**
   * @deprecated
   */
  public void writeState(FacesContext context, SerializedView state)
    throws IOException
  {
  }

  public abstract UIViewRoot restoreView(FacesContext paramFacesContext, String paramString1, String paramString2);

  /**
   * @deprecated
   */
  protected UIViewRoot restoreTreeStructure(FacesContext context, String viewId, String renderKitId)
  {
    return null;
  }

  /**
   * @deprecated
   */
  protected void restoreComponentState(FacesContext context, UIViewRoot viewRoot, String renderKitId)
  {
  }

  public boolean isSavingStateInClient(FacesContext context)
  {
    if (null != this.savingStateInClient)
      return this.savingStateInClient.booleanValue();

    this.savingStateInClient = Boolean.FALSE;

    String saveStateParam = context.getExternalContext().getInitParameter("javax.faces.STATE_SAVING_METHOD");

    if ((saveStateParam != null) && (saveStateParam.equalsIgnoreCase("client")))
    {
      this.savingStateInClient = Boolean.TRUE;
    }
    return this.savingStateInClient.booleanValue();
  }

  /**
   * @deprecated
   */
  public class SerializedView
  {
    private Object structure = null;
    private Object state = null;

    public SerializedView(, Object paramObject1, Object paramObject2) {
      this.state = paramObject1;
      this.state = paramObject2;
    }

    public Object getStructure() {
      return this.state;
    }

    public Object getState() {
      return this.state;
    }
  }
}