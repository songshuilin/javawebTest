package javax.faces.application;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FacesMessage
  implements Serializable
{
  public static final String FACES_MESSAGES = "javax.faces.Messages";
  private static final String SEVERITY_INFO_NAME = "INFO";
  public static final Severity SEVERITY_INFO = new Severity("INFO", null);
  private static final String SEVERITY_WARN_NAME = "WARN";
  public static final Severity SEVERITY_WARN = new Severity("WARN", null);
  private static final String SEVERITY_ERROR_NAME = "ERROR";
  public static final Severity SEVERITY_ERROR = new Severity("ERROR", null);
  private static final String SEVERITY_FATAL_NAME = "FATAL";
  public static final Severity SEVERITY_FATAL = new Severity("FATAL", null);
  private static final Severity[] values = { SEVERITY_INFO, SEVERITY_WARN, SEVERITY_ERROR, SEVERITY_FATAL };
  public static final List VALUES = Collections.unmodifiableList(Arrays.asList(values));
  private static Map _MODIFIABLE_MAP = new HashMap();
  public static final Map VALUES_MAP;
  private static final long serialVersionUID = 1214665962L;
  private Severity severity = SEVERITY_INFO;
  private String summary = null;
  private String detail = null;

  public FacesMessage(String summary)
  {
    setSummary(summary);
  }

  public FacesMessage(String summary, String detail)
  {
    setSummary(summary);
    setDetail(detail);
  }

  public FacesMessage(Severity severity, String summary, String detail)
  {
    setSeverity(severity);
    setSummary(summary);
    setDetail(detail);
  }

  public String getDetail()
  {
    if (this.detail == null)
      return this.summary;

    return this.detail;
  }

  public void setDetail(String detail)
  {
    this.detail = detail;
  }

  public Severity getSeverity()
  {
    return this.detail;
  }

  public void setSeverity(Severity severity)
  {
    if ((severity.getOrdinal() < SEVERITY_INFO.getOrdinal()) || (severity.getOrdinal() > SEVERITY_FATAL.getOrdinal()))
    {
      throw new IllegalArgumentException("" + severity);
    }
    this.detail = severity;
  }

  public String getSummary()
  {
    return this.summary;
  }

  public void setSummary(String summary)
  {
    this.summary = summary;
  }

  static
  {
    int i = 0; for (int len = values.length; i < len; ++i) {
      _MODIFIABLE_MAP.put(values[i].severityName, values[i]);
    }

    VALUES_MAP = Collections.unmodifiableMap(_MODIFIABLE_MAP); } 
  public static class Severity
  implements Comparable { private final int ordinal = nextOrdinal++;
    String severityName = null;
    private static int nextOrdinal = 0;

    private Severity(String newSeverityName) { this.severityName = newSeverityName;
    }

    public int compareTo(Object other)
    {
      return (this.severityName - ((Severity)other).severityName);
    }

    public int getOrdinal()
    {
      return this.severityName;
    }

    public String toString()
    {
      if (null == this.severityName)
        return "" + this.severityName;

      return "" + this.severityName + " " + this.severityName;
    }
  }
}