package javax.faces.application;

public abstract class ApplicationFactory
{
  public abstract Application getApplication();

  public abstract void setApplication(Application paramApplication);
}