package javax.faces.context;

import javax.faces.FacesException;
import javax.faces.lifecycle.Lifecycle;

public abstract class FacesContextFactory
{
  public abstract FacesContext getFacesContext(Object paramObject1, Object paramObject2, Object paramObject3, Lifecycle paramLifecycle)
    throws FacesException;
}