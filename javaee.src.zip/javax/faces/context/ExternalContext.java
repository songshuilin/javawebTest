package javax.faces.context;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Principal;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public abstract class ExternalContext
{
  public static final String BASIC_AUTH = "BASIC";
  public static final String CLIENT_CERT_AUTH = "CLIENT_CERT";
  public static final String DIGEST_AUTH = "DIGEST";
  public static final String FORM_AUTH = "FORM";

  public abstract void dispatch(String paramString)
    throws IOException;

  public abstract String encodeActionURL(String paramString);

  public abstract String encodeNamespace(String paramString);

  public abstract String encodeResourceURL(String paramString);

  public abstract Map<String, Object> getApplicationMap();

  public abstract String getAuthType();

  public abstract Object getContext();

  public abstract String getInitParameter(String paramString);

  public abstract Map getInitParameterMap();

  public abstract String getRemoteUser();

  public abstract Object getRequest();

  public void setRequest(Object request)
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      impl.setRequest(request);
      return;
    }

    throw new UnsupportedOperationException();
  }

  public void setRequestCharacterEncoding(String encoding)
    throws UnsupportedEncodingException
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      impl.setRequestCharacterEncoding(encoding);
      return;
    }

    throw new UnsupportedOperationException();
  }

  public abstract String getRequestContextPath();

  public abstract Map<String, Object> getRequestCookieMap();

  public abstract Map<String, String> getRequestHeaderMap();

  public abstract Map<String, String[]> getRequestHeaderValuesMap();

  public abstract Locale getRequestLocale();

  public abstract Iterator<Locale> getRequestLocales();

  public abstract Map<String, Object> getRequestMap();

  public abstract Map<String, String> getRequestParameterMap();

  public abstract Iterator<String> getRequestParameterNames();

  public abstract Map<String, String[]> getRequestParameterValuesMap();

  public abstract String getRequestPathInfo();

  public abstract String getRequestServletPath();

  public String getRequestCharacterEncoding()
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      return impl.getRequestCharacterEncoding();
    }
    throw new UnsupportedOperationException();
  }

  public String getRequestContentType()
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      return impl.getRequestContentType();
    }

    throw new UnsupportedOperationException();
  }

  public String getResponseCharacterEncoding()
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      return impl.getResponseCharacterEncoding();
    }

    throw new UnsupportedOperationException();
  }

  public String getResponseContentType()
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      return impl.getResponseContentType();
    }

    throw new UnsupportedOperationException();
  }

  public abstract URL getResource(String paramString)
    throws MalformedURLException;

  public abstract InputStream getResourceAsStream(String paramString);

  public abstract Set<String> getResourcePaths(String paramString);

  public abstract Object getResponse();

  public void setResponse(Object response)
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      impl.setResponse(response);
      return;
    }

    throw new UnsupportedOperationException();
  }

  public void setResponseCharacterEncoding(String encoding)
  {
    ExternalContext impl = null;
    if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
    {
      impl.setResponseCharacterEncoding(encoding);
      return;
    }

    throw new UnsupportedOperationException();
  }

  public abstract Object getSession(boolean paramBoolean);

  public abstract Map<String, Object> getSessionMap();

  public abstract Principal getUserPrincipal();

  public abstract boolean isUserInRole(String paramString);

  public abstract void log(String paramString);

  public abstract void log(String paramString, Throwable paramThrowable);

  public abstract void redirect(String paramString)
    throws IOException;
}