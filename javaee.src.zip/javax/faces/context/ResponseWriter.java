package javax.faces.context;

import java.io.IOException;
import java.io.Writer;
import javax.faces.component.UIComponent;

public abstract class ResponseWriter extends Writer
{
  public abstract String getContentType();

  public abstract String getCharacterEncoding();

  public abstract void flush()
    throws IOException;

  public abstract void startDocument()
    throws IOException;

  public abstract void endDocument()
    throws IOException;

  public abstract void startElement(String paramString, UIComponent paramUIComponent)
    throws IOException;

  public abstract void endElement(String paramString)
    throws IOException;

  public abstract void writeAttribute(String paramString1, Object paramObject, String paramString2)
    throws IOException;

  public abstract void writeURIAttribute(String paramString1, Object paramObject, String paramString2)
    throws IOException;

  public abstract void writeComment(Object paramObject)
    throws IOException;

  public abstract void writeText(Object paramObject, String paramString)
    throws IOException;

  public void writeText(Object text, UIComponent component, String property)
    throws IOException
  {
    writeText(text, property);
  }

  public abstract void writeText(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException;

  public abstract ResponseWriter cloneWithWriter(Writer paramWriter);
}