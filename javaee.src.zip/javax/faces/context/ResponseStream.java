package javax.faces.context;

import java.io.OutputStream;

public abstract class ResponseStream extends OutputStream
{
}