package javax.faces.context;

import java.util.Iterator;
import java.util.Map;
import javax.el.ELContext;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.component.UIViewRoot;
import javax.faces.render.RenderKit;

public abstract class FacesContext
{
  private static ThreadLocal instance = new ThreadLocal() {
    protected Object initialValue() { return null;
    }
  };

  public abstract Application getApplication();

  public abstract Iterator<String> getClientIdsWithMessages();

  public ELContext getELContext()
  {
    FacesContext impl = null;
    if (null != (impl = (FacesContext)getExternalContext().getRequestMap().get("com.sun.faces.FacesContextImpl")))
    {
      return impl.getELContext();
    }
    throw new UnsupportedOperationException();
  }

  public abstract ExternalContext getExternalContext();

  public abstract FacesMessage.Severity getMaximumSeverity();

  public abstract Iterator<FacesMessage> getMessages();

  public abstract Iterator<FacesMessage> getMessages(String paramString);

  public abstract RenderKit getRenderKit();

  public abstract boolean getRenderResponse();

  public abstract boolean getResponseComplete();

  public abstract ResponseStream getResponseStream();

  public abstract void setResponseStream(ResponseStream paramResponseStream);

  public abstract ResponseWriter getResponseWriter();

  public abstract void setResponseWriter(ResponseWriter paramResponseWriter);

  public abstract UIViewRoot getViewRoot();

  public abstract void setViewRoot(UIViewRoot paramUIViewRoot);

  public abstract void addMessage(String paramString, FacesMessage paramFacesMessage);

  public abstract void release();

  public abstract void renderResponse();

  public abstract void responseComplete();

  public static FacesContext getCurrentInstance()
  {
    return ((FacesContext)instance.get());
  }

  protected static void setCurrentInstance(FacesContext context)
  {
    instance.set(context);
  }
}