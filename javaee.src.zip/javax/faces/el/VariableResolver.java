package javax.faces.el;

import javax.faces.context.FacesContext;

/**
 * @deprecated
 */
public abstract class VariableResolver
{
  public abstract Object resolveVariable(FacesContext paramFacesContext, String paramString)
    throws EvaluationException;
}