package javax.faces.el;

/**
 * @deprecated
 */
public abstract class PropertyResolver
{
  public abstract Object getValue(Object paramObject1, Object paramObject2)
    throws EvaluationException, PropertyNotFoundException;

  public abstract Object getValue(Object paramObject, int paramInt)
    throws EvaluationException, PropertyNotFoundException;

  public abstract void setValue(Object paramObject1, Object paramObject2, Object paramObject3)
    throws EvaluationException, PropertyNotFoundException;

  public abstract void setValue(Object paramObject1, int paramInt, Object paramObject2)
    throws EvaluationException, PropertyNotFoundException;

  public abstract boolean isReadOnly(Object paramObject1, Object paramObject2)
    throws EvaluationException, PropertyNotFoundException;

  public abstract boolean isReadOnly(Object paramObject, int paramInt)
    throws EvaluationException, PropertyNotFoundException;

  public abstract Class getType(Object paramObject1, Object paramObject2)
    throws EvaluationException, PropertyNotFoundException;

  public abstract Class getType(Object paramObject, int paramInt)
    throws EvaluationException, PropertyNotFoundException;
}