package javax.faces.el;

import javax.faces.context.FacesContext;

/**
 * @deprecated
 */
public abstract class ValueBinding
{
  public abstract Object getValue(FacesContext paramFacesContext)
    throws EvaluationException, PropertyNotFoundException;

  public abstract void setValue(FacesContext paramFacesContext, Object paramObject)
    throws EvaluationException, PropertyNotFoundException;

  public abstract boolean isReadOnly(FacesContext paramFacesContext)
    throws EvaluationException, PropertyNotFoundException;

  public abstract Class getType(FacesContext paramFacesContext)
    throws EvaluationException, PropertyNotFoundException;

  public String getExpressionString()
  {
    return null;
  }
}