package javax.faces.el;

import javax.faces.context.FacesContext;

/**
 * @deprecated
 */
public abstract class MethodBinding
{
  public abstract Object invoke(FacesContext paramFacesContext, Object[] paramArrayOfObject)
    throws EvaluationException, MethodNotFoundException;

  public abstract Class getType(FacesContext paramFacesContext)
    throws MethodNotFoundException;

  public String getExpressionString()
  {
    return null;
  }
}