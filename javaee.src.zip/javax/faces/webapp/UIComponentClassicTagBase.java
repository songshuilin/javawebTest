package javax.faces.webapp;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.component.NamingContainer;
import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.jstl.core.LoopTag;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTag;
import javax.servlet.jsp.tagext.JspIdConsumer;
import javax.servlet.jsp.tagext.Tag;

public abstract class UIComponentClassicTagBase extends UIComponentTagBase
  implements JspIdConsumer, BodyTag
{
  private static final String COMPONENT_TAG_STACK_ATTR = "javax.faces.webapp.COMPONENT_TAG_STACK";
  private static final String JSP_CREATED_COMPONENT_IDS = "javax.faces.webapp.COMPONENT_IDS";
  private static final String JSP_CREATED_FACET_NAMES = "javax.faces.webapp.FACET_NAMES";
  private static final String GLOBAL_ID_VIEW = "javax.faces.webapp.GLOBAL_ID_VIEW";
  private static final String CURRENT_FACES_CONTEXT = "javax.faces.webapp.CURRENT_FACES_CONTEXT";
  private static final String CURRENT_VIEW_ROOT = "javax.faces.webapp.CURRENT_VIEW_ROOT";
  protected static final String UNIQUE_ID_PREFIX = "j_id_";
  private static final String PREVIOUS_JSP_ID_SET = "javax.faces.webapp.PREVIOUS_JSP_ID_SET";
  protected BodyContent bodyContent;
  private UIComponent component;
  private FacesContext context;
  private boolean created;
  private List<String> createdComponents;
  private List createdFacets;
  protected PageContext pageContext;
  private Tag parent;
  private String jspId;
  private String facesJspId;
  private String id;
  private UIComponentClassicTagBase parentTag;
  private boolean isNestedInIterator;

  public UIComponentClassicTagBase()
  {
    this.bodyContent = null;

    this.component = null;

    this.context = null;

    this.created = false;

    this.createdComponents = null;

    this.createdFacets = null;

    this.pageContext = null;

    this.parent = null;

    this.jspId = null;

    this.facesJspId = null;

    this.id = null;

    this.parentTag = null;

    this.isNestedInIterator = false;
  }

  protected int getDoStartValue()
    throws JspException
  {
    int result = 2;

    return result;
  }

  protected int getDoEndValue()
    throws JspException
  {
    return 6;
  }

  /**
   * @deprecated
   */
  protected void encodeBegin()
    throws IOException
  {
    this.component.encodeBegin(this.context);
  }

  /**
   * @deprecated
   */
  protected void encodeChildren()
    throws IOException
  {
    this.component.encodeChildren(this.context);
  }

  /**
   * @deprecated
   */
  protected void encodeEnd()
    throws IOException
  {
    this.component.encodeEnd(this.context);
  }

  public void setPageContext(PageContext pageContext)
  {
    this.pageContext = pageContext;
  }

  public Tag getParent()
  {
    return this.parent;
  }

  public void setParent(Tag parent)
  {
    this.parent = parent;
  }

  protected void setupResponseWriter()
  {
  }

  private UIComponent createChild(FacesContext context, UIComponent parent, String componentId)
    throws JspException
  {
    UIComponent component = createComponent(context, componentId);
    UIComponentTagBase parentTag = getParentUIComponentClassicTagBase(this.pageContext);
    int indexOfNextChildTag = parentTag.getIndexOfNextChildTag();
    if (indexOfNextChildTag > parent.getChildCount())
      indexOfNextChildTag = parent.getChildCount();

    parent.getChildren().add(indexOfNextChildTag, component);
    this.created = true;
    return component;
  }

  private UIComponent createFacet(FacesContext context, UIComponent parent, String name, String newId)
    throws JspException
  {
    UIComponent component = createComponent(context, newId);
    parent.getFacets().put(name, component);
    this.created = true;
    return component;
  }

  private UIComponent getChild(UIComponent component, String componentId)
  {
    Iterator kids = component.getChildren().iterator();
    while (kids.hasNext()) {
      UIComponent kid = (UIComponent)kids.next();
      if (componentId.equals(kid.getId()))
        return kid;
    }

    return null;
  }

  protected UIComponent findComponent(FacesContext context)
    throws JspException
  {
    if (this.component != null) {
      return this.component;
    }

    UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(this.pageContext);

    UIComponent parentComponent = null;
    if (parentTag != null) {
      parentComponent = parentTag.getComponentInstance();
    }
    else
    {
      parentComponent = context.getViewRoot();

      if (null == parentComponent.getAttributes().get("javax.faces.webapp.CURRENT_VIEW_ROOT"))
      {
        try
        {
          setProperties(parentComponent);
        }
        catch (FacesException e) {
          if (e.getCause() instanceof JspException)
            throw ((JspException)e.getCause());

          throw e;
        }

        if (null != this.id)
          parentComponent.setId(this.id);
        else
        {
          if ((!($assertionsDisabled)) && (null == getFacesJspId())) throw new AssertionError();
          parentComponent.setId(getFacesJspId());
        }
        parentComponent.getAttributes().put("javax.faces.webapp.CURRENT_VIEW_ROOT", "javax.faces.webapp.CURRENT_VIEW_ROOT");

        this.created = true;
      }
      else if (hasBinding()) {
        try {
          setProperties(parentComponent);
        }
        catch (FacesException e) {
          if (e.getCause() instanceof JspException)
            throw ((JspException)e.getCause());

          throw e;
        }

      }

      this.component = parentComponent;
      return this.component;
    }

    String newId = createId(context, parentComponent);

    String facetName = getFacetName();
    if (facetName != null) {
      this.component = ((UIComponent)parentComponent.getFacets().get(facetName));

      if (this.component == null) {
        this.component = createFacet(context, parentComponent, facetName, newId);
      }

      return this.component;
    }

    this.component = getChild(parentComponent, newId);
    if (this.component == null)
      this.component = createChild(context, parentComponent, newId);

    return this.component;
  }

  public static UIComponentClassicTagBase getParentUIComponentClassicTagBase(PageContext context)
  {
    FacesContext facesContext = (FacesContext)context.getAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT");

    List list = (List)facesContext.getExternalContext().getRequestMap().get("javax.faces.webapp.COMPONENT_TAG_STACK");

    if (list != null)
      return ((UIComponentClassicTagBase)list.get(list.size() - 1));

    return null;
  }

  protected int getIndexOfNextChildTag()
  {
    if (this.createdComponents != null)
      return this.createdComponents.size();

    return 0;
  }

  protected void addChild(UIComponent child)
  {
    if (this.createdComponents == null)
      this.createdComponents = new ArrayList(32);

    this.createdComponents.add(child.getId());
  }

  protected void addFacet(String name)
  {
    if (this.createdFacets == null)
      this.createdFacets = new ArrayList();

    this.createdFacets.add(name);
  }

  private void popUIComponentClassicTagBase()
  {
    Map requestMap = this.context.getExternalContext().getRequestMap();

    List list = (List)requestMap.get("javax.faces.webapp.COMPONENT_TAG_STACK");
    if (list != null) {
      list.remove(list.size() - 1);
      if (list.size() < 1)
        requestMap.remove("javax.faces.webapp.COMPONENT_TAG_STACK");
    }
  }

  private void pushUIComponentClassicTagBase()
  {
    Map requestMap = this.context.getExternalContext().getRequestMap();

    List list = (List)requestMap.get("javax.faces.webapp.COMPONENT_TAG_STACK");

    if (list == null) {
      list = new ArrayList();
      requestMap.put("javax.faces.webapp.COMPONENT_TAG_STACK", list);
    }
    list.add(this);
  }

  private void removeOldChildren()
  {
    List oldList = (List)this.component.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");

    if ((oldList != null) && (oldList.size() > 0))
    {
      Iterator olds;
      String old;
      UIComponent child;
      if (this.createdComponents != null)
      {
        olds = oldList.iterator();
        while (olds.hasNext()) {
          old = (String)olds.next();
          if (!(this.createdComponents.contains(old))) {
            child = this.component.findComponent(old);

            if (child != null)
              this.component.getChildren().remove(child);
          }

        }

      }
      else
      {
        olds = oldList.iterator();
        while (olds.hasNext()) {
          old = (String)olds.next();
          child = this.component.findComponent(old);
          this.component.getChildren().remove(child);
        }

      }

    }

    if (this.createdComponents != null) {
      this.component.getAttributes().put("javax.faces.webapp.COMPONENT_IDS", this.createdComponents);
    }
    else
      this.component.getAttributes().remove("javax.faces.webapp.COMPONENT_IDS");

    this.createdComponents = null;
  }

  private void removeOldFacets()
  {
    List oldList = (List)this.component.getAttributes().get("javax.faces.webapp.FACET_NAMES");

    if (oldList != null)
    {
      Iterator olds;
      String old;
      if (this.createdFacets != null)
      {
        olds = oldList.iterator();
        while (olds.hasNext()) {
          old = (String)olds.next();
          if (!(this.createdFacets.contains(old)))
            this.component.getFacets().remove(old);

        }

      }
      else
      {
        olds = oldList.iterator();
        while (olds.hasNext()) {
          old = (String)olds.next();
          this.component.getFacets().remove(old);
        }

      }

    }

    if (this.createdFacets != null) {
      this.component.getAttributes().put("javax.faces.webapp.FACET_NAMES", this.createdFacets);
    }
    else
      this.component.getAttributes().remove("javax.faces.webapp.FACET_NAMES");

    this.createdFacets = null;
  }

  protected UIComponent createVerbatimComponentFromBodyContent()
  {
    UIOutput verbatim = null;
    String bodyContentString = null;
    String trimString = null;
    if (null != this.bodyContent) if (null != (bodyContentString = this.bodyContent.getString())) if (0 < (trimString = this.bodyContent.getString().trim()).length())
        {
          if ((!(trimString.startsWith("<!--"))) || (!(trimString.endsWith("-->"))))
          {
            verbatim = createVerbatimComponent();
            verbatim.setValue(bodyContentString);
            this.bodyContent.clearBody();
          }
          else
            this.bodyContent.clearBody();
        }

    return verbatim;
  }

  protected UIOutput createVerbatimComponent()
  {
    if ((!($assertionsDisabled)) && (null == getFacesContext())) throw new AssertionError();
    UIOutput verbatim = null;
    Application application = getFacesContext().getApplication();
    verbatim = (UIOutput)application.createComponent("javax.faces.HtmlOutputText");

    verbatim.setTransient(true);
    verbatim.getAttributes().put("escape", Boolean.FALSE);
    verbatim.setId(getFacesContext().getViewRoot().createUniqueId());
    return verbatim;
  }

  protected void addVerbatimBeforeComponent(UIComponentClassicTagBase parentTag, UIComponent verbatim, UIComponent component)
  {
    UIComponent parent = component.getParent();
    if (null == parent) {
      return;
    }

    List children = parent.getChildren();

    List createdIds = (List)parent.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");

    int indexOfComponentInParent = children.indexOf(component);
    boolean replace = (indexOfComponentInParent > 0) && (createdIds != null) && (createdIds.size() == children.size());

    if (replace) {
      UIComponent oldVerbatim = (UIComponent)children.get(indexOfComponentInParent - 1);
      if ((oldVerbatim instanceof UIOutput) && (oldVerbatim.isTransient()))
        children.set(indexOfComponentInParent - 1, verbatim);
      else
        children.add(indexOfComponentInParent, verbatim);
    }
    else
      children.add(indexOfComponentInParent, verbatim);

    parentTag.addChild(verbatim);
  }

  protected void addVerbatimAfterComponent(UIComponentClassicTagBase parentTag, UIComponent verbatim, UIComponent component)
  {
    int indexOfComponentInParent = 0;
    UIComponent parent = component.getParent();

    if (null == parent)
      return;

    List children = parent.getChildren();
    indexOfComponentInParent = children.indexOf(component);
    if (children.size() - 1 == indexOfComponentInParent) {
      children.add(verbatim);
    }
    else
      children.add(indexOfComponentInParent + 1, verbatim);

    parentTag.addChild(verbatim);
  }

  public int doStartTag()
    throws JspException
  {
    this.createdComponents = null;
    this.createdFacets = null;
    UIComponent verbatim = null;

    this.context = getFacesContext();
    if (null == this.context)
    {
      throw new JspException("Can't find FacesContext");
    }

    this.parentTag = getParentUIComponentClassicTagBase(this.pageContext);
    Map requestMap = this.context.getExternalContext().getRequestMap();
    Map componentIds = null;
    if (this.parentTag == null)
    {
      componentIds = new HashMap();
      requestMap.put("javax.faces.webapp.GLOBAL_ID_VIEW", componentIds);
    }
    else { componentIds = (Map)requestMap.get("javax.faces.webapp.GLOBAL_ID_VIEW");
    }

    if ((null == getFacetName()) && (null != this.parentTag))
    {
      Tag p = getParent();

      if ((null == p) || (p instanceof LoopTag)) {
        JspWriter out = this.pageContext.getOut();
        if (!(out instanceof BodyContent))
          try {
            out.flush();
          }
          catch (IOException ioe) {
            throw new JspException(ioe);
          }
      }

      verbatim = this.parentTag.createVerbatimComponentFromBodyContent();
    }

    this.component = findComponent(this.context);

    if (null != verbatim) {
      addVerbatimBeforeComponent(this.parentTag, verbatim, this.component);
    }

    Object tagInstance = null;
    String clientId = null;
    if (this.id != null) {
      clientId = this.component.getClientId(this.context);
      tagInstance = (componentIds.get(clientId) == this) ? this : null;
    }

    if (tagInstance == null)
    {
      if ((null != this.id) && 
        (clientId != null)) {
        if (componentIds.containsKey(clientId))
        {
          StringWriter writer = new StringWriter(128);
          printTree(this.context.getViewRoot(), clientId, writer, 0);
          String msg = "Duplicate component id: '" + clientId + "', first used in tag: '" + componentIds.get(clientId).getClass().getName() + "'\n" + writer.toString();

          throw new JspException(new IllegalStateException(msg));
        }
        componentIds.put(clientId, this);
      }

      if (this.parentTag != null) {
        if (getFacetName() == null)
          this.parentTag.addChild(this.component);
        else {
          this.parentTag.addFacet(getFacetName());
        }

      }

    }

    pushUIComponentClassicTagBase();
    return getDoStartValue();
  }

  public int doEndTag()
    throws JspException
  {
    popUIComponentClassicTagBase();
    removeOldChildren();
    removeOldFacets();
    try
    {
      UIComponent verbatim = null;
      UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(this.pageContext);

      if (null != (verbatim = createVerbatimComponentFromBodyContent())) {
        this.component.getChildren().add(verbatim);
        if (null != parentTag)
          parentTag.addChild(verbatim);

      }

    }
    catch (Throwable e)
    {
    }
    finally
    {
      this.component = null;
      this.context = null;
    }

    this.created = false;

    release();
    return getDoEndValue();
  }

  public void release()
  {
    this.parent = null;

    this.id = null;
    this.jspId = null;
    this.facesJspId = null;
    this.created = false;
    this.bodyContent = null;
    this.isNestedInIterator = false;
  }

  protected int getDoAfterBodyValue()
    throws JspException
  {
    return 0;
  }

  public void setBodyContent(BodyContent bodyContent)
  {
    this.bodyContent = bodyContent;
  }

  public JspWriter getPreviousOut()
  {
    return this.bodyContent.getEnclosingWriter();
  }

  public BodyContent getBodyContent()
  {
    return this.bodyContent;
  }

  public void doInitBody()
    throws JspException
  {
  }

  public int doAfterBody()
    throws JspException
  {
    UIComponent verbatim = null;
    UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(this.pageContext);

    if ((this == parentTag) || ((null != parentTag) && (parentTag.getComponentInstance().getRendersChildren())))
    {
      if (null != (verbatim = createVerbatimComponentFromBodyContent()))
      {
        List createdIds = (List)this.component.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");

        if (createdIds != null) {
          int listIdx = this.component.getChildCount();
          if (createdIds.size() == listIdx)
            this.component.getChildren().set(listIdx - 1, verbatim);
          else
            this.component.getChildren().add(verbatim);
        }
        else
          this.component.getChildren().add(verbatim);

        parentTag.addChild(verbatim);
      }
    }

    return getDoAfterBodyValue();
  }

  public void setId(String id)
  {
    if ((null != id) && (id.startsWith("j_id"))) {
      throw new IllegalArgumentException();
    }

    this.id = id;
  }

  protected String getId()
  {
    return this.id;
  }

  protected String getFacesJspId()
  {
    if (null == this.facesJspId)
      if (null != this.jspId) {
        this.facesJspId = "j_id_" + this.jspId;

        if ((isDuplicateId(this.facesJspId)) || (isIncludedOrForwarded())) {
          this.facesJspId = generateIncrementedId(this.facesJspId);
        }

      }
      else
        this.facesJspId = this.context.getViewRoot().createUniqueId();


    return this.facesJspId;
  }

  private boolean isDuplicateId(String componentId)
  {
    boolean result = false;
    if (this.parentTag != null)
    {
      if (this.parentTag.isNestedInIterator)
        return true;

      List childComponents = this.parentTag.getCreatedComponents();

      if (childComponents != null) {
        result = childComponents.contains(componentId);
        if ((result) && (!(this.isNestedInIterator)))
          return true;
      }

    }

    return result;
  }

  private String generateIncrementedId(String componentId)
  {
    Map requestMap = getFacesContext().getExternalContext().getRequestMap();
    Integer serialNum = (Integer)requestMap.get(componentId);
    if (null == serialNum)
      serialNum = new Integer(1);
    else
      serialNum = new Integer(serialNum.intValue() + 1);

    requestMap.put(componentId, serialNum);
    componentId = componentId + "j_id_" + serialNum.intValue();
    return componentId;
  }

  protected List<String> getCreatedComponents()
  {
    return this.createdComponents;
  }

  private String createId(FacesContext context, UIComponent parent)
    throws JspException
  {
    if (this.id == null) {
      return getFacesJspId();
    }

    if (isDuplicateId(this.id))
      if (this.isNestedInIterator) {
        this.id = generateIncrementedId(this.id);
      }
      else
      {
        if (parent != null) {
          UIComponent container = getNamingContainer(parent);
          if (container != null) {
            UIComponent comp = container.findComponent(this.id);

            if ((comp == null) || (context.getExternalContext().getRequestParameterMap().containsKey("javax.faces.ViewState")))
            {
              return this.id;
            }
          }
        }
        StringWriter writer = new StringWriter(128);
        printTree(context.getViewRoot(), this.id, writer, 0);
        String msg = "Component ID '" + this.id + "' has already been used" + " in the view.\n" + "See below for the view up to the point of" + " the detected error.\n" + writer.toString();

        throw new JspException(msg);
      }

    return this.id;
  }

  public void setJspId(String id)
  {
    this.facesJspId = null;
    updatePreviousJspIdAndIteratorStatus(id);
    this.jspId = id;
  }

  private void updatePreviousJspIdAndIteratorStatus(String id)
  {
    Set previousJspIdSet = null;

    if (null == (previousJspIdSet = (Set)this.pageContext.getRequest().getAttribute("javax.faces.webapp.PREVIOUS_JSP_ID_SET")))
    {
      this.pageContext.getRequest().setAttribute("javax.faces.webapp.PREVIOUS_JSP_ID_SET", previousJspIdSet = new HashSet());
    }

    if ((!($assertionsDisabled)) && (null == previousJspIdSet)) throw new AssertionError();

    if ((previousJspIdSet.contains(id)) && (!(isIncludedOrForwarded()))) {
      if (log.isLoggable(Level.FINEST)) {
        log.log(Level.FINEST, "Id " + id + " is nested within an iterating tag.");
      }

      this.isNestedInIterator = true;
    }
    else {
      this.isNestedInIterator = false;
      previousJspIdSet.add(id);
    }
  }

  private boolean isIncludedOrForwarded() {
    return getFacesContext().getExternalContext().getRequestMap().containsKey("javax.servlet.include.request_uri");
  }

  public String getJspId()
  {
    return this.jspId;
  }

  protected abstract void setProperties(UIComponent paramUIComponent);

  protected abstract UIComponent createComponent(FacesContext paramFacesContext, String paramString)
    throws JspException;

  protected abstract boolean hasBinding();

  public UIComponent getComponentInstance()
  {
    return this.component;
  }

  public boolean getCreated()
  {
    return this.created;
  }

  protected FacesContext getFacesContext()
  {
    if (this.context == null)
      if (null == (this.context = (FacesContext)this.pageContext.getAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT")))
      {
        this.context = FacesContext.getCurrentInstance();

        if (this.context == null) {
          throw new RuntimeException("Cannot find FacesContext");
        }

        this.pageContext.setAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT", this.context);
      }


    return this.context;
  }

  protected String getFacetName()
  {
    Tag parent = getParent();
    if (parent instanceof FacetTag)
      return ((FacetTag)parent).getName();

    return null;
  }

  private static void printTree(UIComponent root, String duplicateId, Writer out, int curDepth)
  {
    UIComponent uiComponent;
    if (null == root) {
      return;
    }

    if (duplicateId.equals(root.getId())) {
      indentPrintln(out, "+id: " + root.getId() + "  <===============", curDepth);
    }
    else
      indentPrintln(out, "+id: " + root.getId(), curDepth);

    indentPrintln(out, " type: " + root.toString(), curDepth);

    ++curDepth;

    for (Iterator i$ = root.getFacets().values().iterator(); i$.hasNext(); ) { uiComponent = (UIComponent)i$.next();
      printTree(uiComponent, duplicateId, out, curDepth);
    }

    for (i$ = root.getChildren().iterator(); i$.hasNext(); ) { uiComponent = (UIComponent)i$.next();
      printTree(uiComponent, duplicateId, out, curDepth);
    }
  }

  private static void indentPrintln(Writer out, String str, int curDepth)
  {
    int i;
    try
    {
      for (i = 0; i < curDepth; ++i)
        out.write("  ");

      out.write(str + "\n");
    }
    catch (IOException ex)
    {
    }
  }

  private UIComponent getNamingContainer(UIComponent component)
  {
    UIComponent namingContainer = component;
    while (namingContainer != null) {
      if (namingContainer instanceof NamingContainer)
        return namingContainer;

      namingContainer = namingContainer.getParent();
    }
    return null;
  }
}