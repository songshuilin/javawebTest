package javax.faces.webapp;

/**
 * @deprecated
 */
public abstract class UIComponentBodyTag extends UIComponentTag
{
}