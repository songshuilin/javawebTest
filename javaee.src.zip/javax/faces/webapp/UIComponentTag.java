package javax.faces.webapp;

import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

/**
 * @deprecated
 */
public abstract class UIComponentTag extends UIComponentClassicTagBase
  implements Tag
{
  private String binding;
  private String rendered;
  private boolean suppressed;

  public UIComponentTag()
  {
    this.binding = null;

    this.rendered = null;

    this.suppressed = false;
  }

  public void setBinding(String binding)
    throws JspException
  {
    if (!(isValueReference(binding))) {
      throw new IllegalArgumentException();
    }

    this.binding = binding;
  }

  protected boolean hasBinding() {
    return (null != this.binding);
  }

  public void setRendered(String rendered)
  {
    this.rendered = rendered;
  }

  protected boolean isSuppressed()
  {
    return this.suppressed;
  }

  public static boolean isValueReference(String value)
  {
    if (value == null) {
      throw new NullPointerException();
    }

    return ((value.indexOf("#{") != -1) && (value.indexOf("#{") < value.indexOf(125)));
  }

  public void release()
  {
    this.suppressed = false;
    this.binding = null;
    this.rendered = null;
    super.release();
  }

  protected void setProperties(UIComponent component)
  {
    if (this.rendered != null)
      if (isValueReference(this.rendered)) {
        ValueBinding vb = getFacesContext().getApplication().createValueBinding(this.rendered);

        component.setValueBinding("rendered", vb);
      }
      else component.setRendered(Boolean.valueOf(this.rendered).booleanValue());


    if (getRendererType() != null)
      component.setRendererType(getRendererType());
  }

  protected UIComponent createComponent(FacesContext context, String newId)
  {
    UIComponent component = null;
    Application application = context.getApplication();
    if (this.binding != null) {
      ValueBinding vb = application.createValueBinding(this.binding);
      component = application.createComponent(vb, context, getComponentType());

      component.setValueBinding("binding", vb);
    }
    else { component = application.createComponent(getComponentType());
    }

    component.setId(newId);
    setProperties(component);

    return component;
  }

  public static UIComponentTag getParentUIComponentTag(PageContext context)
  {
    UIComponentClassicTagBase result = getParentUIComponentClassicTagBase(context);

    return ((UIComponentTag)result);
  }
}