package javax.faces.webapp;

import java.io.IOException;
import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public final class FacesServlet
  implements Servlet
{
  public static final String CONFIG_FILES_ATTR = "javax.faces.CONFIG_FILES";
  public static final String LIFECYCLE_ID_ATTR = "javax.faces.LIFECYCLE_ID";
  private FacesContextFactory facesContextFactory;
  private Lifecycle lifecycle;
  private ServletConfig servletConfig;

  public FacesServlet()
  {
    this.facesContextFactory = null;

    this.lifecycle = null;

    this.servletConfig = null;
  }

  public void destroy()
  {
    this.facesContextFactory = null;
    this.lifecycle = null;
    this.servletConfig = null;
  }

  public ServletConfig getServletConfig()
  {
    return this.servletConfig;
  }

  public String getServletInfo()
  {
    return super.getClass().getName();
  }

  public void init(ServletConfig servletConfig)
    throws ServletException
  {
    Throwable rootCause;
    this.servletConfig = servletConfig;
    try
    {
      this.facesContextFactory = ((FacesContextFactory)FactoryFinder.getFactory("javax.faces.context.FacesContextFactory"));
    }
    catch (FacesException e)
    {
      rootCause = e.getCause();
      if (rootCause == null)
        throw e;

      throw new ServletException(e.getMessage(), rootCause);
    }

    try
    {
      LifecycleFactory lifecycleFactory = (LifecycleFactory)FactoryFinder.getFactory("javax.faces.lifecycle.LifecycleFactory");

      String lifecycleId = null;

      if (null == (lifecycleId = servletConfig.getInitParameter("javax.faces.LIFECYCLE_ID")))
      {
        lifecycleId = servletConfig.getServletContext().getInitParameter("javax.faces.LIFECYCLE_ID");
      }

      if (lifecycleId == null)
        lifecycleId = "DEFAULT";

      this.lifecycle = lifecycleFactory.getLifecycle(lifecycleId);
    } catch (FacesException lifecycleFactory) {
      rootCause = e.getCause();
      if (rootCause == null)
        throw e;
    }
    throw new ServletException(e.getMessage(), rootCause);
  }

  public void service(ServletRequest request, ServletResponse response)
    throws IOException, ServletException
  {
    String pathInfo = ((HttpServletRequest)request).getPathInfo();
    if (pathInfo != null) {
      pathInfo = pathInfo.toUpperCase();
      if ((pathInfo.startsWith("/WEB-INF/")) || (pathInfo.equals("/WEB-INF")) || (pathInfo.startsWith("/META-INF/")) || (pathInfo.equals("/META-INF")))
      {
        ((HttpServletResponse)response).sendError(404);

        return;
      }

    }

    FacesContext context = this.facesContextFactory.getFacesContext(this.servletConfig.getServletContext(), request, response, this.lifecycle);
    try
    {
      this.lifecycle.execute(context);
      this.lifecycle.render(context);
    } catch (FacesException e) {
      Throwable t = e.getCause();
      if (t == null)
        throw new ServletException(e.getMessage(), e);

      if (t instanceof ServletException)
        throw ((ServletException)t);
      if (t instanceof IOException);
      throw new ServletException(t.getMessage(), t);
    }
    finally
    {
      context.release();
    }
  }
}