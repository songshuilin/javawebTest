package javax.faces.webapp;

import javax.faces.component.UIComponent;
import javax.faces.component.ValueHolder;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

public abstract class ConverterELTag extends TagSupport
{
  public int doStartTag()
    throws JspException
  {
    Converter converter = null;

    UIComponentClassicTagBase tag = UIComponentELTag.getParentUIComponentClassicTagBase(this.pageContext);

    if (tag == null) {
      throw new JspException("Not nested in a UIComponentTag Error for tag with handler class:" + getClass().getName());
    }

    if (!(tag.getCreated())) {
      return 0;
    }

    UIComponent component = tag.getComponentInstance();
    if (component == null)
    {
      throw new JspException("Can't create Component from tag.");
    }
    if (!(component instanceof ValueHolder))
    {
      throw new JspException("Not nested in a tag of proper type. Error for tag with handler class:" + getClass().getName());
    }

    converter = createConverter();

    if (converter == null) {
      throw new JspException("Can't create class of type: javax.faces.convert.Converter, converter is null");
    }

    ValueHolder vh = (ValueHolder)component;
    FacesContext context = FacesContext.getCurrentInstance();

    vh.setConverter(converter);

    Object localValue = vh.getLocalValue();
    if (localValue instanceof String) {
      try {
        localValue = converter.getAsObject(context, (UIComponent)vh, (String)localValue);
        vh.setValue(localValue);
      }
      catch (ConverterException ce)
      {
      }

    }

    return 0;
  }

  protected abstract Converter createConverter()
    throws JspException;
}