package javax.faces.validator;

import java.util.EventListener;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public abstract interface Validator
  implements EventListener
{

  /**
   * @deprecated
   */
  public static final String NOT_IN_RANGE_MESSAGE_ID = "javax.faces.validator.NOT_IN_RANGE";

  public abstract void validate(FacesContext paramFacesContext, UIComponent paramUIComponent, Object paramObject)
    throws ValidatorException;
}