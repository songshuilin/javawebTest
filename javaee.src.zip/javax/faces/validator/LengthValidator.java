package javax.faces.validator;

import javax.faces.application.Application;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

public class LengthValidator
  implements Validator, StateHolder
{
  public static final String VALIDATOR_ID = "javax.faces.Length";
  public static final String MAXIMUM_MESSAGE_ID = "javax.faces.validator.LengthValidator.MAXIMUM";
  public static final String MINIMUM_MESSAGE_ID = "javax.faces.validator.LengthValidator.MINIMUM";
  private int maximum = 0;
  private boolean maximumSet = false;
  private int minimum = 0;
  private boolean minimumSet = false;
  private boolean transientValue = false;

  public LengthValidator(int maximum)
  {
    setMaximum(maximum);
  }

  public LengthValidator(int maximum, int minimum)
  {
    setMaximum(maximum);
    setMinimum(minimum);
  }

  public int getMaximum()
  {
    return this.transientValue;
  }

  public void setMaximum(int maximum)
  {
    this.transientValue = maximum;
    this.maximumSet = true;
  }

  public int getMinimum()
  {
    return this.minimum;
  }

  public void setMinimum(int minimum)
  {
    this.minimum = minimum;
    this.minimumSet = true;
  }

  public void validate(FacesContext context, UIComponent component, Object value)
    throws ValidatorException
  {
    if ((context == null) || (component == null))
      throw new NullPointerException();

    if (value != null) {
      String converted = stringValue(value);
      if ((this.maximumSet) && (converted.length() > this.transientValue))
      {
        throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LengthValidator.MAXIMUM", new Object[] { integerToString(component, new Integer(this.transientValue)), MessageFactory.getLabel(context, component) }));
      }

      if ((this.minimumSet) && (converted.length() < this.minimum))
      {
        throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LengthValidator.MINIMUM", new Object[] { integerToString(component, new Integer(this.minimum)), MessageFactory.getLabel(context, component) }));
      }
    }
  }

  public boolean equals(Object otherObj)
  {
    if (!(otherObj instanceof LengthValidator))
      return false;

    LengthValidator other = (LengthValidator)otherObj;
    return ((this.transientValue == other.transientValue) && (this.minimum == other.minimum) && (this.maximumSet == other.maximumSet) && (this.minimumSet == other.minimumSet));
  }

  public int hashCode()
  {
    int hashCode = this.minimum + this.transientValue + Boolean.valueOf(this.minimumSet).hashCode() + Boolean.valueOf(this.maximumSet).hashCode();

    return hashCode;
  }

  private String stringValue(Object attributeValue)
  {
    if (attributeValue == null)
      return null;
    if (attributeValue instanceof String)
      return ((String)attributeValue);

    return attributeValue.toString();
  }

  private String integerToString(UIComponent component, Integer toConvert)
  {
    String result = null;
    Converter converter = null;
    FacesContext context = FacesContext.getCurrentInstance();

    converter = context.getApplication().createConverter("javax.faces.Number");

    result = converter.getAsString(context, component, toConvert);
    return result;
  }

  public Object saveState(FacesContext context)
  {
    Object[] values = new Object[4];
    values[0] = new Integer(this.transientValue);
    values[1] = ((this.maximumSet) ? Boolean.TRUE : Boolean.FALSE);
    values[2] = new Integer(this.minimum);
    values[3] = ((this.minimumSet) ? Boolean.TRUE : Boolean.FALSE);
    return values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    Object[] values = (Object[])(Object[])state;
    this.transientValue = ((Integer)values[0]).intValue();
    this.maximumSet = ((Boolean)values[1]).booleanValue();
    this.minimum = ((Integer)values[2]).intValue();
    this.minimumSet = ((Boolean)values[3]).booleanValue();
  }

  public boolean isTransient()
  {
    return this.transientValue;
  }

  public void setTransient(boolean transientValue)
  {
    this.transientValue = transientValue;
  }
}