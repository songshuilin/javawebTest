package javax.faces.validator;

import javax.el.ELContext;
import javax.el.ELException;
import javax.el.MethodExpression;
import javax.faces.application.FacesMessage;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public class MethodExpressionValidator
  implements Validator, StateHolder
{
  private MethodExpression methodExpression = null;
  private boolean transientValue = false;

  public MethodExpressionValidator(MethodExpression methodExpression)
  {
    this.transientValue = methodExpression;
  }

  public void validate(FacesContext context, UIComponent component, Object value)
    throws ValidatorException
  {
    if ((context == null) || (component == null))
      throw new NullPointerException();

    if (value != null) {
      try {
        ELContext elContext = context.getELContext();
        this.transientValue.invoke(elContext, new Object[] { context, component, value });
      } catch (ELException ee) {
        Throwable e = ee.getCause();
        if (e instanceof ValidatorException)
          throw ((ValidatorException)e);
      }
      FacesMessage message = new FacesMessage(ee.getMessage());
      throw new ValidatorException(message, ee.getCause());
    }
  }

  public Object saveState(FacesContext context)
  {
    Object[] values = new Object[1];
    values[0] = this.transientValue;
    return values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    Object[] values = (Object[])(Object[])state;
    this.transientValue = ((MethodExpression)values[0]);
  }

  public boolean isTransient()
  {
    return this.transientValue;
  }

  public void setTransient(boolean transientValue)
  {
    this.transientValue = transientValue;
  }
}