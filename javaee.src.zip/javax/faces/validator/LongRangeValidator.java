package javax.faces.validator;

import javax.faces.application.Application;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

public class LongRangeValidator
  implements Validator, StateHolder
{
  public static final String VALIDATOR_ID = "javax.faces.LongRange";
  public static final String MAXIMUM_MESSAGE_ID = "javax.faces.validator.LongRangeValidator.MAXIMUM";
  public static final String MINIMUM_MESSAGE_ID = "javax.faces.validator.LongRangeValidator.MINIMUM";
  public static final String NOT_IN_RANGE_MESSAGE_ID = "javax.faces.validator.LongRangeValidator.NOT_IN_RANGE";
  public static final String TYPE_MESSAGE_ID = "javax.faces.validator.LongRangeValidator.TYPE";
  private long maximum = 0L;
  private boolean maximumSet = false;
  private long minimum = 0L;
  private boolean minimumSet = false;
  private boolean transientValue = false;

  public LongRangeValidator(long maximum)
  {
    setMaximum(maximum);
  }

  public LongRangeValidator(long maximum, long minimum)
  {
    setMaximum(maximum);
    setMinimum(minimum);
  }

  public long getMaximum()
  {
    return this.transientValue;
  }

  public void setMaximum(long maximum)
  {
    this.transientValue = maximum;
    this.maximumSet = true;
  }

  public long getMinimum()
  {
    return this.minimum;
  }

  public void setMinimum(long minimum)
  {
    this.minimum = minimum;
    this.minimumSet = true;
  }

  public void validate(FacesContext context, UIComponent component, Object value)
    throws ValidatorException
  {
    if ((context == null) || (component == null))
      throw new NullPointerException();

    if (value != null)
      try {
        long converted = longValue(value);
        if ((this.maximumSet) && (converted > this.transientValue))
        {
          if (this.minimumSet) {
            throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LongRangeValidator.NOT_IN_RANGE", new Object[] { stringValue(component, new Long(this.minimum)), stringValue(component, new Long(this.transientValue)), MessageFactory.getLabel(context, component) }));
          }

          throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LongRangeValidator.MAXIMUM", new Object[] { stringValue(component, new Long(this.transientValue)), MessageFactory.getLabel(context, component) }));
        }

        if ((this.minimumSet) && (converted < this.minimum))
        {
          if (this.maximumSet) {
            throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LongRangeValidator.NOT_IN_RANGE", new Object[] { stringValue(component, new Long(this.minimum)), stringValue(component, new Long(this.transientValue)), MessageFactory.getLabel(context, component) }));
          }

          throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LongRangeValidator.MINIMUM", new Object[] { stringValue(component, new Long(this.minimum)), MessageFactory.getLabel(context, component) }));
        }

      }
      catch (NumberFormatException e)
      {
        throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LongRangeValidator.TYPE", new Object[] { MessageFactory.getLabel(context, component) }));
      }
  }

  public boolean equals(Object otherObj)
  {
    if (!(otherObj instanceof LongRangeValidator))
      return false;

    LongRangeValidator other = (LongRangeValidator)otherObj;
    return ((this.transientValue == other.transientValue) && (this.minimum == other.minimum) && (this.maximumSet == other.maximumSet) && (this.minimumSet == other.minimumSet));
  }

  public int hashCode()
  {
    int hashCode = new Long(this.minimum).hashCode() + new Long(this.transientValue).hashCode() + Boolean.valueOf(this.minimumSet).hashCode() + Boolean.valueOf(this.maximumSet).hashCode();

    return hashCode;
  }

  private long longValue(Object attributeValue)
    throws NumberFormatException
  {
    if (attributeValue instanceof Number)
      return ((Number)attributeValue).longValue();

    return Long.parseLong(attributeValue.toString());
  }

  private String stringValue(UIComponent component, Long toConvert)
  {
    String result = null;
    Converter converter = null;
    FacesContext context = FacesContext.getCurrentInstance();

    converter = context.getApplication().createConverter("javax.faces.Number");

    result = converter.getAsString(context, component, toConvert);
    return result;
  }

  public Object saveState(FacesContext context)
  {
    Object[] values = new Object[4];
    values[0] = new Long(this.transientValue);
    values[1] = ((this.maximumSet) ? Boolean.TRUE : Boolean.FALSE);
    values[2] = new Long(this.minimum);
    values[3] = ((this.minimumSet) ? Boolean.TRUE : Boolean.FALSE);
    return values;
  }

  public void restoreState(FacesContext context, Object state)
  {
    Object[] values = (Object[])(Object[])state;
    this.transientValue = ((Long)values[0]).longValue();
    this.maximumSet = ((Boolean)values[1]).booleanValue();
    this.minimum = ((Long)values[2]).longValue();
    this.minimumSet = ((Boolean)values[3]).booleanValue();
  }

  public boolean isTransient()
  {
    return this.transientValue;
  }

  public void setTransient(boolean transientValue)
  {
    this.transientValue = transientValue;
  }
}