package javax.faces;

public class FacesException extends RuntimeException
{
  private Throwable cause = null;

  public FacesException(String message)
  {
    super(message);
  }

  public FacesException(Throwable cause)
  {
    super(cause.toString());
    this.cause = cause;
  }

  public FacesException(String message, Throwable cause)
  {
    super(message);
    this.cause = cause;
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}