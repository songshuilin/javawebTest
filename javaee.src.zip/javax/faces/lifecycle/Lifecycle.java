package javax.faces.lifecycle;

import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseListener;

public abstract class Lifecycle
{
  public abstract void addPhaseListener(PhaseListener paramPhaseListener);

  public abstract void execute(FacesContext paramFacesContext)
    throws FacesException;

  public abstract PhaseListener[] getPhaseListeners();

  public abstract void removePhaseListener(PhaseListener paramPhaseListener);

  public abstract void render(FacesContext paramFacesContext)
    throws FacesException;
}