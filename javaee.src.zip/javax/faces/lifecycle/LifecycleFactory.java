package javax.faces.lifecycle;

import java.util.Iterator;

public abstract class LifecycleFactory
{
  public static final String DEFAULT_LIFECYCLE = "DEFAULT";

  public abstract void addLifecycle(String paramString, Lifecycle paramLifecycle);

  public abstract Lifecycle getLifecycle(String paramString);

  public abstract Iterator<String> getLifecycleIds();
}