package javax.ejb;

import java.io.Serializable;
import java.rmi.RemoteException;

public abstract interface HomeHandle
  implements Serializable
{
  public abstract EJBHome getEJBHome()
    throws RemoteException;
}