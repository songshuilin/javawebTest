package javax.ejb;

public class FinderException extends Exception
{
  public FinderException(String message)
  {
    super(message);
  }
}