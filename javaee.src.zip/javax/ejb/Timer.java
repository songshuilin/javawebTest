package javax.ejb;

import java.io.Serializable;
import java.util.Date;

public abstract interface Timer
{
  public abstract void cancel()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;

  public abstract long getTimeRemaining()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;

  public abstract Date getNextTimeout()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;

  public abstract Serializable getInfo()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;

  public abstract TimerHandle getHandle()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}