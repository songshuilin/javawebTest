package javax.ejb;

import javax.xml.rpc.handler.MessageContext;

public abstract interface SessionContext
  implements EJBContext
{
  public abstract EJBLocalObject getEJBLocalObject()
    throws IllegalStateException;

  public abstract EJBObject getEJBObject()
    throws IllegalStateException;

  public abstract MessageContext getMessageContext()
    throws IllegalStateException;

  public abstract <T> T getBusinessObject(Class<T> paramClass)
    throws IllegalStateException;

  public abstract Class getInvokedBusinessInterface()
    throws IllegalStateException;
}