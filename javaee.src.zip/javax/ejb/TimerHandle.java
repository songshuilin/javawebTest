package javax.ejb;

import java.io.Serializable;

public abstract interface TimerHandle
  implements Serializable
{
  public abstract Timer getTimer()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}