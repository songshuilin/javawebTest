package javax.ejb;

public class EJBAccessException extends EJBException
{
  public EJBAccessException(String message)
  {
    super(message);
  }
}