package javax.ejb;

public class CreateException extends Exception
{
  public CreateException(String message)
  {
    super(message);
  }
}