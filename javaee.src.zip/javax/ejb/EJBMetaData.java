package javax.ejb;

public abstract interface EJBMetaData
{
  public abstract EJBHome getEJBHome();

  public abstract Class getHomeInterfaceClass();

  public abstract Class getRemoteInterfaceClass();

  public abstract Class getPrimaryKeyClass();

  public abstract boolean isSession();

  public abstract boolean isStatelessSession();
}