package javax.ejb;

import java.rmi.RemoteException;

public abstract interface SessionBean
  implements EnterpriseBean
{
  public abstract void setSessionContext(SessionContext paramSessionContext)
    throws EJBException, RemoteException;

  public abstract void ejbRemove()
    throws EJBException, RemoteException;

  public abstract void ejbActivate()
    throws EJBException, RemoteException;

  public abstract void ejbPassivate()
    throws EJBException, RemoteException;
}