package javax.ejb;

import java.io.Serializable;

public abstract interface EnterpriseBean
  implements Serializable
{
}