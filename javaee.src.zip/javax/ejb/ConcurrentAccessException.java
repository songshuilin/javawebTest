package javax.ejb;

public class ConcurrentAccessException extends EJBException
{
  public ConcurrentAccessException(String message)
  {
    super(message);
  }

  public ConcurrentAccessException(String message, Exception ex)
  {
    super(message, ex);
  }
}