package javax.ejb;

public enum TransactionAttributeType
{
  MANDATORY, REQUIRED, REQUIRES_NEW, SUPPORTS, NOT_SUPPORTED, NEVER;

  public static final TransactionAttributeType[] values()
  {
    return ((TransactionAttributeType[])$VALUES.clone());
  }
}