package javax.ejb;

public class ObjectNotFoundException extends FinderException
{
  public ObjectNotFoundException(String message)
  {
    super(message);
  }
}