package javax.ejb;

public abstract interface MessageDrivenContext
  implements EJBContext
{
}