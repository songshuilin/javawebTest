package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface EJBObject
  implements Remote
{
  public abstract EJBHome getEJBHome()
    throws RemoteException;

  public abstract Object getPrimaryKey()
    throws RemoteException;

  public abstract void remove()
    throws RemoteException, RemoveException;

  public abstract Handle getHandle()
    throws RemoteException;

  public abstract boolean isIdentical(EJBObject paramEJBObject)
    throws RemoteException;
}