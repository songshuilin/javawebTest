package javax.ejb;

import java.rmi.RemoteException;

public abstract interface EntityBean
  implements EnterpriseBean
{
  public abstract void setEntityContext(EntityContext paramEntityContext)
    throws EJBException, RemoteException;

  public abstract void unsetEntityContext()
    throws EJBException, RemoteException;

  public abstract void ejbRemove()
    throws RemoveException, EJBException, RemoteException;

  public abstract void ejbActivate()
    throws EJBException, RemoteException;

  public abstract void ejbPassivate()
    throws EJBException, RemoteException;

  public abstract void ejbLoad()
    throws EJBException, RemoteException;

  public abstract void ejbStore()
    throws EJBException, RemoteException;
}