package javax.ejb;

public class RemoveException extends Exception
{
  public RemoveException(String message)
  {
    super(message);
  }
}