package javax.ejb;

public abstract interface EJBLocalHome
{
  public abstract void remove(Object paramObject)
    throws RemoveException, EJBException;
}