package javax.ejb;

public abstract interface EJBLocalObject
{
  public abstract EJBLocalHome getEJBLocalHome()
    throws EJBException;

  public abstract Object getPrimaryKey()
    throws EJBException;

  public abstract void remove()
    throws RemoveException, EJBException;

  public abstract boolean isIdentical(EJBLocalObject paramEJBLocalObject)
    throws EJBException;
}