package javax.enterprise.deploy.model;

import javax.enterprise.deploy.shared.ModuleType;

public abstract interface J2eeApplicationObject
  implements DeployableObject
{
  public abstract DeployableObject getDeployableObject(String paramString);

  public abstract DeployableObject[] getDeployableObjects(ModuleType paramModuleType);

  public abstract DeployableObject[] getDeployableObjects();

  public abstract String[] getModuleUris(ModuleType paramModuleType);

  public abstract String[] getModuleUris();

  public abstract DDBean[] getChildBean(ModuleType paramModuleType, String paramString);

  public abstract String[] getText(ModuleType paramModuleType, String paramString);

  public abstract void addXpathListener(ModuleType paramModuleType, String paramString, XpathListener paramXpathListener);

  public abstract void removeXpathListener(ModuleType paramModuleType, String paramString, XpathListener paramXpathListener);
}