package javax.enterprise.deploy.model;

public abstract interface XpathListener
{
  public abstract void fireXpathEvent(XpathEvent paramXpathEvent);
}