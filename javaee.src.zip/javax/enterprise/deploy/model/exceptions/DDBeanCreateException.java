package javax.enterprise.deploy.model.exceptions;

public class DDBeanCreateException extends Exception
{
  public DDBeanCreateException(String msg)
  {
    super(msg);
  }
}