package javax.enterprise.deploy.spi;

public abstract interface Target
{
  public abstract String getName();

  public abstract String getDescription();
}