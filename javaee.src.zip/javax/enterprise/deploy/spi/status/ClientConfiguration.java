package javax.enterprise.deploy.spi.status;

import java.io.Serializable;
import javax.enterprise.deploy.spi.exceptions.ClientExecuteException;

public abstract interface ClientConfiguration
  implements Serializable
{
  public abstract void execute()
    throws ClientExecuteException;
}