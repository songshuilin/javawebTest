package javax.enterprise.deploy.spi.status;

import java.util.EventListener;

public abstract interface ProgressListener
  implements EventListener
{
  public abstract void handleProgressEvent(ProgressEvent paramProgressEvent);
}