package javax.enterprise.deploy.spi.status;

import javax.enterprise.deploy.shared.ActionType;
import javax.enterprise.deploy.shared.CommandType;
import javax.enterprise.deploy.shared.StateType;

public abstract interface DeploymentStatus
{
  public abstract StateType getState();

  public abstract CommandType getCommand();

  public abstract ActionType getAction();

  public abstract String getMessage();

  public abstract boolean isCompleted();

  public abstract boolean isFailed();

  public abstract boolean isRunning();
}