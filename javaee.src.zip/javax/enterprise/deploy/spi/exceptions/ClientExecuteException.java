package javax.enterprise.deploy.spi.exceptions;

public class ClientExecuteException extends Exception
{
  public ClientExecuteException(String msg)
  {
    super(msg);
  }
}