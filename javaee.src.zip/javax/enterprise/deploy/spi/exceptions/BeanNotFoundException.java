package javax.enterprise.deploy.spi.exceptions;

public class BeanNotFoundException extends Exception
{
  public BeanNotFoundException(String s)
  {
    super(s);
  }
}