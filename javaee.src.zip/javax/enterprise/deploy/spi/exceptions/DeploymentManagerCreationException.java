package javax.enterprise.deploy.spi.exceptions;

public class DeploymentManagerCreationException extends Exception
{
  public DeploymentManagerCreationException(String s)
  {
    super(s);
  }
}