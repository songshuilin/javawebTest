package javax.enterprise.deploy.spi.exceptions;

public class ConfigurationException extends Exception
{
  public ConfigurationException(String msg)
  {
    super(msg);
  }
}