package javax.enterprise.deploy.spi.exceptions;

public class InvalidModuleException extends Exception
{
  public InvalidModuleException(String s)
  {
    super(s);
  }
}