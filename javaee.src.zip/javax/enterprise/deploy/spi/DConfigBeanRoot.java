package javax.enterprise.deploy.spi;

import javax.enterprise.deploy.model.DDBeanRoot;

public abstract interface DConfigBeanRoot
  implements DConfigBean
{
  public abstract DConfigBean getDConfigBean(DDBeanRoot paramDDBeanRoot);
}