package javax.enterprise.deploy.spi;

public abstract interface TargetModuleID
{
  public abstract Target getTarget();

  public abstract String getModuleID();

  public abstract String getWebURL();

  public abstract String toString();

  public abstract TargetModuleID getParentTargetModuleID();

  public abstract TargetModuleID[] getChildTargetModuleID();
}