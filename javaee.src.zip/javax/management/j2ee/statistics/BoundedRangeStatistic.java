package javax.management.j2ee.statistics;

public abstract interface BoundedRangeStatistic
  implements BoundaryStatistic, RangeStatistic
{
}