package javax.management.j2ee.statistics;

public abstract interface JCAConnectionPoolStats
  implements JCAConnectionStats
{
  public abstract CountStatistic getCloseCount();

  public abstract CountStatistic getCreateCount();

  public abstract BoundedRangeStatistic getFreePoolSize();

  public abstract BoundedRangeStatistic getPoolSize();

  public abstract RangeStatistic getWaitingThreadCount();
}