package javax.management.j2ee.statistics;

public abstract interface BoundaryStatistic
  implements Statistic
{
  public abstract long getUpperBound();

  public abstract long getLowerBound();
}