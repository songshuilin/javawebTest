package javax.management.j2ee.statistics;

public abstract interface EntityBeanStats
  implements EJBStats
{
  public abstract RangeStatistic getReadyCount();

  public abstract RangeStatistic getPooledCount();
}