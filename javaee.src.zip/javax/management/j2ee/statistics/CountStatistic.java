package javax.management.j2ee.statistics;

public abstract interface CountStatistic
  implements Statistic
{
  public abstract long getCount();
}