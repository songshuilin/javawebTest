package javax.management.j2ee.statistics;

public abstract interface JCAStats
  implements Stats
{
  public abstract JCAConnectionStats[] getConnections();

  public abstract JCAConnectionPoolStats[] getConnectionPools();
}