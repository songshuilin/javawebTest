package javax.management.j2ee.statistics;

public abstract interface EJBStats
  implements Stats
{
  public abstract CountStatistic getCreateCount();

  public abstract CountStatistic getRemoveCount();
}