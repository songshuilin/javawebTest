package javax.management.j2ee;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface ManagementHome
  implements EJBHome
{
  public abstract Management create()
    throws CreateException, RemoteException;
}