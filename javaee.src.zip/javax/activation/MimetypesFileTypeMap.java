package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MimeTypeFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

public class MimetypesFileTypeMap extends FileTypeMap
{
  private static MimeTypeFile defDB = null;
  private MimeTypeFile[] DB;
  private static final int PROG = 0;
  private static String defaultType = "application/octet-stream";

  public MimetypesFileTypeMap()
  {
    Vector dbv = new Vector(5);
    MimeTypeFile mf = null;
    dbv.addElement(null);

    LogSupport.log("MimetypesFileTypeMap: load HOME");
    try {
      String user_home = System.getProperty("user.home");

      if (user_home != null) {
        String path = user_home + File.separator + ".mime.types";
        mf = loadFile(path);
        if (mf != null)
          dbv.addElement(mf);
      }
    } catch (SecurityException ex) {
    }
    LogSupport.log("MimetypesFileTypeMap: load SYS");
    try
    {
      String system_mimetypes = System.getProperty("java.home") + File.separator + "lib" + File.separator + "mime.types";

      mf = loadFile(system_mimetypes);
      if (mf != null)
        dbv.addElement(mf);
    } catch (SecurityException system_mimetypes) {
    }
    LogSupport.log("MimetypesFileTypeMap: load JAR");

    loadAllResources(dbv, "META-INF/mime.types");

    LogSupport.log("MimetypesFileTypeMap: load DEF");
    monitorenter;
    try {
      if (defDB == null)
        defDB = loadResource("/META-INF/mimetypes.default"); 
    } finally {
      monitorexit;
    }
    if (defDB != null)
      dbv.addElement(defDB);

    this.DB = new MimeTypeFile[dbv.size()];
    dbv.copyInto(this.DB); } 
  // ERROR //
  private MimeTypeFile loadResource(String name) { // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: invokevirtual 255	java/lang/Object:getClass	()Ljava/lang/Class;
    //   6: aload_1
    //   7: invokestatic 278	javax/activation/SecuritySupport:getResourceAsStream	(Ljava/lang/Class;Ljava/lang/String;)Ljava/io/InputStream;
    //   10: astore_2
    //   11: aload_2
    //   12: ifnull +59 -> 71
    //   15: new 143	com/sun/activation/registries/MimeTypeFile
    //   18: dup
    //   19: aload_2
    //   20: invokespecial 245	com/sun/activation/registries/MimeTypeFile:<init>	(Ljava/io/InputStream;)V
    //   23: astore_3
    //   24: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   27: ifeq +25 -> 52
    //   30: new 154	java/lang/StringBuffer
    //   33: dup
    //   34: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   37: ldc 16
    //   39: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   42: aload_1
    //   43: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   46: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   49: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   52: aload_3
    //   53: astore 4
    //   55: aload_2
    //   56: ifnull +7 -> 63
    //   59: aload_2
    //   60: invokevirtual 250	java/io/InputStream:close	()V
    //   63: goto +5 -> 68
    //   66: astore 5
    //   68: aload 4
    //   70: areturn
    //   71: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   74: ifeq +25 -> 99
    //   77: new 154	java/lang/StringBuffer
    //   80: dup
    //   81: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   84: ldc 14
    //   86: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   89: aload_1
    //   90: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   93: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   96: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   99: aload_2
    //   100: ifnull +7 -> 107
    //   103: aload_2
    //   104: invokevirtual 250	java/io/InputStream:close	()V
    //   107: goto +115 -> 222
    //   110: astore_3
    //   111: goto +111 -> 222
    //   114: astore_3
    //   115: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   118: ifeq +26 -> 144
    //   121: new 154	java/lang/StringBuffer
    //   124: dup
    //   125: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   128: ldc 8
    //   130: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   133: aload_1
    //   134: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   137: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   140: aload_3
    //   141: invokestatic 243	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   144: aload_2
    //   145: ifnull +7 -> 152
    //   148: aload_2
    //   149: invokevirtual 250	java/io/InputStream:close	()V
    //   152: goto +70 -> 222
    //   155: astore_3
    //   156: goto +66 -> 222
    //   159: astore_3
    //   160: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   163: ifeq +26 -> 189
    //   166: new 154	java/lang/StringBuffer
    //   169: dup
    //   170: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   173: ldc 8
    //   175: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   178: aload_1
    //   179: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   182: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   185: aload_3
    //   186: invokestatic 243	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   189: aload_2
    //   190: ifnull +7 -> 197
    //   193: aload_2
    //   194: invokevirtual 250	java/io/InputStream:close	()V
    //   197: goto +25 -> 222
    //   200: astore_3
    //   201: goto +21 -> 222
    //   204: astore 6
    //   206: aload_2
    //   207: ifnull +7 -> 214
    //   210: aload_2
    //   211: invokevirtual 250	java/io/InputStream:close	()V
    //   214: goto +5 -> 219
    //   217: astore 7
    //   219: aload 6
    //   221: athrow
    //   222: aconst_null
    //   223: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   55	63	66	java/io/IOException
    //   99	107	110	java/io/IOException
    //   2	55	114	java/io/IOException
    //   71	99	114	java/io/IOException
    //   144	152	155	java/io/IOException
    //   2	55	159	java/lang/SecurityException
    //   71	99	159	java/lang/SecurityException
    //   189	197	200	java/io/IOException
    //   2	55	204	finally
    //   71	99	204	finally
    //   114	144	204	finally
    //   159	189	204	finally
    //   204	206	204	finally
    //   206	214	217	java/io/IOException } 
  // ERROR //
  private void loadAllResources(Vector v, String name) { // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aconst_null
    //   3: astore 5
    //   5: invokestatic 275	javax/activation/SecuritySupport:getContextClassLoader	()Ljava/lang/ClassLoader;
    //   8: astore 5
    //   10: aload 5
    //   12: ifnonnull +12 -> 24
    //   15: aload_0
    //   16: invokevirtual 255	java/lang/Object:getClass	()Ljava/lang/Class;
    //   19: invokevirtual 251	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   22: astore 5
    //   24: aload 5
    //   26: ifnull +14 -> 40
    //   29: aload 5
    //   31: aload_2
    //   32: invokestatic 279	javax/activation/SecuritySupport:getResources	(Ljava/lang/ClassLoader;Ljava/lang/String;)[Ljava/net/URL;
    //   35: astore 4
    //   37: goto +9 -> 46
    //   40: aload_2
    //   41: invokestatic 277	javax/activation/SecuritySupport:getSystemResources	(Ljava/lang/String;)[Ljava/net/URL;
    //   44: astore 4
    //   46: aload 4
    //   48: ifnull +298 -> 346
    //   51: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   54: ifeq +8 -> 62
    //   57: ldc 9
    //   59: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   62: iconst_0
    //   63: istore 6
    //   65: iload 6
    //   67: aload 4
    //   69: arraylength
    //   70: if_icmpge +276 -> 346
    //   73: aload 4
    //   75: iload 6
    //   77: aaload
    //   78: astore 7
    //   80: aconst_null
    //   81: astore 8
    //   83: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   86: ifeq +26 -> 112
    //   89: new 154	java/lang/StringBuffer
    //   92: dup
    //   93: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   96: ldc 7
    //   98: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   101: aload 7
    //   103: invokevirtual 261	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   106: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   109: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   112: aload 7
    //   114: invokestatic 276	javax/activation/SecuritySupport:openStream	(Ljava/net/URL;)Ljava/io/InputStream;
    //   117: astore 8
    //   119: aload 8
    //   121: ifnull +50 -> 171
    //   124: aload_1
    //   125: new 143	com/sun/activation/registries/MimeTypeFile
    //   128: dup
    //   129: aload 8
    //   131: invokespecial 245	com/sun/activation/registries/MimeTypeFile:<init>	(Ljava/io/InputStream;)V
    //   134: invokevirtual 266	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   137: iconst_1
    //   138: istore_3
    //   139: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   142: ifeq +58 -> 200
    //   145: new 154	java/lang/StringBuffer
    //   148: dup
    //   149: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   152: ldc 17
    //   154: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   157: aload 7
    //   159: invokevirtual 261	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   162: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   165: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   168: goto +32 -> 200
    //   171: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   174: ifeq +26 -> 200
    //   177: new 154	java/lang/StringBuffer
    //   180: dup
    //   181: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   184: ldc 15
    //   186: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   189: aload 7
    //   191: invokevirtual 261	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   194: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   197: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   200: aload 8
    //   202: ifnull +8 -> 210
    //   205: aload 8
    //   207: invokevirtual 250	java/io/InputStream:close	()V
    //   210: goto +130 -> 340
    //   213: astore 9
    //   215: goto +125 -> 340
    //   218: astore 9
    //   220: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   223: ifeq +28 -> 251
    //   226: new 154	java/lang/StringBuffer
    //   229: dup
    //   230: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   233: ldc 8
    //   235: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   238: aload 7
    //   240: invokevirtual 261	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   243: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   246: aload 9
    //   248: invokestatic 243	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   251: aload 8
    //   253: ifnull +8 -> 261
    //   256: aload 8
    //   258: invokevirtual 250	java/io/InputStream:close	()V
    //   261: goto +79 -> 340
    //   264: astore 9
    //   266: goto +74 -> 340
    //   269: astore 9
    //   271: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   274: ifeq +28 -> 302
    //   277: new 154	java/lang/StringBuffer
    //   280: dup
    //   281: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   284: ldc 8
    //   286: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   289: aload 7
    //   291: invokevirtual 261	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   294: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   297: aload 9
    //   299: invokestatic 243	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   302: aload 8
    //   304: ifnull +8 -> 312
    //   307: aload 8
    //   309: invokevirtual 250	java/io/InputStream:close	()V
    //   312: goto +28 -> 340
    //   315: astore 9
    //   317: goto +23 -> 340
    //   320: astore 10
    //   322: aload 8
    //   324: ifnull +8 -> 332
    //   327: aload 8
    //   329: invokevirtual 250	java/io/InputStream:close	()V
    //   332: goto +5 -> 337
    //   335: astore 11
    //   337: aload 10
    //   339: athrow
    //   340: iinc 6 1
    //   343: goto -278 -> 65
    //   346: goto +35 -> 381
    //   349: astore 4
    //   351: invokestatic 241	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   354: ifeq +27 -> 381
    //   357: new 154	java/lang/StringBuffer
    //   360: dup
    //   361: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   364: ldc 8
    //   366: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   369: aload_2
    //   370: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   373: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   376: aload 4
    //   378: invokestatic 243	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   381: iload_3
    //   382: ifne +44 -> 426
    //   385: ldc 6
    //   387: invokestatic 242	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   390: aload_0
    //   391: new 154	java/lang/StringBuffer
    //   394: dup
    //   395: invokespecial 259	java/lang/StringBuffer:<init>	()V
    //   398: ldc 3
    //   400: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   403: aload_2
    //   404: invokevirtual 262	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   407: invokevirtual 260	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   410: invokespecial 271	javax/activation/MimetypesFileTypeMap:loadResource	(Ljava/lang/String;)Lcom/sun/activation/registries/MimeTypeFile;
    //   413: astore 4
    //   415: aload 4
    //   417: ifnull +9 -> 426
    //   420: aload_1
    //   421: aload 4
    //   423: invokevirtual 266	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   426: return
    //
    // Exception table:
    //   from	to	target	type
    //   200	210	213	java/io/IOException
    //   112	200	218	java/io/IOException
    //   251	261	264	java/io/IOException
    //   112	200	269	java/lang/SecurityException
    //   302	312	315	java/io/IOException
    //   112	200	320	finally
    //   218	251	320	finally
    //   269	302	320	finally
    //   320	322	320	finally
    //   322	332	335	java/io/IOException
    //   2	346	349	java/lang/Exception } 
  private MimeTypeFile loadFile(String name) { MimeTypeFile mtf = null;
    try
    {
      mtf = new MimeTypeFile(name);
    }
    catch (IOException e) {
    }
    return mtf;
  }

  public MimetypesFileTypeMap(String mimeTypeFileName)
    throws IOException
  {
    this.DB[0] = new MimeTypeFile(mimeTypeFileName);
  }

  public MimetypesFileTypeMap(InputStream is)
  {
    try
    {
      this.DB[0] = new MimeTypeFile(is);
    }
    catch (IOException ex)
    {
    }
  }

  public synchronized void addMimeTypes(String mime_types)
  {
    if (this.DB[0] == null)
      this.DB[0] = new MimeTypeFile();

    this.DB[0].appendToRegistry(mime_types);
  }

  public String getContentType(File f)
  {
    return getContentType(f.getName());
  }

  public synchronized String getContentType(String filename)
  {
    int dot_pos = filename.lastIndexOf(".");

    if (dot_pos < 0)
      return defaultType;

    String file_ext = filename.substring(dot_pos + 1);
    if (file_ext.length() == 0)
      return defaultType;

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label81:
      String result = this.DB[i].getMIMETypeString(file_ext);
      label81: if (result != null)
        return result;
    }
    return defaultType;
  }
}