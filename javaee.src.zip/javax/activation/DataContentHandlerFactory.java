package javax.activation;

public abstract interface DataContentHandlerFactory
{
  public abstract DataContentHandler createDataContentHandler(String paramString);
}