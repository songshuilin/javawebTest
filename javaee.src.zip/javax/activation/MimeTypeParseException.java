package javax.activation;

public class MimeTypeParseException extends Exception
{
  public MimeTypeParseException(String s)
  {
    super(s);
  }
}