package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MailcapFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MailcapCommandMap extends CommandMap
{
  private static MailcapFile defDB = null;
  private MailcapFile[] DB;
  private static final int PROG = 0;

  public MailcapCommandMap()
  {
    List dbv = new ArrayList(5);
    MailcapFile mf = null;
    dbv.add(null);

    LogSupport.log("MailcapCommandMap: load HOME");
    try {
      String user_home = System.getProperty("user.home");

      if (user_home != null) {
        String path = user_home + File.separator + ".mailcap";
        mf = loadFile(path);
        if (mf != null)
          dbv.add(mf);
      }
    } catch (SecurityException ex) {
    }
    LogSupport.log("MailcapCommandMap: load SYS");
    try
    {
      String system_mailcap = System.getProperty("java.home") + File.separator + "lib" + File.separator + "mailcap";

      mf = loadFile(system_mailcap);
      if (mf != null)
        dbv.add(mf);
    } catch (SecurityException system_mailcap) {
    }
    LogSupport.log("MailcapCommandMap: load JAR");

    loadAllResources(dbv, "META-INF/mailcap");

    LogSupport.log("MailcapCommandMap: load DEF");
    monitorenter;
    try {
      if (defDB == null)
        defDB = loadResource("/META-INF/mailcap.default"); 
    } finally {
      monitorexit;
    }
    if (defDB != null)
      dbv.add(defDB);

    this.DB = new MailcapFile[dbv.size()];
    this.DB = ((MailcapFile[])(MailcapFile[])dbv.toArray(this.DB)); } 
  // ERROR //
  private MailcapFile loadResource(String name) { // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: invokevirtual 362	java/lang/Object:getClass	()Ljava/lang/Class;
    //   6: aload_1
    //   7: invokestatic 388	javax/activation/SecuritySupport:getResourceAsStream	(Ljava/lang/Class;Ljava/lang/String;)Ljava/io/InputStream;
    //   10: astore_2
    //   11: aload_2
    //   12: ifnull +59 -> 71
    //   15: new 208	com/sun/activation/registries/MailcapFile
    //   18: dup
    //   19: aload_2
    //   20: invokespecial 348	com/sun/activation/registries/MailcapFile:<init>	(Ljava/io/InputStream;)V
    //   23: astore_3
    //   24: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   27: ifeq +25 -> 52
    //   30: new 222	java/lang/StringBuffer
    //   33: dup
    //   34: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   37: ldc 25
    //   39: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   42: aload_1
    //   43: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   46: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   49: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   52: aload_3
    //   53: astore 4
    //   55: aload_2
    //   56: ifnull +7 -> 63
    //   59: aload_2
    //   60: invokevirtual 355	java/io/InputStream:close	()V
    //   63: goto +5 -> 68
    //   66: astore 5
    //   68: aload 4
    //   70: areturn
    //   71: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   74: ifeq +25 -> 99
    //   77: new 222	java/lang/StringBuffer
    //   80: dup
    //   81: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   84: ldc 23
    //   86: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   89: aload_1
    //   90: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   93: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   96: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   99: aload_2
    //   100: ifnull +7 -> 107
    //   103: aload_2
    //   104: invokevirtual 355	java/io/InputStream:close	()V
    //   107: goto +115 -> 222
    //   110: astore_3
    //   111: goto +111 -> 222
    //   114: astore_3
    //   115: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   118: ifeq +26 -> 144
    //   121: new 222	java/lang/StringBuffer
    //   124: dup
    //   125: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   128: ldc 13
    //   130: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   133: aload_1
    //   134: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   137: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   140: aload_3
    //   141: invokestatic 346	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   144: aload_2
    //   145: ifnull +7 -> 152
    //   148: aload_2
    //   149: invokevirtual 355	java/io/InputStream:close	()V
    //   152: goto +70 -> 222
    //   155: astore_3
    //   156: goto +66 -> 222
    //   159: astore_3
    //   160: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   163: ifeq +26 -> 189
    //   166: new 222	java/lang/StringBuffer
    //   169: dup
    //   170: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   173: ldc 13
    //   175: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   178: aload_1
    //   179: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   182: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   185: aload_3
    //   186: invokestatic 346	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   189: aload_2
    //   190: ifnull +7 -> 197
    //   193: aload_2
    //   194: invokevirtual 355	java/io/InputStream:close	()V
    //   197: goto +25 -> 222
    //   200: astore_3
    //   201: goto +21 -> 222
    //   204: astore 6
    //   206: aload_2
    //   207: ifnull +7 -> 214
    //   210: aload_2
    //   211: invokevirtual 355	java/io/InputStream:close	()V
    //   214: goto +5 -> 219
    //   217: astore 7
    //   219: aload 6
    //   221: athrow
    //   222: aconst_null
    //   223: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   55	63	66	java/io/IOException
    //   99	107	110	java/io/IOException
    //   2	55	114	java/io/IOException
    //   71	99	114	java/io/IOException
    //   144	152	155	java/io/IOException
    //   2	55	159	java/lang/SecurityException
    //   71	99	159	java/lang/SecurityException
    //   189	197	200	java/io/IOException
    //   2	55	204	finally
    //   71	99	204	finally
    //   114	144	204	finally
    //   159	189	204	finally
    //   204	206	204	finally
    //   206	214	217	java/io/IOException } 
  // ERROR //
  private void loadAllResources(List v, String name) { // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aconst_null
    //   3: astore 5
    //   5: invokestatic 385	javax/activation/SecuritySupport:getContextClassLoader	()Ljava/lang/ClassLoader;
    //   8: astore 5
    //   10: aload 5
    //   12: ifnonnull +12 -> 24
    //   15: aload_0
    //   16: invokevirtual 362	java/lang/Object:getClass	()Ljava/lang/Class;
    //   19: invokevirtual 356	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   22: astore 5
    //   24: aload 5
    //   26: ifnull +14 -> 40
    //   29: aload 5
    //   31: aload_2
    //   32: invokestatic 389	javax/activation/SecuritySupport:getResources	(Ljava/lang/ClassLoader;Ljava/lang/String;)[Ljava/net/URL;
    //   35: astore 4
    //   37: goto +9 -> 46
    //   40: aload_2
    //   41: invokestatic 387	javax/activation/SecuritySupport:getSystemResources	(Ljava/lang/String;)[Ljava/net/URL;
    //   44: astore 4
    //   46: aload 4
    //   48: ifnull +301 -> 349
    //   51: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   54: ifeq +8 -> 62
    //   57: ldc 15
    //   59: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   62: iconst_0
    //   63: istore 6
    //   65: iload 6
    //   67: aload 4
    //   69: arraylength
    //   70: if_icmpge +279 -> 349
    //   73: aload 4
    //   75: iload 6
    //   77: aaload
    //   78: astore 7
    //   80: aconst_null
    //   81: astore 8
    //   83: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   86: ifeq +26 -> 112
    //   89: new 222	java/lang/StringBuffer
    //   92: dup
    //   93: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   96: ldc 11
    //   98: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   101: aload 7
    //   103: invokevirtual 368	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   106: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   109: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   112: aload 7
    //   114: invokestatic 386	javax/activation/SecuritySupport:openStream	(Ljava/net/URL;)Ljava/io/InputStream;
    //   117: astore 8
    //   119: aload 8
    //   121: ifnull +53 -> 174
    //   124: aload_1
    //   125: new 208	com/sun/activation/registries/MailcapFile
    //   128: dup
    //   129: aload 8
    //   131: invokespecial 348	com/sun/activation/registries/MailcapFile:<init>	(Ljava/io/InputStream;)V
    //   134: invokeinterface 394 2 0
    //   139: pop
    //   140: iconst_1
    //   141: istore_3
    //   142: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   145: ifeq +58 -> 203
    //   148: new 222	java/lang/StringBuffer
    //   151: dup
    //   152: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   155: ldc 24
    //   157: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   160: aload 7
    //   162: invokevirtual 368	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   165: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   168: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   171: goto +32 -> 203
    //   174: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   177: ifeq +26 -> 203
    //   180: new 222	java/lang/StringBuffer
    //   183: dup
    //   184: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   187: ldc 22
    //   189: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   192: aload 7
    //   194: invokevirtual 368	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   197: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   200: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   203: aload 8
    //   205: ifnull +8 -> 213
    //   208: aload 8
    //   210: invokevirtual 355	java/io/InputStream:close	()V
    //   213: goto +130 -> 343
    //   216: astore 9
    //   218: goto +125 -> 343
    //   221: astore 9
    //   223: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   226: ifeq +28 -> 254
    //   229: new 222	java/lang/StringBuffer
    //   232: dup
    //   233: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   236: ldc 13
    //   238: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   241: aload 7
    //   243: invokevirtual 368	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   246: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   249: aload 9
    //   251: invokestatic 346	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   254: aload 8
    //   256: ifnull +8 -> 264
    //   259: aload 8
    //   261: invokevirtual 355	java/io/InputStream:close	()V
    //   264: goto +79 -> 343
    //   267: astore 9
    //   269: goto +74 -> 343
    //   272: astore 9
    //   274: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   277: ifeq +28 -> 305
    //   280: new 222	java/lang/StringBuffer
    //   283: dup
    //   284: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   287: ldc 13
    //   289: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   292: aload 7
    //   294: invokevirtual 368	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   297: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   300: aload 9
    //   302: invokestatic 346	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   305: aload 8
    //   307: ifnull +8 -> 315
    //   310: aload 8
    //   312: invokevirtual 355	java/io/InputStream:close	()V
    //   315: goto +28 -> 343
    //   318: astore 9
    //   320: goto +23 -> 343
    //   323: astore 10
    //   325: aload 8
    //   327: ifnull +8 -> 335
    //   330: aload 8
    //   332: invokevirtual 355	java/io/InputStream:close	()V
    //   335: goto +5 -> 340
    //   338: astore 11
    //   340: aload 10
    //   342: athrow
    //   343: iinc 6 1
    //   346: goto -281 -> 65
    //   349: goto +35 -> 384
    //   352: astore 4
    //   354: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   357: ifeq +27 -> 384
    //   360: new 222	java/lang/StringBuffer
    //   363: dup
    //   364: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   367: ldc 13
    //   369: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   372: aload_2
    //   373: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   376: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   379: aload 4
    //   381: invokestatic 346	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   384: iload_3
    //   385: ifne +53 -> 438
    //   388: invokestatic 344	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   391: ifeq +8 -> 399
    //   394: ldc 10
    //   396: invokestatic 345	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   399: aload_0
    //   400: new 222	java/lang/StringBuffer
    //   403: dup
    //   404: invokespecial 365	java/lang/StringBuffer:<init>	()V
    //   407: ldc 6
    //   409: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   412: aload_2
    //   413: invokevirtual 369	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   416: invokevirtual 366	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   419: invokespecial 378	javax/activation/MailcapCommandMap:loadResource	(Ljava/lang/String;)Lcom/sun/activation/registries/MailcapFile;
    //   422: astore 4
    //   424: aload 4
    //   426: ifnull +12 -> 438
    //   429: aload_1
    //   430: aload 4
    //   432: invokeinterface 394 2 0
    //   437: pop
    //   438: return
    //
    // Exception table:
    //   from	to	target	type
    //   203	213	216	java/io/IOException
    //   112	203	221	java/io/IOException
    //   254	264	267	java/io/IOException
    //   112	203	272	java/lang/SecurityException
    //   305	315	318	java/io/IOException
    //   112	203	323	finally
    //   221	254	323	finally
    //   272	305	323	finally
    //   323	325	323	finally
    //   325	335	338	java/io/IOException
    //   2	349	352	java/lang/Exception } 
  private MailcapFile loadFile(String name) { MailcapFile mtf = null;
    try
    {
      mtf = new MailcapFile(name);
    }
    catch (IOException e) {
    }
    return mtf;
  }

  public MailcapCommandMap(String fileName)
    throws IOException
  {
    if (LogSupport.isLoggable())
      LogSupport.log("MailcapCommandMap: load PROG from " + fileName);
    if (this.DB[0] == null)
      this.DB[0] = new MailcapFile(fileName);
  }

  public MailcapCommandMap(InputStream is)
  {
    LogSupport.log("MailcapCommandMap: load PROG");
    if (this.DB[0] == null)
      try {
        this.DB[0] = new MailcapFile(is);
      }
      catch (IOException ex)
      {
      }
  }

  public synchronized CommandInfo[] getPreferredCommands(String mimeType)
  {
    Map cmdMap;
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label64:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      label64: if (cmdMap != null)
        appendPrefCmdsToList(cmdMap, cmdList);

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label117:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      label117: if (cmdMap != null)
        appendPrefCmdsToList(cmdMap, cmdList);
    }

    CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
    cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);

    return cmdInfos;
  }

  private void appendPrefCmdsToList(Map cmdHash, List cmdList)
  {
    Iterator verb_enum = cmdHash.keySet().iterator();

    while (verb_enum.hasNext()) {
      String verb = (String)verb_enum.next();
      if (!(checkForVerb(cmdList, verb))) {
        List cmdList2 = (List)cmdHash.get(verb);
        String className = (String)cmdList2.get(0);
        cmdList.add(new CommandInfo(verb, className));
      }
    }
  }

  private boolean checkForVerb(List cmdList, String verb)
  {
    Iterator ee = cmdList.iterator();
    while (ee.hasNext()) {
      String enum_verb = ((CommandInfo)ee.next()).getCommandName();

      if (enum_verb.equals(verb))
        return true;
    }
    return false;
  }

  public synchronized CommandInfo[] getAllCommands(String mimeType)
  {
    Map cmdMap;
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label64:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      label64: if (cmdMap != null)
        appendCmdsToList(cmdMap, cmdList);

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label117:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      label117: if (cmdMap != null)
        appendCmdsToList(cmdMap, cmdList);
    }

    CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
    cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);

    return cmdInfos;
  }

  private void appendCmdsToList(Map typeHash, List cmdList)
  {
    Iterator verb_enum = typeHash.keySet().iterator();

    while (verb_enum.hasNext()) {
      String verb = (String)verb_enum.next();
      List cmdList2 = (List)typeHash.get(verb);
      Iterator cmd_enum = cmdList2.iterator();

      while (cmd_enum.hasNext()) {
        String cmd = (String)cmd_enum.next();
        cmdList.add(new CommandInfo(verb, cmd));
      }
    }
  }

  public synchronized CommandInfo getCommand(String mimeType, String cmdName)
  {
    Map cmdMap;
    List v;
    String cmdClassName;
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label96:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null)
      {
        v = (List)cmdMap.get(cmdName);
        if (v != null) {
          cmdClassName = (String)v.get(0);

          label96: if (cmdClassName != null)
            return new CommandInfo(cmdName, cmdClassName);
        }
      }

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label189:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null)
      {
        v = (List)cmdMap.get(cmdName);
        if (v != null) {
          cmdClassName = (String)v.get(0);

          label189: if (cmdClassName != null)
            return new CommandInfo(cmdName, cmdClassName);
        }
      }
    }
    return null;
  }

  public synchronized void addMailcap(String mail_cap)
  {
    LogSupport.log("MailcapCommandMap: add to PROG");
    if (this.DB[0] == null)
      this.DB[0] = new MailcapFile();

    this.DB[0].appendToMailcap(mail_cap);
  }

  public synchronized DataContentHandler createDataContentHandler(String mimeType)
  {
    Map cmdMap;
    List v;
    String name;
    DataContentHandler dch;
    if (LogSupport.isLoggable())
      LogSupport.log("MailcapCommandMap: createDataContentHandler for " + mimeType);

    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label150:
      if (LogSupport.isLoggable())
        LogSupport.log("  search DB #" + i);
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null) {
        v = (List)cmdMap.get("content-handler");
        if (v != null) {
          name = (String)v.get(0);
          dch = getDataContentHandler(name);
          label150: if (dch != null)
            return dch;
        }
      }

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label269:
      if (LogSupport.isLoggable())
        LogSupport.log("  search fallback DB #" + i);
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null) {
        v = (List)cmdMap.get("content-handler");
        if (v != null) {
          name = (String)v.get(0);
          dch = getDataContentHandler(name);
          label269: if (dch != null)
            return dch;
        }
      }
    }
    return null;
  }

  private DataContentHandler getDataContentHandler(String name) {
    if (LogSupport.isLoggable())
      LogSupport.log("    got content-handler");
    if (LogSupport.isLoggable())
      LogSupport.log("      class " + name);
    try {
      ClassLoader cld = null;

      cld = SecuritySupport.getContextClassLoader();
      if (cld == null)
        cld = getClass().getClassLoader();
      Class cl = null;
      try {
        cl = cld.loadClass(name);
      }
      catch (Exception ex) {
        cl = Class.forName(name);
      }
      if (cl != null)
        return ((DataContentHandler)cl.newInstance());
    } catch (IllegalAccessException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    } catch (ClassNotFoundException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    } catch (InstantiationException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    }
    return null;
  }

  public synchronized String[] getMimeTypes()
  {
    List mtList = new ArrayList();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label85:
      String[] ts = this.DB[i].getMimeTypes();
      label85: if (ts != null)
        for (int j = 0; j < ts.length; ++j)
        {
          if (!(mtList.contains(ts[j])))
            mtList.add(ts[j]);
        }

    }

    String[] mts = new String[mtList.size()];
    mts = (String[])(String[])mtList.toArray(mts);

    return mts;
  }

  public synchronized String[] getNativeCommands(String mimeType)
  {
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label100:
      String[] cmds = this.DB[i].getNativeCommands(mimeType);
      label100: if (cmds != null)
        for (int j = 0; j < cmds.length; ++j)
        {
          if (!(cmdList.contains(cmds[j])))
            cmdList.add(cmds[j]);
        }

    }

    String[] cmds = new String[cmdList.size()];
    cmds = (String[])(String[])cmdList.toArray(cmds);

    return cmds;
  }
}