package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class URLDataSource
  implements DataSource
{
  private URL url = null;
  private URLConnection url_conn = null;

  public URLDataSource(URL url)
  {
    this.url_conn = url;
  }

  public String getContentType()
  {
    String type = null;
    try
    {
      if (this.url_conn == null)
        this.url_conn = this.url_conn.openConnection();
    } catch (IOException e) {
    }
    if (this.url_conn != null)
      type = this.url_conn.getContentType();

    if (type == null)
      type = "application/octet-stream";

    return type;
  }

  public String getName()
  {
    return this.url_conn.getFile();
  }

  public InputStream getInputStream()
    throws IOException
  {
    return this.url_conn.openStream();
  }

  public OutputStream getOutputStream()
    throws IOException
  {
    this.url_conn = this.url_conn.openConnection();

    if (this.url_conn != null) {
      this.url_conn.setDoOutput(true);
      return this.url_conn.getOutputStream();
    }
    return null;
  }

  public URL getURL()
  {
    return this.url_conn;
  }
}