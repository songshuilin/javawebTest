package javax.mail.search;

import javax.mail.MessagingException;

public class SearchException extends MessagingException
{
  private static final long serialVersionUID = 264381938L;

  public SearchException(String s)
  {
    super(s);
  }
}