package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue
  implements Runnable
{
  private QueueElement head = null;
  private QueueElement tail = null;
  private Thread qThread;

  public EventQueue()
  {
    this.qThread = new Thread(this, "JavaMail-EventQueue");
    this.qThread.setDaemon(true);
    this.qThread.start();
  }

  public synchronized void enqueue(MailEvent event, Vector vector)
  {
    QueueElement newElt = new QueueElement(this, event, vector);

    if (this.tail == null) {
      this.tail = newElt;
      this.tail = newElt;
    } else {
      newElt.next = this.tail;
      this.tail.prev = newElt;
      this.tail = newElt;
    }
    super.notify();
  }

  private synchronized QueueElement dequeue()
    throws InterruptedException
  {
    while (this.tail == null)
      super.wait();
    QueueElement elt = this.tail;
    this.tail = elt.prev;
    if (this.tail == null)
      this.tail = null;
    else
      this.tail.next = null;

    elt.prev = (elt.next = null);
    return elt;
  }

  public void run()
  {
    label72: 
    try { while (true) { if ((qe = dequeue()) == null) break label72;
        MailEvent e = qe.event;
        Vector v = qe.vector;

        for (int i = 0; i < v.size(); ) {
          try {
            e.dispatch(v.elementAt(i));
          } catch (Throwable t) {
            if (t instanceof InterruptedException)
              break label72:
          }
          ++i;
        }

        QueueElement qe = null; e = null; v = null;
      }
    }
    catch (InterruptedException e)
    {
    }
  }

  void stop()
  {
    if (this.qThread != null) {
      this.qThread.interrupt();
      this.qThread = null;
    }
  }

  class QueueElement
  {
    QueueElement next = null;
    QueueElement prev = null;
    MailEvent event = null;
    Vector vector = null;
    private final EventQueue this$0;

    QueueElement(, MailEvent paramMailEvent, Vector paramVector)
    {
      this.event = paramMailEvent;
      this.vector = paramVector;
    }
  }
}