package javax.mail;

public class FolderNotFoundException extends MessagingException
{
  private transient Folder folder;
  private static final long serialVersionUID = -2096964869L;

  public FolderNotFoundException(Folder folder)
  {
    this.folder = folder;
  }

  public FolderNotFoundException(Folder folder, String s)
  {
    super(s);
    this.folder = folder;
  }

  public FolderNotFoundException(String s, Folder folder)
  {
    super(s);
    this.folder = folder;
  }

  public Folder getFolder()
  {
    return this.folder;
  }
}