package javax.mail;

public class MethodNotSupportedException extends MessagingException
{
  private static final long serialVersionUID = 453368198L;

  public MethodNotSupportedException(String s)
  {
    super(s);
  }
}