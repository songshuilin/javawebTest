package javax.mail.internet;

import javax.mail.MessagingException;

public class ParseException extends MessagingException
{
  private static final long serialVersionUID = 1070962793L;

  public ParseException(String s)
  {
    super(s);
  }
}