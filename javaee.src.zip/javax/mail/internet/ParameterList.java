package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class ParameterList
{
  private Map list = new LinkedHashMap();
  private static boolean encodeParameters = false;
  private static boolean decodeParameters = false;
  private static boolean decodeParametersStrict = false;
  private static final char[] hex;

  public ParameterList(String s)
    throws ParseException
  {
    HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
    while (true)
    {
      tk = h.next();
      int type = tk.getType();

      if (type == -4)
        return;

      if ((char)type != ';')
        break;
      tk = h.next();

      if (tk.getType() == -4)
        return;

      if (tk.getType() != -1)
        throw new ParseException("Expected parameter name, got \"" + tk.getValue() + "\"");

      String name = tk.getValue().toLowerCase();

      tk = h.next();
      if ((char)tk.getType() != '=') {
        throw new ParseException("Expected '=', got \"" + tk.getValue() + "\"");
      }

      tk = h.next();
      type = tk.getType();

      if ((type != -1) && (type != -2))
      {
        throw new ParseException("Expected parameter value, got \"" + tk.getValue() + "\"");
      }

      String value = tk.getValue();
      if ((decodeParameters) && (name.endsWith("*"))) {
        name = name.substring(0, name.length() - 1);
        this.list.put(name, decodeValue(value));
      }
      else this.list.put(name, value);
    }
    throw new ParseException("Expected ';', got \"" + tk.getValue() + "\"");
  }

  public int size()
  {
    return this.list.size();
  }

  public String get(String name)
  {
    String value;
    Object v = this.list.get(name.trim().toLowerCase());
    if (v instanceof Value)
      value = ((Value)v).value;
    else
      value = (String)v;
    return value;
  }

  public void set(String name, String value)
  {
    this.list.put(name.trim().toLowerCase(), value);
  }

  public void set(String name, String value, String charset)
  {
    if (encodeParameters) {
      Value ev = encodeValue(value, charset);

      if (ev != null)
        this.list.put(name.trim().toLowerCase(), ev);
      else
        set(name, value);
    }
    else set(name, value);
  }

  public void remove(String name)
  {
    this.list.remove(name.trim().toLowerCase());
  }

  public Enumeration getNames()
  {
    return new ParamEnum(this.list.keySet().iterator());
  }

  public String toString()
  {
    return toString(0);
  }

  public String toString(int used)
  {
    StringBuffer sb = new StringBuffer();
    Iterator e = this.list.keySet().iterator();

    while (e.hasNext()) {
      String name = (String)e.next();

      Object v = this.list.get(name);
      if (v instanceof Value) {
        value = ((Value)v).encodedValue;
        name = name + '*';
      }
      else value = (String)v;
      String value = quote(value);
      sb.append("; ");
      used += 2;
      int len = name.length() + value.length() + 1;
      if (used + len > 76) {
        sb.append("\r\n\t");
        used = 8;
      }
      sb.append(name).append('=');
      used = used + name.length() + 1;
      if (used + value.length() > 76)
      {
        String s = MimeUtility.fold(used, value);
        sb.append(s);
        int lastlf = s.lastIndexOf(10);
        if (lastlf >= 0)
          used = used + s.length() - lastlf - 1;
        else
          used = used + s.length();
      } else {
        sb.append(value);
        used = used + value.length();
      }
    }

    return sb.toString();
  }

  private String quote(String value)
  {
    return MimeUtility.quote(value, "()<>@,;:\\\"\t []/?=");
  }

  private Value encodeValue(String value, String charset)
  {
    byte[] b;
    if (MimeUtility.checkAscii(value) == 1)
      return null;

    try
    {
      b = value.getBytes(MimeUtility.javaCharset(charset));
    } catch (UnsupportedEncodingException ex) {
      return null;
    }
    StringBuffer sb = new StringBuffer(b.length + charset.length() + 2);
    sb.append(charset).append("''");
    for (int i = 0; i < b.length; ++i) {
      char c = (char)(b[i] & 0xFF);

      if ((c <= ' ') || (c >= '') || (c == '*') || (c == '\'') || (c == '%') || ("()<>@,;:\\\"\t []/?=".indexOf(c) >= 0))
      {
        sb.append('%').append(hex[(c >> '\4')]).append(hex[(c & 0xF)]);
      }
      else sb.append(c);
    }
    Value v = new Value(null);
    v.value = value;
    v.encodedValue = sb.toString();
    return v;
  }

  // ERROR //
  private Value decodeValue(String value)
    throws ParseException
  {
    // Byte code:
    //   0: new 150	javax/mail/internet/ParameterList$Value
    //   3: dup
    //   4: aconst_null
    //   5: invokespecial 289	javax/mail/internet/ParameterList$Value:<init>	(Ljavax/mail/internet/ParameterList$1;)V
    //   8: astore_2
    //   9: aload_2
    //   10: aload_1
    //   11: putfield 248	javax/mail/internet/ParameterList$Value:encodedValue	Ljava/lang/String;
    //   14: aload_2
    //   15: aload_1
    //   16: putfield 249	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   19: aload_1
    //   20: bipush 39
    //   22: invokevirtual 256	java/lang/String:indexOf	(I)I
    //   25: istore_3
    //   26: iload_3
    //   27: ifgt +38 -> 65
    //   30: getstatic 244	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   33: ifeq +30 -> 63
    //   36: new 151	ParseException
    //   39: dup
    //   40: new 137	java/lang/StringBuffer
    //   43: dup
    //   44: invokespecial 267	java/lang/StringBuffer:<init>	()V
    //   47: ldc 11
    //   49: invokevirtual 271	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   52: aload_1
    //   53: invokevirtual 271	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   56: invokevirtual 269	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   59: invokespecial 290	ParseException:<init>	(Ljava/lang/String;)V
    //   62: athrow
    //   63: aload_2
    //   64: areturn
    //   65: aload_1
    //   66: iconst_0
    //   67: iload_3
    //   68: invokevirtual 262	java/lang/String:substring	(II)Ljava/lang/String;
    //   71: astore 4
    //   73: aload_1
    //   74: bipush 39
    //   76: iload_3
    //   77: iconst_1
    //   78: iadd
    //   79: invokevirtual 258	java/lang/String:indexOf	(II)I
    //   82: istore 5
    //   84: iload 5
    //   86: ifge +38 -> 124
    //   89: getstatic 244	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   92: ifeq +30 -> 122
    //   95: new 151	ParseException
    //   98: dup
    //   99: new 137	java/lang/StringBuffer
    //   102: dup
    //   103: invokespecial 267	java/lang/StringBuffer:<init>	()V
    //   106: ldc 12
    //   108: invokevirtual 271	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   111: aload_1
    //   112: invokevirtual 271	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   115: invokevirtual 269	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   118: invokespecial 290	ParseException:<init>	(Ljava/lang/String;)V
    //   121: athrow
    //   122: aload_2
    //   123: areturn
    //   124: aload_1
    //   125: iload_3
    //   126: iconst_1
    //   127: iadd
    //   128: iload 5
    //   130: invokevirtual 262	java/lang/String:substring	(II)Ljava/lang/String;
    //   133: astore 6
    //   135: aload_1
    //   136: iload 5
    //   138: iconst_1
    //   139: iadd
    //   140: invokevirtual 261	java/lang/String:substring	(I)Ljava/lang/String;
    //   143: astore_1
    //   144: aload_1
    //   145: invokevirtual 254	java/lang/String:length	()I
    //   148: newarray byte
    //   150: astore 7
    //   152: iconst_0
    //   153: istore_3
    //   154: iconst_0
    //   155: istore 8
    //   157: iload_3
    //   158: aload_1
    //   159: invokevirtual 254	java/lang/String:length	()I
    //   162: if_icmpge +59 -> 221
    //   165: aload_1
    //   166: iload_3
    //   167: invokevirtual 255	java/lang/String:charAt	(I)C
    //   170: istore 9
    //   172: iload 9
    //   174: bipush 37
    //   176: if_icmpne +28 -> 204
    //   179: aload_1
    //   180: iload_3
    //   181: iconst_1
    //   182: iadd
    //   183: iload_3
    //   184: iconst_3
    //   185: iadd
    //   186: invokevirtual 262	java/lang/String:substring	(II)Ljava/lang/String;
    //   189: astore 10
    //   191: aload 10
    //   193: bipush 16
    //   195: invokestatic 251	java/lang/Integer:parseInt	(Ljava/lang/String;I)I
    //   198: i2c
    //   199: istore 9
    //   201: iinc 3 2
    //   204: aload 7
    //   206: iload 8
    //   208: iinc 8 1
    //   211: iload 9
    //   213: i2b
    //   214: bastore
    //   215: iinc 3 1
    //   218: goto -61 -> 157
    //   221: aload_2
    //   222: new 136	java/lang/String
    //   225: dup
    //   226: aload 7
    //   228: iconst_0
    //   229: iload 8
    //   231: aload 4
    //   233: invokestatic 281	javax/mail/internet/MimeUtility:javaCharset	(Ljava/lang/String;)Ljava/lang/String;
    //   236: invokespecial 266	java/lang/String:<init>	([BIILjava/lang/String;)V
    //   239: putfield 249	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   242: goto +66 -> 308
    //   245: astore_3
    //   246: getstatic 244	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   249: ifeq +15 -> 264
    //   252: new 151	ParseException
    //   255: dup
    //   256: aload_3
    //   257: invokevirtual 252	java/lang/NumberFormatException:toString	()Ljava/lang/String;
    //   260: invokespecial 290	ParseException:<init>	(Ljava/lang/String;)V
    //   263: athrow
    //   264: goto +44 -> 308
    //   267: astore_3
    //   268: getstatic 244	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   271: ifeq +15 -> 286
    //   274: new 151	ParseException
    //   277: dup
    //   278: aload_3
    //   279: invokevirtual 250	java/io/UnsupportedEncodingException:toString	()Ljava/lang/String;
    //   282: invokespecial 290	ParseException:<init>	(Ljava/lang/String;)V
    //   285: athrow
    //   286: goto +22 -> 308
    //   289: astore_3
    //   290: getstatic 244	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   293: ifeq +15 -> 308
    //   296: new 151	ParseException
    //   299: dup
    //   300: aload_3
    //   301: invokevirtual 272	java/lang/StringIndexOutOfBoundsException:toString	()Ljava/lang/String;
    //   304: invokespecial 290	ParseException:<init>	(Ljava/lang/String;)V
    //   307: athrow
    //   308: aload_2
    //   309: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   19	64	245	java/lang/NumberFormatException
    //   65	123	245	java/lang/NumberFormatException
    //   124	242	245	java/lang/NumberFormatException
    //   19	64	267	java/io/UnsupportedEncodingException
    //   65	123	267	java/io/UnsupportedEncodingException
    //   124	242	267	java/io/UnsupportedEncodingException
    //   19	64	289	java/lang/StringIndexOutOfBoundsException
    //   65	123	289	java/lang/StringIndexOutOfBoundsException
    //   124	242	289	java/lang/StringIndexOutOfBoundsException
  }

  static
  {
    try
    {
      String s = System.getProperty("mail.mime.encodeparameters");

      encodeParameters = (s != null) && (s.equalsIgnoreCase("true"));
      s = System.getProperty("mail.mime.decodeparameters");

      decodeParameters = (s != null) && (s.equalsIgnoreCase("true"));
      s = System.getProperty("mail.mime.decodeparameters.strict");

      decodeParametersStrict = (s != null) && (s.equalsIgnoreCase("true"));
    }
    catch (SecurityException sex)
    {
    }

    hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
  }

  private static class ParamEnum
  implements Enumeration
  {
    private Iterator it;

    ParamEnum(Iterator it)
    {
      this.it = it;
    }

    public boolean hasMoreElements() {
      return this.it.hasNext();
    }

    public Object nextElement() {
      return this.it.next();
    }
  }

  private static class Value
  {
    String value;
    String encodedValue;
  }
}