package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;

public class MimeMultipart extends Multipart
{
  private static boolean ignoreMissingEndBoundary = true;
  private static boolean ignoreMissingBoundaryParameter = true;
  private static boolean bmparse = true;
  protected DataSource ds;
  protected boolean parsed;
  private boolean complete;
  private String preamble;

  public MimeMultipart()
  {
    this("mixed");
  }

  public MimeMultipart(String subtype)
  {
    this.ds = null;

    this.parsed = true;

    this.complete = true;

    this.preamble = null;

    String boundary = UniqueValue.getUniqueBoundaryValue();
    ContentType cType = new ContentType("multipart", subtype, null);
    cType.setParameter("boundary", boundary);
    this.contentType = cType.toString();
  }

  public MimeMultipart(DataSource ds)
    throws MessagingException
  {
    this.ds = null;

    this.parsed = true;

    this.complete = true;

    this.preamble = null;

    if (ds instanceof MessageAware) {
      MessageContext mc = ((MessageAware)ds).getMessageContext();
      setParent(mc.getPart());
    }

    if (ds instanceof MultipartDataSource)
    {
      setMultipartDataSource((MultipartDataSource)ds);
      return;
    }

    this.parsed = false;
    this.ds = ds;
    this.contentType = ds.getContentType();
  }

  public synchronized void setSubType(String subtype)
    throws MessagingException
  {
    ContentType cType = new ContentType(this.contentType);
    cType.setSubType(subtype);
    this.contentType = cType.toString();
  }

  public synchronized int getCount()
    throws MessagingException
  {
    parse();
    return super.getCount();
  }

  public synchronized BodyPart getBodyPart(int index)
    throws MessagingException
  {
    parse();
    return super.getBodyPart(index);
  }

  public synchronized BodyPart getBodyPart(String CID)
    throws MessagingException
  {
    parse();

    int count = getCount();
    for (int i = 0; i < count; ++i) {
      MimeBodyPart part = (MimeBodyPart)getBodyPart(i);
      String s = part.getContentID();
      if ((s != null) && (s.equals(CID)))
        return part;
    }
    return null;
  }

  public boolean isComplete()
    throws MessagingException
  {
    parse();
    return this.complete;
  }

  public String getPreamble()
    throws MessagingException
  {
    parse();
    return this.preamble;
  }

  public void setPreamble(String preamble)
    throws MessagingException
  {
    this.preamble = preamble;
  }

  protected void updateHeaders()
    throws MessagingException
  {
    for (int i = 0; i < this.parts.size(); ++i)
      ((MimeBodyPart)this.parts.elementAt(i)).updateHeaders();
  }

  public void writeTo(OutputStream os)
    throws IOException, MessagingException
  {
    parse();

    String boundary = "--" + new ContentType(this.contentType).getParameter("boundary");

    LineOutputStream los = new LineOutputStream(os);

    if (this.preamble != null) {
      byte[] pb = ASCIIUtility.getBytes(this.preamble);
      los.write(pb);

      if ((pb.length > 0) && (pb[(pb.length - 1)] != 13) && (pb[(pb.length - 1)] != 10))
      {
        los.writeln();
      }
    }

    for (int i = 0; i < this.parts.size(); ++i) {
      los.writeln(boundary);
      ((MimeBodyPart)this.parts.elementAt(i)).writeTo(os);
      los.writeln();
    }

    los.writeln(boundary + "--"); } 
  // ERROR //
  protected synchronized void parse() throws MessagingException { // Byte code:
    //   0: aload_0
    //   1: getfield 329	javax/mail/internet/MimeMultipart:parsed	Z
    //   4: ifeq +4 -> 8
    //   7: return
    //   8: getstatic 325	javax/mail/internet/MimeMultipart:bmparse	Z
    //   11: ifeq +8 -> 19
    //   14: aload_0
    //   15: invokespecial 387	javax/mail/internet/MimeMultipart:parsebm	()V
    //   18: return
    //   19: aconst_null
    //   20: astore_1
    //   21: aconst_null
    //   22: astore_2
    //   23: lconst_0
    //   24: lstore_3
    //   25: lconst_0
    //   26: lstore 5
    //   28: aload_0
    //   29: getfield 333	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   32: invokeinterface 397 1 0
    //   37: astore_1
    //   38: aload_1
    //   39: instanceof 189
    //   42: ifne +26 -> 68
    //   45: aload_1
    //   46: instanceof 188
    //   49: ifne +19 -> 68
    //   52: aload_1
    //   53: instanceof 210
    //   56: ifne +12 -> 68
    //   59: new 188	java/io/BufferedInputStream
    //   62: dup
    //   63: aload_1
    //   64: invokespecial 341	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   67: astore_1
    //   68: goto +15 -> 83
    //   71: astore 7
    //   73: new 203	MessagingException
    //   76: dup
    //   77: ldc 6
    //   79: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   82: athrow
    //   83: aload_1
    //   84: instanceof 210
    //   87: ifeq +8 -> 95
    //   90: aload_1
    //   91: checkcast 210	javax/mail/internet/SharedInputStream
    //   94: astore_2
    //   95: new 206	javax/mail/internet/ContentType
    //   98: dup
    //   99: aload_0
    //   100: getfield 330	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   103: invokespecial 374	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   106: astore 7
    //   108: aconst_null
    //   109: astore 8
    //   111: aload 7
    //   113: ldc 8
    //   115: invokevirtual 376	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   118: astore 9
    //   120: aload 9
    //   122: ifnull +28 -> 150
    //   125: new 197	java/lang/StringBuffer
    //   128: dup
    //   129: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   132: ldc 2
    //   134: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   137: aload 9
    //   139: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   142: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   145: astore 8
    //   147: goto +19 -> 166
    //   150: getstatic 327	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   153: ifne +13 -> 166
    //   156: new 203	MessagingException
    //   159: dup
    //   160: ldc 4
    //   162: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   165: athrow
    //   166: new 186	com/sun/mail/util/LineInputStream
    //   169: dup
    //   170: aload_1
    //   171: invokespecial 335	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   174: astore 10
    //   176: aconst_null
    //   177: astore 12
    //   179: aload 10
    //   181: invokevirtual 336	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   184: dup
    //   185: astore 11
    //   187: ifnull +195 -> 382
    //   190: aload 11
    //   192: invokevirtual 354	java/lang/String:length	()I
    //   195: iconst_1
    //   196: isub
    //   197: istore 13
    //   199: iload 13
    //   201: iflt +35 -> 236
    //   204: aload 11
    //   206: iload 13
    //   208: invokevirtual 355	java/lang/String:charAt	(I)C
    //   211: istore 14
    //   213: iload 14
    //   215: bipush 32
    //   217: if_icmpeq +13 -> 230
    //   220: iload 14
    //   222: bipush 9
    //   224: if_icmpeq +6 -> 230
    //   227: goto +9 -> 236
    //   230: iinc 13 255
    //   233: goto -34 -> 199
    //   236: aload 11
    //   238: iconst_0
    //   239: iload 13
    //   241: iconst_1
    //   242: iadd
    //   243: invokevirtual 357	java/lang/String:substring	(II)Ljava/lang/String;
    //   246: astore 11
    //   248: aload 8
    //   250: ifnull +16 -> 266
    //   253: aload 11
    //   255: aload 8
    //   257: invokevirtual 356	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   260: ifeq +23 -> 283
    //   263: goto +119 -> 382
    //   266: aload 11
    //   268: ldc 2
    //   270: invokevirtual 359	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   273: ifeq +10 -> 283
    //   276: aload 11
    //   278: astore 8
    //   280: goto +102 -> 382
    //   283: aload 11
    //   285: invokevirtual 354	java/lang/String:length	()I
    //   288: ifle +91 -> 379
    //   291: aload 12
    //   293: ifnonnull +21 -> 314
    //   296: ldc 10
    //   298: ldc 1
    //   300: invokestatic 364	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   303: astore 12
    //   305: goto +9 -> 314
    //   308: astore 14
    //   310: ldc 1
    //   312: astore 12
    //   314: aload_0
    //   315: getfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   318: ifnonnull +30 -> 348
    //   321: aload_0
    //   322: new 197	java/lang/StringBuffer
    //   325: dup
    //   326: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   329: aload 11
    //   331: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   334: aload 12
    //   336: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   339: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   342: putfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   345: goto +34 -> 379
    //   348: new 197	java/lang/StringBuffer
    //   351: dup
    //   352: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   355: aload_0
    //   356: dup_x1
    //   357: getfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   360: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   363: aload 11
    //   365: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   368: aload 12
    //   370: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   373: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   376: putfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   379: goto -200 -> 179
    //   382: aload 11
    //   384: ifnonnull +13 -> 397
    //   387: new 203	MessagingException
    //   390: dup
    //   391: ldc 5
    //   393: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   396: athrow
    //   397: aload 8
    //   399: invokestatic 334	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   402: astore 13
    //   404: aload 13
    //   406: arraylength
    //   407: istore 14
    //   409: iconst_0
    //   410: istore 15
    //   412: iload 15
    //   414: ifne +494 -> 908
    //   417: aconst_null
    //   418: astore 16
    //   420: aload_2
    //   421: ifnull +61 -> 482
    //   424: aload_2
    //   425: invokeinterface 400 1 0
    //   430: lstore_3
    //   431: aload 10
    //   433: invokevirtual 336	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   436: dup
    //   437: astore 11
    //   439: ifnull +14 -> 453
    //   442: aload 11
    //   444: invokevirtual 354	java/lang/String:length	()I
    //   447: ifle +6 -> 453
    //   450: goto -19 -> 431
    //   453: aload 11
    //   455: ifnonnull +34 -> 489
    //   458: getstatic 328	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   461: ifne +13 -> 474
    //   464: new 203	MessagingException
    //   467: dup
    //   468: ldc 14
    //   470: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   473: athrow
    //   474: aload_0
    //   475: iconst_0
    //   476: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   479: goto +429 -> 908
    //   482: aload_0
    //   483: aload_1
    //   484: invokevirtual 393	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   487: astore 16
    //   489: aload_1
    //   490: invokevirtual 349	java/io/InputStream:markSupported	()Z
    //   493: ifne +13 -> 506
    //   496: new 203	MessagingException
    //   499: dup
    //   500: ldc 7
    //   502: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   505: athrow
    //   506: aconst_null
    //   507: astore 17
    //   509: aload_2
    //   510: ifnonnull +15 -> 525
    //   513: new 190	java/io/ByteArrayOutputStream
    //   516: dup
    //   517: invokespecial 342	java/io/ByteArrayOutputStream:<init>	()V
    //   520: astore 17
    //   522: goto +11 -> 533
    //   525: aload_2
    //   526: invokeinterface 400 1 0
    //   531: lstore 5
    //   533: iconst_1
    //   534: istore 19
    //   536: iconst_m1
    //   537: istore 20
    //   539: iconst_m1
    //   540: istore 21
    //   542: iload 19
    //   544: ifeq +192 -> 736
    //   547: aload_1
    //   548: iload 14
    //   550: iconst_4
    //   551: iadd
    //   552: sipush 1000
    //   555: iadd
    //   556: invokevirtual 350	java/io/InputStream:mark	(I)V
    //   559: iconst_0
    //   560: istore 22
    //   562: iload 22
    //   564: iload 14
    //   566: if_icmpge +28 -> 594
    //   569: aload_1
    //   570: invokevirtual 346	java/io/InputStream:read	()I
    //   573: aload 13
    //   575: iload 22
    //   577: baload
    //   578: sipush 255
    //   581: iand
    //   582: if_icmpeq +6 -> 588
    //   585: goto +9 -> 594
    //   588: iinc 22 1
    //   591: goto -29 -> 562
    //   594: iload 22
    //   596: iload 14
    //   598: if_icmpne +97 -> 695
    //   601: aload_1
    //   602: invokevirtual 346	java/io/InputStream:read	()I
    //   605: istore 23
    //   607: iload 23
    //   609: bipush 45
    //   611: if_icmpne +23 -> 634
    //   614: aload_1
    //   615: invokevirtual 346	java/io/InputStream:read	()I
    //   618: bipush 45
    //   620: if_icmpne +14 -> 634
    //   623: aload_0
    //   624: iconst_1
    //   625: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   628: iconst_1
    //   629: istore 15
    //   631: goto +233 -> 864
    //   634: iload 23
    //   636: bipush 32
    //   638: if_icmpeq +10 -> 648
    //   641: iload 23
    //   643: bipush 9
    //   645: if_icmpne +12 -> 657
    //   648: aload_1
    //   649: invokevirtual 346	java/io/InputStream:read	()I
    //   652: istore 23
    //   654: goto -20 -> 634
    //   657: iload 23
    //   659: bipush 10
    //   661: if_icmpne +6 -> 667
    //   664: goto +200 -> 864
    //   667: iload 23
    //   669: bipush 13
    //   671: if_icmpne +24 -> 695
    //   674: aload_1
    //   675: iconst_1
    //   676: invokevirtual 350	java/io/InputStream:mark	(I)V
    //   679: aload_1
    //   680: invokevirtual 346	java/io/InputStream:read	()I
    //   683: bipush 10
    //   685: if_icmpeq +179 -> 864
    //   688: aload_1
    //   689: invokevirtual 348	java/io/InputStream:reset	()V
    //   692: goto +172 -> 864
    //   695: aload_1
    //   696: invokevirtual 348	java/io/InputStream:reset	()V
    //   699: aload 17
    //   701: ifnull +35 -> 736
    //   704: iload 20
    //   706: iconst_m1
    //   707: if_icmpeq +29 -> 736
    //   710: aload 17
    //   712: iload 20
    //   714: invokevirtual 344	java/io/ByteArrayOutputStream:write	(I)V
    //   717: iload 21
    //   719: iconst_m1
    //   720: if_icmpeq +10 -> 730
    //   723: aload 17
    //   725: iload 21
    //   727: invokevirtual 344	java/io/ByteArrayOutputStream:write	(I)V
    //   730: iconst_m1
    //   731: dup
    //   732: istore 21
    //   734: istore 20
    //   736: aload_1
    //   737: invokevirtual 346	java/io/InputStream:read	()I
    //   740: dup
    //   741: istore 18
    //   743: ifge +30 -> 773
    //   746: getstatic 328	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   749: ifne +13 -> 762
    //   752: new 203	MessagingException
    //   755: dup
    //   756: ldc 14
    //   758: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   761: athrow
    //   762: aload_0
    //   763: iconst_0
    //   764: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   767: iconst_1
    //   768: istore 15
    //   770: goto +94 -> 864
    //   773: iload 18
    //   775: bipush 13
    //   777: if_icmpeq +10 -> 787
    //   780: iload 18
    //   782: bipush 10
    //   784: if_icmpne +62 -> 846
    //   787: iconst_1
    //   788: istore 19
    //   790: aload_2
    //   791: ifnull +13 -> 804
    //   794: aload_2
    //   795: invokeinterface 400 1 0
    //   800: lconst_1
    //   801: lsub
    //   802: lstore 5
    //   804: iload 18
    //   806: istore 20
    //   808: iload 18
    //   810: bipush 13
    //   812: if_icmpne -270 -> 542
    //   815: aload_1
    //   816: iconst_1
    //   817: invokevirtual 350	java/io/InputStream:mark	(I)V
    //   820: aload_1
    //   821: invokevirtual 346	java/io/InputStream:read	()I
    //   824: dup
    //   825: istore 18
    //   827: bipush 10
    //   829: if_icmpne +10 -> 839
    //   832: iload 18
    //   834: istore 21
    //   836: goto -294 -> 542
    //   839: aload_1
    //   840: invokevirtual 348	java/io/InputStream:reset	()V
    //   843: goto -301 -> 542
    //   846: iconst_0
    //   847: istore 19
    //   849: aload 17
    //   851: ifnull -309 -> 542
    //   854: aload 17
    //   856: iload 18
    //   858: invokevirtual 344	java/io/ByteArrayOutputStream:write	(I)V
    //   861: goto -319 -> 542
    //   864: aload_2
    //   865: ifnull +21 -> 886
    //   868: aload_0
    //   869: aload_2
    //   870: lload_3
    //   871: lload 5
    //   873: invokeinterface 401 5 0
    //   878: invokevirtual 394	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   881: astore 22
    //   883: goto +16 -> 899
    //   886: aload_0
    //   887: aload 16
    //   889: aload 17
    //   891: invokevirtual 343	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   894: invokevirtual 395	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   897: astore 22
    //   899: aload_0
    //   900: aload 22
    //   902: invokevirtual 390	javax/mail/internet/MimeMultipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   905: goto -493 -> 412
    //   908: aload_1
    //   909: invokevirtual 347	java/io/InputStream:close	()V
    //   912: goto +36 -> 948
    //   915: astore 10
    //   917: goto +31 -> 948
    //   920: astore 10
    //   922: new 203	MessagingException
    //   925: dup
    //   926: ldc 3
    //   928: aload 10
    //   930: invokespecial 369	MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   933: athrow
    //   934: astore 24
    //   936: aload_1
    //   937: invokevirtual 347	java/io/InputStream:close	()V
    //   940: goto +5 -> 945
    //   943: astore 25
    //   945: aload 24
    //   947: athrow
    //   948: aload_0
    //   949: iconst_1
    //   950: putfield 329	javax/mail/internet/MimeMultipart:parsed	Z
    //   953: return
    //
    // Exception table:
    //   from	to	target	type
    //   28	68	71	java/lang/Exception
    //   296	305	308	java/lang/SecurityException
    //   908	912	915	IOException
    //   166	908	920	IOException
    //   166	908	934	finally
    //   920	936	934	finally
    //   936	940	943	IOException } 
  // ERROR //
  private synchronized void parsebm() throws MessagingException { // Byte code:
    //   0: aload_0
    //   1: getfield 329	javax/mail/internet/MimeMultipart:parsed	Z
    //   4: ifeq +4 -> 8
    //   7: return
    //   8: aconst_null
    //   9: astore_1
    //   10: aconst_null
    //   11: astore_2
    //   12: lconst_0
    //   13: lstore_3
    //   14: lconst_0
    //   15: lstore 5
    //   17: aload_0
    //   18: getfield 333	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   21: invokeinterface 397 1 0
    //   26: astore_1
    //   27: aload_1
    //   28: instanceof 189
    //   31: ifne +26 -> 57
    //   34: aload_1
    //   35: instanceof 188
    //   38: ifne +19 -> 57
    //   41: aload_1
    //   42: instanceof 210
    //   45: ifne +12 -> 57
    //   48: new 188	java/io/BufferedInputStream
    //   51: dup
    //   52: aload_1
    //   53: invokespecial 341	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   56: astore_1
    //   57: goto +15 -> 72
    //   60: astore 7
    //   62: new 203	MessagingException
    //   65: dup
    //   66: ldc 6
    //   68: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   71: athrow
    //   72: aload_1
    //   73: instanceof 210
    //   76: ifeq +8 -> 84
    //   79: aload_1
    //   80: checkcast 210	javax/mail/internet/SharedInputStream
    //   83: astore_2
    //   84: new 206	javax/mail/internet/ContentType
    //   87: dup
    //   88: aload_0
    //   89: getfield 330	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   92: invokespecial 374	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   95: astore 7
    //   97: aconst_null
    //   98: astore 8
    //   100: aload 7
    //   102: ldc 8
    //   104: invokevirtual 376	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   107: astore 9
    //   109: aload 9
    //   111: ifnull +28 -> 139
    //   114: new 197	java/lang/StringBuffer
    //   117: dup
    //   118: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   121: ldc 2
    //   123: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   126: aload 9
    //   128: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   131: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   134: astore 8
    //   136: goto +19 -> 155
    //   139: getstatic 327	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   142: ifne +13 -> 155
    //   145: new 203	MessagingException
    //   148: dup
    //   149: ldc 4
    //   151: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   154: athrow
    //   155: new 186	com/sun/mail/util/LineInputStream
    //   158: dup
    //   159: aload_1
    //   160: invokespecial 335	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   163: astore 10
    //   165: aconst_null
    //   166: astore 12
    //   168: aload 10
    //   170: invokevirtual 336	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   173: dup
    //   174: astore 11
    //   176: ifnull +195 -> 371
    //   179: aload 11
    //   181: invokevirtual 354	java/lang/String:length	()I
    //   184: iconst_1
    //   185: isub
    //   186: istore 13
    //   188: iload 13
    //   190: iflt +35 -> 225
    //   193: aload 11
    //   195: iload 13
    //   197: invokevirtual 355	java/lang/String:charAt	(I)C
    //   200: istore 14
    //   202: iload 14
    //   204: bipush 32
    //   206: if_icmpeq +13 -> 219
    //   209: iload 14
    //   211: bipush 9
    //   213: if_icmpeq +6 -> 219
    //   216: goto +9 -> 225
    //   219: iinc 13 255
    //   222: goto -34 -> 188
    //   225: aload 11
    //   227: iconst_0
    //   228: iload 13
    //   230: iconst_1
    //   231: iadd
    //   232: invokevirtual 357	java/lang/String:substring	(II)Ljava/lang/String;
    //   235: astore 11
    //   237: aload 8
    //   239: ifnull +16 -> 255
    //   242: aload 11
    //   244: aload 8
    //   246: invokevirtual 356	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   249: ifeq +23 -> 272
    //   252: goto +119 -> 371
    //   255: aload 11
    //   257: ldc 2
    //   259: invokevirtual 359	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   262: ifeq +10 -> 272
    //   265: aload 11
    //   267: astore 8
    //   269: goto +102 -> 371
    //   272: aload 11
    //   274: invokevirtual 354	java/lang/String:length	()I
    //   277: ifle +91 -> 368
    //   280: aload 12
    //   282: ifnonnull +21 -> 303
    //   285: ldc 10
    //   287: ldc 1
    //   289: invokestatic 364	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   292: astore 12
    //   294: goto +9 -> 303
    //   297: astore 14
    //   299: ldc 1
    //   301: astore 12
    //   303: aload_0
    //   304: getfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   307: ifnonnull +30 -> 337
    //   310: aload_0
    //   311: new 197	java/lang/StringBuffer
    //   314: dup
    //   315: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   318: aload 11
    //   320: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   323: aload 12
    //   325: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   328: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   331: putfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   334: goto +34 -> 368
    //   337: new 197	java/lang/StringBuffer
    //   340: dup
    //   341: invokespecial 360	java/lang/StringBuffer:<init>	()V
    //   344: aload_0
    //   345: dup_x1
    //   346: getfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   349: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   352: aload 11
    //   354: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   357: aload 12
    //   359: invokevirtual 362	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   362: invokevirtual 361	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   365: putfield 331	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   368: goto -200 -> 168
    //   371: aload 11
    //   373: ifnonnull +13 -> 386
    //   376: new 203	MessagingException
    //   379: dup
    //   380: ldc 5
    //   382: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   385: athrow
    //   386: aload 8
    //   388: invokestatic 334	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   391: astore 13
    //   393: aload 13
    //   395: arraylength
    //   396: istore 14
    //   398: sipush 256
    //   401: newarray int
    //   403: astore 15
    //   405: iconst_0
    //   406: istore 16
    //   408: iload 16
    //   410: iload 14
    //   412: if_icmpge +21 -> 433
    //   415: aload 15
    //   417: aload 13
    //   419: iload 16
    //   421: baload
    //   422: iload 16
    //   424: iconst_1
    //   425: iadd
    //   426: iastore
    //   427: iinc 16 1
    //   430: goto -22 -> 408
    //   433: iload 14
    //   435: newarray int
    //   437: astore 16
    //   439: iload 14
    //   441: istore 17
    //   443: iload 17
    //   445: ifle +71 -> 516
    //   448: iload 14
    //   450: iconst_1
    //   451: isub
    //   452: istore 18
    //   454: iload 18
    //   456: iload 17
    //   458: if_icmplt +34 -> 492
    //   461: aload 13
    //   463: iload 18
    //   465: baload
    //   466: aload 13
    //   468: iload 18
    //   470: iload 17
    //   472: isub
    //   473: baload
    //   474: if_icmpne +36 -> 510
    //   477: aload 16
    //   479: iload 18
    //   481: iconst_1
    //   482: isub
    //   483: iload 17
    //   485: iastore
    //   486: iinc 18 255
    //   489: goto -35 -> 454
    //   492: iload 18
    //   494: ifle +16 -> 510
    //   497: aload 16
    //   499: iinc 18 255
    //   502: iload 18
    //   504: iload 17
    //   506: iastore
    //   507: goto -15 -> 492
    //   510: iinc 17 255
    //   513: goto -70 -> 443
    //   516: aload 16
    //   518: iload 14
    //   520: iconst_1
    //   521: isub
    //   522: iconst_1
    //   523: iastore
    //   524: iconst_0
    //   525: istore 17
    //   527: iload 17
    //   529: ifne +692 -> 1221
    //   532: aconst_null
    //   533: astore 18
    //   535: aload_2
    //   536: ifnull +61 -> 597
    //   539: aload_2
    //   540: invokeinterface 400 1 0
    //   545: lstore_3
    //   546: aload 10
    //   548: invokevirtual 336	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   551: dup
    //   552: astore 11
    //   554: ifnull +14 -> 568
    //   557: aload 11
    //   559: invokevirtual 354	java/lang/String:length	()I
    //   562: ifle +6 -> 568
    //   565: goto -19 -> 546
    //   568: aload 11
    //   570: ifnonnull +34 -> 604
    //   573: getstatic 328	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   576: ifne +13 -> 589
    //   579: new 203	MessagingException
    //   582: dup
    //   583: ldc 14
    //   585: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   588: athrow
    //   589: aload_0
    //   590: iconst_0
    //   591: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   594: goto +627 -> 1221
    //   597: aload_0
    //   598: aload_1
    //   599: invokevirtual 393	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   602: astore 18
    //   604: aload_1
    //   605: invokevirtual 349	java/io/InputStream:markSupported	()Z
    //   608: ifne +13 -> 621
    //   611: new 203	MessagingException
    //   614: dup
    //   615: ldc 7
    //   617: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   620: athrow
    //   621: aconst_null
    //   622: astore 19
    //   624: aload_2
    //   625: ifnonnull +15 -> 640
    //   628: new 190	java/io/ByteArrayOutputStream
    //   631: dup
    //   632: invokespecial 342	java/io/ByteArrayOutputStream:<init>	()V
    //   635: astore 19
    //   637: goto +11 -> 648
    //   640: aload_2
    //   641: invokeinterface 400 1 0
    //   646: lstore 5
    //   648: iload 14
    //   650: newarray byte
    //   652: astore 21
    //   654: iload 14
    //   656: newarray byte
    //   658: astore 22
    //   660: iconst_0
    //   661: istore 23
    //   663: iconst_0
    //   664: istore 24
    //   666: iconst_1
    //   667: istore 26
    //   669: aload_1
    //   670: iload 14
    //   672: iconst_4
    //   673: iadd
    //   674: sipush 1000
    //   677: iadd
    //   678: invokevirtual 350	java/io/InputStream:mark	(I)V
    //   681: iconst_0
    //   682: istore 25
    //   684: aload_1
    //   685: aload 21
    //   687: iconst_0
    //   688: iload 14
    //   690: invokevirtual 352	java/io/InputStream:read	([BII)I
    //   693: istore 23
    //   695: iload 23
    //   697: iload 14
    //   699: if_icmpge +42 -> 741
    //   702: getstatic 328	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   705: ifne +13 -> 718
    //   708: new 203	MessagingException
    //   711: dup
    //   712: ldc 14
    //   714: invokespecial 368	MessagingException:<init>	(Ljava/lang/String;)V
    //   717: athrow
    //   718: aload_2
    //   719: ifnull +11 -> 730
    //   722: aload_2
    //   723: invokeinterface 400 1 0
    //   728: lstore 5
    //   730: aload_0
    //   731: iconst_0
    //   732: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   735: iconst_1
    //   736: istore 17
    //   738: goto +396 -> 1134
    //   741: iload 14
    //   743: iconst_1
    //   744: isub
    //   745: istore 27
    //   747: iload 27
    //   749: iflt +25 -> 774
    //   752: aload 21
    //   754: iload 27
    //   756: baload
    //   757: aload 13
    //   759: iload 27
    //   761: baload
    //   762: if_icmpeq +6 -> 768
    //   765: goto +9 -> 774
    //   768: iinc 27 255
    //   771: goto -24 -> 747
    //   774: iload 27
    //   776: ifge +196 -> 972
    //   779: iconst_0
    //   780: istore 25
    //   782: iload 26
    //   784: ifne +61 -> 845
    //   787: aload 22
    //   789: iload 24
    //   791: iconst_1
    //   792: isub
    //   793: baload
    //   794: istore 20
    //   796: iload 20
    //   798: bipush 13
    //   800: if_icmpeq +10 -> 810
    //   803: iload 20
    //   805: bipush 10
    //   807: if_icmpne +38 -> 845
    //   810: iconst_1
    //   811: istore 25
    //   813: iload 20
    //   815: bipush 10
    //   817: if_icmpne +28 -> 845
    //   820: iload 24
    //   822: iconst_2
    //   823: if_icmplt +22 -> 845
    //   826: aload 22
    //   828: iload 24
    //   830: iconst_2
    //   831: isub
    //   832: baload
    //   833: istore 20
    //   835: iload 20
    //   837: bipush 13
    //   839: if_icmpne +6 -> 845
    //   842: iconst_2
    //   843: istore 25
    //   845: iload 26
    //   847: ifne +8 -> 855
    //   850: iload 25
    //   852: ifle +117 -> 969
    //   855: aload_2
    //   856: ifnull +19 -> 875
    //   859: aload_2
    //   860: invokeinterface 400 1 0
    //   865: iload 14
    //   867: i2l
    //   868: lsub
    //   869: iload 25
    //   871: i2l
    //   872: lsub
    //   873: lstore 5
    //   875: aload_1
    //   876: invokevirtual 346	java/io/InputStream:read	()I
    //   879: istore 28
    //   881: iload 28
    //   883: bipush 45
    //   885: if_icmpne +23 -> 908
    //   888: aload_1
    //   889: invokevirtual 346	java/io/InputStream:read	()I
    //   892: bipush 45
    //   894: if_icmpne +14 -> 908
    //   897: aload_0
    //   898: iconst_1
    //   899: putfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   902: iconst_1
    //   903: istore 17
    //   905: goto +229 -> 1134
    //   908: iload 28
    //   910: bipush 32
    //   912: if_icmpeq +10 -> 922
    //   915: iload 28
    //   917: bipush 9
    //   919: if_icmpne +12 -> 931
    //   922: aload_1
    //   923: invokevirtual 346	java/io/InputStream:read	()I
    //   926: istore 28
    //   928: goto -20 -> 908
    //   931: iload 28
    //   933: bipush 10
    //   935: if_icmpne +6 -> 941
    //   938: goto +196 -> 1134
    //   941: iload 28
    //   943: bipush 13
    //   945: if_icmpne +24 -> 969
    //   948: aload_1
    //   949: iconst_1
    //   950: invokevirtual 350	java/io/InputStream:mark	(I)V
    //   953: aload_1
    //   954: invokevirtual 346	java/io/InputStream:read	()I
    //   957: bipush 10
    //   959: if_icmpeq +175 -> 1134
    //   962: aload_1
    //   963: invokevirtual 348	java/io/InputStream:reset	()V
    //   966: goto +168 -> 1134
    //   969: iconst_0
    //   970: istore 27
    //   972: iload 27
    //   974: iconst_1
    //   975: iadd
    //   976: aload 15
    //   978: aload 21
    //   980: iload 27
    //   982: baload
    //   983: bipush 127
    //   985: iand
    //   986: iaload
    //   987: isub
    //   988: aload 16
    //   990: iload 27
    //   992: iaload
    //   993: invokestatic 353	java/lang/Math:max	(II)I
    //   996: istore 28
    //   998: iload 28
    //   1000: iconst_2
    //   1001: if_icmpge +80 -> 1081
    //   1004: aload_2
    //   1005: ifnonnull +21 -> 1026
    //   1008: iload 24
    //   1010: iconst_1
    //   1011: if_icmple +15 -> 1026
    //   1014: aload 19
    //   1016: aload 22
    //   1018: iconst_0
    //   1019: iload 24
    //   1021: iconst_1
    //   1022: isub
    //   1023: invokevirtual 345	java/io/ByteArrayOutputStream:write	([BII)V
    //   1026: aload_1
    //   1027: invokevirtual 348	java/io/InputStream:reset	()V
    //   1030: aload_1
    //   1031: lconst_1
    //   1032: invokevirtual 351	java/io/InputStream:skip	(J)J
    //   1035: pop2
    //   1036: iload 24
    //   1038: iconst_1
    //   1039: if_icmplt +28 -> 1067
    //   1042: aload 22
    //   1044: iconst_0
    //   1045: aload 22
    //   1047: iload 24
    //   1049: iconst_1
    //   1050: isub
    //   1051: baload
    //   1052: bastore
    //   1053: aload 22
    //   1055: iconst_1
    //   1056: aload 21
    //   1058: iconst_0
    //   1059: baload
    //   1060: bastore
    //   1061: iconst_2
    //   1062: istore 24
    //   1064: goto +64 -> 1128
    //   1067: aload 22
    //   1069: iconst_0
    //   1070: aload 21
    //   1072: iconst_0
    //   1073: baload
    //   1074: bastore
    //   1075: iconst_1
    //   1076: istore 24
    //   1078: goto +50 -> 1128
    //   1081: iload 24
    //   1083: ifle +17 -> 1100
    //   1086: aload_2
    //   1087: ifnonnull +13 -> 1100
    //   1090: aload 19
    //   1092: aload 22
    //   1094: iconst_0
    //   1095: iload 24
    //   1097: invokevirtual 345	java/io/ByteArrayOutputStream:write	([BII)V
    //   1100: iload 28
    //   1102: istore 24
    //   1104: aload_1
    //   1105: invokevirtual 348	java/io/InputStream:reset	()V
    //   1108: aload_1
    //   1109: iload 24
    //   1111: i2l
    //   1112: invokevirtual 351	java/io/InputStream:skip	(J)J
    //   1115: pop2
    //   1116: aload 21
    //   1118: astore 29
    //   1120: aload 22
    //   1122: astore 21
    //   1124: aload 29
    //   1126: astore 22
    //   1128: iconst_0
    //   1129: istore 26
    //   1131: goto -462 -> 669
    //   1134: aload_2
    //   1135: ifnull +21 -> 1156
    //   1138: aload_0
    //   1139: aload_2
    //   1140: lload_3
    //   1141: lload 5
    //   1143: invokeinterface 401 5 0
    //   1148: invokevirtual 394	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   1151: astore 27
    //   1153: goto +59 -> 1212
    //   1156: iload 24
    //   1158: iload 25
    //   1160: isub
    //   1161: ifle +16 -> 1177
    //   1164: aload 19
    //   1166: aload 22
    //   1168: iconst_0
    //   1169: iload 24
    //   1171: iload 25
    //   1173: isub
    //   1174: invokevirtual 345	java/io/ByteArrayOutputStream:write	([BII)V
    //   1177: aload_0
    //   1178: getfield 326	javax/mail/internet/MimeMultipart:complete	Z
    //   1181: ifne +18 -> 1199
    //   1184: iload 23
    //   1186: ifle +13 -> 1199
    //   1189: aload 19
    //   1191: aload 21
    //   1193: iconst_0
    //   1194: iload 23
    //   1196: invokevirtual 345	java/io/ByteArrayOutputStream:write	([BII)V
    //   1199: aload_0
    //   1200: aload 18
    //   1202: aload 19
    //   1204: invokevirtual 343	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   1207: invokevirtual 395	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   1210: astore 27
    //   1212: aload_0
    //   1213: aload 27
    //   1215: invokevirtual 390	javax/mail/internet/MimeMultipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   1218: goto -691 -> 527
    //   1221: aload_1
    //   1222: invokevirtual 347	java/io/InputStream:close	()V
    //   1225: goto +36 -> 1261
    //   1228: astore 10
    //   1230: goto +31 -> 1261
    //   1233: astore 10
    //   1235: new 203	MessagingException
    //   1238: dup
    //   1239: ldc 3
    //   1241: aload 10
    //   1243: invokespecial 369	MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   1246: athrow
    //   1247: astore 30
    //   1249: aload_1
    //   1250: invokevirtual 347	java/io/InputStream:close	()V
    //   1253: goto +5 -> 1258
    //   1256: astore 31
    //   1258: aload 30
    //   1260: athrow
    //   1261: aload_0
    //   1262: iconst_1
    //   1263: putfield 329	javax/mail/internet/MimeMultipart:parsed	Z
    //   1266: return
    //
    // Exception table:
    //   from	to	target	type
    //   17	57	60	java/lang/Exception
    //   285	294	297	java/lang/SecurityException
    //   1221	1225	1228	IOException
    //   155	1221	1233	IOException
    //   155	1221	1247	finally
    //   1233	1249	1247	finally
    //   1249	1253	1256	IOException } 
  protected InternetHeaders createInternetHeaders(InputStream is) throws MessagingException { return new InternetHeaders(is);
  }

  protected MimeBodyPart createMimeBodyPart(InternetHeaders headers, byte[] content)
    throws MessagingException
  {
    return new MimeBodyPart(headers, content);
  }

  protected MimeBodyPart createMimeBodyPart(InputStream is)
    throws MessagingException
  {
    return new MimeBodyPart(is);
  }

  static
  {
    try
    {
      String s = System.getProperty("mail.mime.multipart.ignoremissingendboundary");

      ignoreMissingEndBoundary = (s == null) || (!(s.equalsIgnoreCase("false")));

      s = System.getProperty("mail.mime.multipart.ignoremissingboundaryparameter");

      ignoreMissingBoundaryParameter = (s == null) || (!(s.equalsIgnoreCase("false")));

      s = System.getProperty("mail.mime.multipart.bmparse");

      bmparse = (s == null) || (!(s.equalsIgnoreCase("false")));
    }
    catch (SecurityException sex)
    {
    }
  }
}