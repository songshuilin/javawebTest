package javax.mail;

public class IllegalWriteException extends MessagingException
{
  private static final long serialVersionUID = 928976621L;

  public IllegalWriteException(String s)
  {
    super(s);
  }
}