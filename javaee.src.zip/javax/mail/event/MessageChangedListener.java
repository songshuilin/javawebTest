package javax.mail.event;

import java.util.EventListener;

public abstract interface MessageChangedListener
  implements EventListener
{
  public abstract void messageChanged(MessageChangedEvent paramMessageChangedEvent);
}