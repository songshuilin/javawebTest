package javax.mail.event;

import java.util.EventListener;

public abstract interface ConnectionListener
  implements EventListener
{
  public abstract void opened(ConnectionEvent paramConnectionEvent);

  public abstract void disconnected(ConnectionEvent paramConnectionEvent);

  public abstract void closed(ConnectionEvent paramConnectionEvent);
}