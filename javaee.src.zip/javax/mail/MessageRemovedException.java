package javax.mail;

public class MessageRemovedException extends MessagingException
{
  private static final long serialVersionUID = -2011265806L;

  public MessageRemovedException(String s)
  {
    super(s);
  }
}