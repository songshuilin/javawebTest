package javax.mail;

public class NoSuchProviderException extends MessagingException
{
  private static final long serialVersionUID = -886452901L;

  public NoSuchProviderException(String message)
  {
    super(message);
  }
}