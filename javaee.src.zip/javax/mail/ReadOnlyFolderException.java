package javax.mail;

public class ReadOnlyFolderException extends MessagingException
{
  private transient Folder folder;
  private static final long serialVersionUID = 1330919261L;

  public ReadOnlyFolderException(Folder folder)
  {
    this(folder, null);
  }

  public ReadOnlyFolderException(Folder folder, String message)
  {
    super(message);
    this.folder = folder;
  }

  public Folder getFolder()
  {
    return this.folder;
  }
}