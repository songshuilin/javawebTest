package javax.mail;

public class AuthenticationFailedException extends MessagingException
{
  private static final long serialVersionUID = -1304914273L;

  public AuthenticationFailedException(String message)
  {
    super(message);
  }
}