package javax.mail.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.DataSource;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParseException;

public class ByteArrayDataSource
  implements DataSource
{
  private byte[] data;
  private String type;
  private String name = "";

  public ByteArrayDataSource(InputStream is, String type)
    throws IOException
  {
    ByteArrayOutputStream os = new ByteArrayOutputStream();
    byte[] buf = new byte[8192];
    while (true) {
      int len;
      if ((len = is.read(buf)) <= 0) break;
      os.write(buf, 0, len); }
    this.data = os.toByteArray();
    this.type = type;
  }

  public ByteArrayDataSource(byte[] data, String type)
  {
    this.data = data;
    this.type = type;
  }

  public ByteArrayDataSource(String data, String type)
    throws IOException
  {
    String charset = null;
    try {
      ContentType ct = new ContentType(type);
      charset = ct.getParameter("charset"); } catch (ParseException pex) {
    }
    if (charset == null)
      charset = MimeUtility.getDefaultJavaCharset();

    this.data = data.getBytes(charset);
    this.type = type;
  }

  public InputStream getInputStream()
    throws IOException
  {
    if (this.data == null)
      throw new IOException("no data");
    return new ByteArrayInputStream(this.data);
  }

  public OutputStream getOutputStream()
    throws IOException
  {
    throw new IOException("cannot do this");
  }

  public String getContentType()
  {
    return this.type;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String name)
  {
    this.name = name;
  }
}