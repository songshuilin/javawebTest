package javax.jms;

public abstract interface XAQueueConnectionFactory
  implements XAConnectionFactory, QueueConnectionFactory
{
  public abstract XAQueueConnection createXAQueueConnection()
    throws JMSException;

  public abstract XAQueueConnection createXAQueueConnection(String paramString1, String paramString2)
    throws JMSException;
}