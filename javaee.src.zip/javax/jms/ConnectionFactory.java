package javax.jms;

public abstract interface ConnectionFactory
{
  public abstract Connection createConnection()
    throws JMSException;

  public abstract Connection createConnection(String paramString1, String paramString2)
    throws JMSException;
}