package javax.jms;

public class InvalidSelectorException extends JMSException
{
  public InvalidSelectorException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public InvalidSelectorException(String reason)
  {
    super(reason);
  }
}