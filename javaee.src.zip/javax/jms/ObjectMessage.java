package javax.jms;

import java.io.Serializable;

public abstract interface ObjectMessage
  implements Message
{
  public abstract void setObject(Serializable paramSerializable)
    throws JMSException;

  public abstract Serializable getObject()
    throws JMSException;
}