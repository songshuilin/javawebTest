package javax.jms;

public class MessageNotWriteableException extends JMSException
{
  public MessageNotWriteableException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public MessageNotWriteableException(String reason)
  {
    super(reason);
  }
}