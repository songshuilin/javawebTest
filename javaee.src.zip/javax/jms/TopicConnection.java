package javax.jms;

public abstract interface TopicConnection
  implements Connection
{
  public abstract TopicSession createTopicSession(boolean paramBoolean, int paramInt)
    throws JMSException;

  public abstract ConnectionConsumer createConnectionConsumer(Topic paramTopic, String paramString, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException;

  public abstract ConnectionConsumer createDurableConnectionConsumer(Topic paramTopic, String paramString1, String paramString2, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException;
}