package javax.jms;

public abstract interface XAQueueConnection
  implements XAConnection, QueueConnection
{
  public abstract XAQueueSession createXAQueueSession()
    throws JMSException;

  public abstract QueueSession createQueueSession(boolean paramBoolean, int paramInt)
    throws JMSException;
}