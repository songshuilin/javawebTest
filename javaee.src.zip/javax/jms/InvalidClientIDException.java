package javax.jms;

public class InvalidClientIDException extends JMSException
{
  public InvalidClientIDException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public InvalidClientIDException(String reason)
  {
    super(reason);
  }
}