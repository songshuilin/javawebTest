package javax.jms;

public abstract interface ServerSessionPool
{
  public abstract ServerSession getServerSession()
    throws JMSException;
}