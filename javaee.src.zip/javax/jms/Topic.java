package javax.jms;

public abstract interface Topic
  implements Destination
{
  public abstract String getTopicName()
    throws JMSException;

  public abstract String toString();
}