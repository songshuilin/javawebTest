package javax.jms;

public abstract interface QueueReceiver
  implements MessageConsumer
{
  public abstract Queue getQueue()
    throws JMSException;
}