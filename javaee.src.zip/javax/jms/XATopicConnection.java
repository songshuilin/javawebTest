package javax.jms;

public abstract interface XATopicConnection
  implements XAConnection, TopicConnection
{
  public abstract XATopicSession createXATopicSession()
    throws JMSException;

  public abstract TopicSession createTopicSession(boolean paramBoolean, int paramInt)
    throws JMSException;
}