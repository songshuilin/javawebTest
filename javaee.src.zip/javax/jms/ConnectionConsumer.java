package javax.jms;

public abstract interface ConnectionConsumer
{
  public abstract ServerSessionPool getServerSessionPool()
    throws JMSException;

  public abstract void close()
    throws JMSException;
}