package javax.jms;

public abstract interface TextMessage
  implements Message
{
  public abstract void setText(String paramString)
    throws JMSException;

  public abstract String getText()
    throws JMSException;
}