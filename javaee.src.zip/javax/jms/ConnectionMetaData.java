package javax.jms;

import java.util.Enumeration;

public abstract interface ConnectionMetaData
{
  public abstract String getJMSVersion()
    throws JMSException;

  public abstract int getJMSMajorVersion()
    throws JMSException;

  public abstract int getJMSMinorVersion()
    throws JMSException;

  public abstract String getJMSProviderName()
    throws JMSException;

  public abstract String getProviderVersion()
    throws JMSException;

  public abstract int getProviderMajorVersion()
    throws JMSException;

  public abstract int getProviderMinorVersion()
    throws JMSException;

  public abstract Enumeration getJMSXPropertyNames()
    throws JMSException;
}