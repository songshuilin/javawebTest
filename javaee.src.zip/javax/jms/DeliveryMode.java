package javax.jms;

public abstract interface DeliveryMode
{
  public static final int NON_PERSISTENT = 1;
  public static final int PERSISTENT = 2;
}