package javax.jms;

public abstract interface TemporaryTopic
  implements Topic
{
  public abstract void delete()
    throws JMSException;
}