package javax.jms;

public abstract interface TopicConnectionFactory
  implements ConnectionFactory
{
  public abstract TopicConnection createTopicConnection()
    throws JMSException;

  public abstract TopicConnection createTopicConnection(String paramString1, String paramString2)
    throws JMSException;
}