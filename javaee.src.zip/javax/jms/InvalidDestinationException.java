package javax.jms;

public class InvalidDestinationException extends JMSException
{
  public InvalidDestinationException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public InvalidDestinationException(String reason)
  {
    super(reason);
  }
}