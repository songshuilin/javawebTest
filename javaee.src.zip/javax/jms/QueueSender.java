package javax.jms;

public abstract interface QueueSender
  implements MessageProducer
{
  public abstract Queue getQueue()
    throws JMSException;

  public abstract void send(Message paramMessage)
    throws JMSException;

  public abstract void send(Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;

  public abstract void send(Queue paramQueue, Message paramMessage)
    throws JMSException;

  public abstract void send(Queue paramQueue, Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
}