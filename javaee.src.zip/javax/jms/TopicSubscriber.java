package javax.jms;

public abstract interface TopicSubscriber
  implements MessageConsumer
{
  public abstract Topic getTopic()
    throws JMSException;

  public abstract boolean getNoLocal()
    throws JMSException;
}