package javax.jms;

public abstract interface XATopicSession
  implements XASession
{
  public abstract TopicSession getTopicSession()
    throws JMSException;
}