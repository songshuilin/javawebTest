package javax.jms;

public abstract interface Queue
  implements Destination
{
  public abstract String getQueueName()
    throws JMSException;

  public abstract String toString();
}