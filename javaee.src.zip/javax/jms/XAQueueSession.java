package javax.jms;

public abstract interface XAQueueSession
  implements XASession
{
  public abstract QueueSession getQueueSession()
    throws JMSException;
}