package javax.jms;

public abstract interface TemporaryQueue
  implements Queue
{
  public abstract void delete()
    throws JMSException;
}