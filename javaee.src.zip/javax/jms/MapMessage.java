package javax.jms;

import java.util.Enumeration;

public abstract interface MapMessage
  implements Message
{
  public abstract boolean getBoolean(String paramString)
    throws JMSException;

  public abstract byte getByte(String paramString)
    throws JMSException;

  public abstract short getShort(String paramString)
    throws JMSException;

  public abstract char getChar(String paramString)
    throws JMSException;

  public abstract int getInt(String paramString)
    throws JMSException;

  public abstract long getLong(String paramString)
    throws JMSException;

  public abstract float getFloat(String paramString)
    throws JMSException;

  public abstract double getDouble(String paramString)
    throws JMSException;

  public abstract String getString(String paramString)
    throws JMSException;

  public abstract byte[] getBytes(String paramString)
    throws JMSException;

  public abstract Object getObject(String paramString)
    throws JMSException;

  public abstract Enumeration getMapNames()
    throws JMSException;

  public abstract void setBoolean(String paramString, boolean paramBoolean)
    throws JMSException;

  public abstract void setByte(String paramString, byte paramByte)
    throws JMSException;

  public abstract void setShort(String paramString, short paramShort)
    throws JMSException;

  public abstract void setChar(String paramString, char paramChar)
    throws JMSException;

  public abstract void setInt(String paramString, int paramInt)
    throws JMSException;

  public abstract void setLong(String paramString, long paramLong)
    throws JMSException;

  public abstract void setFloat(String paramString, float paramFloat)
    throws JMSException;

  public abstract void setDouble(String paramString, double paramDouble)
    throws JMSException;

  public abstract void setString(String paramString1, String paramString2)
    throws JMSException;

  public abstract void setBytes(String paramString, byte[] paramArrayOfByte)
    throws JMSException;

  public abstract void setBytes(String paramString, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws JMSException;

  public abstract void setObject(String paramString, Object paramObject)
    throws JMSException;

  public abstract boolean itemExists(String paramString)
    throws JMSException;
}