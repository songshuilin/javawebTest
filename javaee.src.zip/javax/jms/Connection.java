package javax.jms;

public abstract interface Connection
{
  public abstract Session createSession(boolean paramBoolean, int paramInt)
    throws JMSException;

  public abstract String getClientID()
    throws JMSException;

  public abstract void setClientID(String paramString)
    throws JMSException;

  public abstract ConnectionMetaData getMetaData()
    throws JMSException;

  public abstract ExceptionListener getExceptionListener()
    throws JMSException;

  public abstract void setExceptionListener(ExceptionListener paramExceptionListener)
    throws JMSException;

  public abstract void start()
    throws JMSException;

  public abstract void stop()
    throws JMSException;

  public abstract void close()
    throws JMSException;

  public abstract ConnectionConsumer createConnectionConsumer(Destination paramDestination, String paramString, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException;

  public abstract ConnectionConsumer createDurableConnectionConsumer(Topic paramTopic, String paramString1, String paramString2, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException;
}