package javax.jms;

public abstract interface XAConnectionFactory
{
  public abstract XAConnection createXAConnection()
    throws JMSException;

  public abstract XAConnection createXAConnection(String paramString1, String paramString2)
    throws JMSException;
}