package javax.interceptor;

import java.lang.reflect.Method;
import java.util.Map;

public abstract interface InvocationContext
{
  public abstract Object getTarget();

  public abstract Method getMethod();

  public abstract Object[] getParameters();

  public abstract void setParameters(Object[] paramArrayOfObject);

  public abstract Map<String, Object> getContextData();

  public abstract Object proceed()
    throws Exception;
}